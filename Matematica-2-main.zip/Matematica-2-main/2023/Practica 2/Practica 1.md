# Matematicas 2 - Practica 1

* Profesor - Angelo Goncalo

## Evaluacion

- Puntuacion minimo de ambos partes es 4/10
  * Teoria 50% de la nota final
  * Practica 50% de la nota final

- Teoria 
  * 80% examen final
  * 20% ejercicios teoria

- Practica
  * 80% examen final
  * 20% examen final
