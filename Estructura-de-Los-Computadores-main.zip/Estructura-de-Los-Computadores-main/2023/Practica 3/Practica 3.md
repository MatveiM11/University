# Practica 3 Aritmetica de enteros(2)

* Entrega - `2, 5, 8`

## 1. Desbordamiento e instrucciones unsigned.

>  **Un número entero puede estar representado en binario con signo,
normalmente en complemento a 2, o sin signo directamente en binario natural.**

> . En MIPS
hay instrucciones aritméticas distintas para operar con **valores con signo y sin signo**(por
ejemplo **addi** y **addiu**)

> **el programador es libre de utilizar una instrucción sin signo con un número
en complemento a 2, ahora bien, en ese caso el programador tiene que ser el responsable
de detectar el desbordamiento.**

$$-2^{31}+2^{31-1}$$

- Actividad 1

```assembly MIPS
ori $t1, 0x7FFF
ori $t2, 0x0001
```

```assembly MIPS
addu $t1, $t0, 0x7FFFFFFF
addu $t2, $t0, 0x00000001
```

## 2. Preudoinstrucciones

>  Si en lugar **de addi $t0,$0,10 escribís li $t0,10, el ensamblador traducirá
esta pseudoinstrucción por addi $t0,$0,10**.

```assembly MIPS
li $t0,10
```

> **addi $t1,$t0,0. Ahora podéis escribir la pseudoinstrucción move $t1,$t0**

```assembly MIPS

```

> **invertir cada uno de los bits del registro $t2 y guardarlo en el registro $t1,
hasta ahora habríais escrito nor $t1, $t2, $zero. Ahora podéis escribir Not $t1, $t2.**

```assembly MIPS

```

> Si queréis hacer una resta con el valor inmediato k, hasta ahora habríais escrito, por
ejemplo, addi $t1,$t0,-k. Ahora podéis escribir la pseudoinstrucción
subi $t1, $t0, k.

```assembly MIPS
li $t0, 10
move $t2, $t1
not $t3, $t2
subi $t4, $t1, 1
```

* `subi` es una pseudofuncion, que es una combinacion de `addi` y `sub`.[[1]](https://eng.libretexts.org/Bookshelves/Computer_Science/Programming_Languages/Introduction_To_MIPS_Assembly_Language_Programming_(Kann)/03%3A_MIPS_Arithmetic_and_Logical_Operators/3.03%3A_Subtraction_in_MIPS_Assembly)


## Constantes grandes


```assembly
li $t0,0x10000000
li $t1,0x10000100

- Cuestion 2

## 4. Entrada/salida de caracteres

```assembly MIPS
li $v0,12 #Función 12. Read character
syscall #Carácter leído en $v0
move $a0,$v0 #Carácter a escribir en $a0
li $v0,11 #Función 11. Print character
syscall
li $v0, 10 #Función 10. Acaba programa
syscall
```
> Podéis cargar directamente un carácter en un registro poniéndolo entre comillas
simples, por ejemplo li $a0,'x' o con su valor ASCII li $a0,0x78.

```assembly MIPS
li $a0, 'x'
li $a1, 0x78 # hexadecimal
li $a2, 78 # es diferente, porque es decimal
```

- Cuestion 3

> El carácter ‘\n‘ es el de nueva línea y provoca que la salida por consola desde el
programa comience en una línea nueva. Modifica el código anterior para que al
leer un carácter muestre la salida en una línea diferente.

```assembly
li $v0,12 #Función 12. Read character
syscall #Carácter leído en $v0

move $t3, $v0 #print new line
li, $a0, '\n'
li $v0, 11
syscall

move $a0,$t3 #Carácter a escribir en $a0
li $v0,11 #Función 11. Print character
syscall

li $v0, 10 #Función 10. Acaba programa
syscall
```

# Etiquetas

```assembly MIPS
.text
eti1: addi $v0,$0,5
syscall
eti2: addi $a0,$v0,15
addi $v0,$0,1
syscall

li $a0, '\n'
li $v0,11
syscall

la $t1, eti1 #Carga en $t1 la dirección de

la $t2, eti2 #Carga en $t2 la dirección de

move $a0,$t1
li $v0,34
syscall

li $a0, '\n'
li $v0,11
syscall

move $a0,$t2
li $v0,34
syscall

li $v0,10 #Función 10 Exit
syscall
```

## Trabaja en casa

- Cuestion 2
> Escribid el código (3 líneas entre instrucciones y pseudoinstrucciones) que hace
estas acciones:
$t0=5
$t1=$t0+10
$t2=$t1-30
Ensamblad y ejecutad el programa. Comprobad que el resultado final es ($t0=5,
$t1=15, $t2=-30) es correcto.


```assembly MIPS
.text

add $t0, $t1, 5
addiu $t1, $t0, 10
addi, $t2, $t1, -30
```

- Cuestion 5
> Escribe el código que imprime por consola el valor ASCII en hexadecimal del
carácter leído.


```assembly MIPS
.text

li, $v0,12 # read character
syscall

move $t3, $v0
li $a0, '\n' 
li $v0,11 # print char
syscall

move $a0,$t3
li $v0,34
syscall

li $v0,10 #Función 10 Exit
syscall
```

- Cuestion 8
> Escribe un programa que lea del teclado una letra en mayúscula y la escríba en
minúscula en la consola.


```assembly MIPS
.text

li, $v0,12 # read character
syscall

move $a0, $v0
addiu, $a0, $a0, -32
li $v0,11 # print char
syscall

li $v0,10 #Función 10 Exit
syscall
```
