Practica 5 - 1, 7, 9
Practica 6 - 1,4, 7 
Practica 7 -  2, 6, 7 
Practica 8 - 2, 6, 7

## Practica 5

Cuestión 1.
> La instrucción bltz (branch if less than zero) salta si el valor es menor que cero y
es similar a bgez ya que también compara un registro con 0 pero siendo contraria
la condición de salto. Cambiad la instrucción bgez por bltz, ¿Qué modificaciones
tendríais que hacer en el código?
> Comprobad que el nuevo código con bltz opera correctamente.

Si cambiamos la instrucción bgez por bltz, la condición de salto se modificará de "branch if greater than or equal to zero" a "branch if less than zero". Por lo tanto, la instrucción de salto se ejecutará si el valor en el registro es menor que cero. Para hacer esta modificación en el código, se debe reemplazar la instrucción bgez por bltz.

El código modificado con bltz sería el siguiente:

```assembly MIPS
.text
li $a0, '>'
li $v0,11 #Indicación de escribir un valor
syscall
li $v0,5
syscall #Leer el entero A
bltz $v0, else # Si (A < 0) salta a else
move $a0, $v0 # En $a0 el valor A
j exit #Acaba parte if-then
else: sub $a0, $zero, $v0 # En $a0 el negativo de A
exit: li $v0, 1 #Imprimir lo que hay en $a0
syscall
li $v0, 10 #Acaba el programa
syscall
```
![imagen](https://user-images.githubusercontent.com/90862738/227937135-39c6df25-8f32-4cc2-a318-028e1083d0c8.png)
