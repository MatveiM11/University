#Practica 4 Aritmetica de enteros(3) y funciones

## Entrega

1. 1..4
2. 6..8
3. 9..12
4. **Cuestion - 3, 6, 11**

1, Instrucciones de desplazamiento

> MIPS proporciona además dos pseudoinstruccions para hacer
las operaciones de rotación a la izquierda y a la derecha, estas son `ror` y `rol` (rotate
left/right). 


```assembly MIPS
.text

rol $t1, $t2, $t3

rol $t1, $t2, 10

ror $t1, $t2, $t3

ror $t1, $t2, 10
```

## Trabaja de casa 

Cuestion - 3

> Descubre la palabra escondida. Dado el siguiente código, complétalo de tal
manera que mediante instrucciones lógicas y de desplazamientos puedas escribir
en la consola cada uno de los caracteres que se encuentran almacenados en cada
byte del registre $t1. 

Version 1
```assembly MIPS
.text
li $t1, 1215261793   # load the value to be decoded

# H
srl $t2, $t1, 24  #72
move $a0, $t2
li $v0, 11
syscall

# O
sll $t3, $t1, 8  #111
srl $t3, $t3, 24
move $a0, $t3
li $v0, 11
syscall

# l
sll $t4, $t1, 16  #108
srl $t4, $t4, 24
move $a0, $t4
li $v0, 11
syscall

# a
sll $t5, $t1, 24  #72
srl $t5, $t5, 24
move $a0, $t5
li $v0, 11
syscall
```

Version 2
```assembly MIPS
.text
li $t1, 1215261793   # load the value to be decoded
li $t7, 24


loop:
srlv $t2, $t1, $t7  #cut n bit from right
move $a0, $t2
sll $t3, $t1, 8  # cut 8 bits from left, 4 bits - 1 simbol in hex
move $t1, $t3
li $v0, 11
syscall

addi $t2, $t2, -8   # decrement the shift counter by 8
bgez $t2, loop      # loop while the shift counter is non-negative

li $v0, 10 #end program
syscall
```

Actividad 3
- Cuestion 6
>➢ Modifica el código en el que ahora haya una función multi5 que multiplique por
5 y muestre el resultado por consola. Comprobar que el resultado es correcto.

```assembly MIPS
.text
li $a0, '>'
li $v0, 11
syscall

# read integer from user input
li $v0, 5
syscall
move $a0, $v0

# call mult4 function
jal mult5
move $a0, $v0



# print result
jal imprim

# exit program
li $v0, 10
syscall

# function to multiply by 5
mult5:
add, $t2, $t2, $a0
sll $v0, $a0, 2
add $v0, $v0, $t2
jr $ra



# function to print integer to console
imprim:
addi $v0, $zero, 1
syscall
li $a0, '\n'
li $v0, 11
syscall
jr $ra

```

- Cuestion 11
> ➢ Escribe el código que lee el valor x y escribe por pantalla la solución de la
ecuación: 5x2 + 2x + 3.

```assembly MIPS
.text
li $v0, 5        # read integer from user input
syscall
move $t0, $v0    # store user input in $t0

# calculate result of equation 5x^2 + 2x + 3
add, $t1, $zero, $t0
li $t5, 5
mult $t1, $t1    # $t1 * $t1 = x^2
mflo $t1     # move the least significant 32 bits of the result to $t1
mult $t1, $t5 # 5 * x^2
mflo $t1    # move the least significant 32 bits of the result to $t1
sll $t2, $t0, 1  # $2*x
add $t3, $t1, $t2 # 5x^2+2x
add $t3, $t3, 3 # 5x^2+2x+3


# print result
move $a0, $t3
li $v0, 1        # print integer
syscall

# exit program
li $v0, 10       # exit program
syscall

```
