# Practica 2

## Entrega
`5, 9, 13`

## Entra/Salida(I/O)

Todas las instrucciones de MIPS, son de 4 bytes o 32bits.
6 bits superiores codifican Operacion, Rs5 bits, Rt - 5 bots, Immedianto - 16 bits.
1. Rs - Source register - 1
2. Rt - Source Register 2
3. Rd - Destination register
4. Shamt - Shift amount, specief bits positions to be shifted left or right, empty positions are filled with 0s.


- Print Integer

```assembly MIPS
.text 0x00400000
addi $a0,$0,25 #Valor a escribir en $a0
addi $v0,$0,1 #Función 1, print integer
syscall #Escribe en consola $a0
```

- Leer de teclado e imprimir en consola. Para leer se utiliza la función 5 (read integer).
Si metemos 5 en lo registro $v0 se lee un entero del teclado. El valor leído se
almacenará en $v0.

```assembly MIPS
.text
addi $v0,$0,5 #Función 5, read integer
syscall #Valor leído en $v0
addi $a0,$v0,0 #Movemos el valor leído a $a0
addi $v0,$0,1 #Función 1, print integer
syscall #Escribimos en consola $a0
```

* PC contador cado bito es digito separado. 
  Por ejemplo - 14 en hexadecimal no es representacion entera, pero dos numeros 1 y 4.
 
 `0x00400000 -> 0x00400004 -> 0x00400008 -> 0x0040000c`
 
 - Finalizar el programa. Incorporamos la función 10 (exit), lo que hace esta función es
salir del proceso o acabar el programa. De aquí en adelante lo utilizaremos para finalizar
los programas.

```assembly mips
.text
addi $v0,$0,5 #Función 5, read integer
syscall #Valor leído en $v0
addi $a0,$v0,0 #Movemos el valor leído a $a0
addi $v0,$0,1 #Función 1, print integer
syscall #Escribimos en consola $a0
addi $v0,$0,10 #Función 10, exit
syscall #Acaba el programa
```

- Cuestión 1.
> Haz un código que lee un valor x de teclado y escribe x+1 en la consola.

```assembly MIPS
.text
addi $v0,$0,5 #Función 5, read integer
syscall #Valor leído en $v0
addi $a0,$v0,1 #Movemos el valor leído a $a0 + 1
addi $v0,$0,1 #Función 1, print integer
syscall #Escribimos en consola $a0
addi $v0,$0,10 #Función 10, exit
syscall #Acaba el programa
```
O
```assembly mips
.text
addi $v0,$0,5 #Función 5, read integer
syscall #Valor leído en $v0
addi $a0,$v0,0 #Movemos el valor leído a $a0 
addi $a0,$a0,1 # x+1
addi $v0,$0,1 #Función 1, print integer
syscall #Escribimos en consola $a0
addi $v0,$0,10 #Función 10, exit
syscall #Acaba el programa
```
 
 - Cuestion 7

> Escribe el código que hace estas acciones haciendo uso de las instrucciones
estudiadas:
$t0=5
$t1=$t0+10
$t2=$t0+$t1
$t3=$t1-30


```assembly

```

- Cuestion 10
> ¿Cómo escribirías la instrucción que hace $t2=7 utilizando ori?

```assembly MIPS
.text
ori $t2, $t0, 7
```

- Cuestion 12

> Reescribid el código de partida Aritmética de enteros del apartado 2 cambiando
addi o addiu por ori:
```assembly MIPS
.text 0x00400000

ori $a0, $zero, 25 # Valor a a0
ori $v0, 1 # Fun 1, print int
syscall
```

> ¿Cuál es el valor del código de operación de la instrucción ori?

`001101`

- Cuestion 14


- Ayudas a la programacion: mas sobre entrada y salida


# Trabaja en Casa

- Cuestion 5

> ¿Cómo se codifica la última instrucción de resta del código de partida Aritmética
de enteros de la actividad 4? Hacedlo a manos (el campo función de la resta es
0x22)

 ```assembly MIPS
  sub $t2,$t0,$t1
 ```

1. Opcode para instrucciones de R-tipo es 0, 6 bits `000000`.
2.  Rs -  $t0 = 8<sub>dec</sub> -> 5bits 01000<sub>bin</sub>
3. Rt - $t1 = 9<sub>dec</sub> -> 5bits 01001<sub>bin</sub>
4. Rd - $t2 = 10<sub>dec</sub> -> 5bits 01010<sub>bin</sub>
5. shamt = 0 -> 5bits 00000<sub>bin</sub>
6. funct = 22<sub>hex</sub> -> 6 bits 0010 0010<sub>bin</sub> -> 100010<sub>bin</sub>
  
Por el fin - `000000 01000 01001 01010 00000 100010`

>  Confirmad con el programa ensamblado que el código máquina es el mismo.
![imagen](https://user-images.githubusercontent.com/90862738/220236795-3016f06a-c574-4653-bcf9-3cbbc4581b57.png)


- Cuestion 9

> Haz el código que lee dos números x e y, y obtén por pantalla x-y

 ```assembly MIPS
 .text
    # read first number
    li $v0, 5
    syscall
    move $t0, $v0 # movemos el valor leido
    
    # read second number
    li $v0, 5
    syscall
    move $t1, $v0 # movemos el valor leido
    
    # subtract second number from first number
    sub $t2, $t0, $t1
    
    # print result
    li $v0, 1
    move $a0, $t2 # movemos el valor leido
    syscall
    
    # exit program
    li $v0, 10
    syscall
 ```

-Cuestion 13

 ```assembly MIPS
 .text
ori $t1, $zero, 0x55555555   # Inicializar $t1 en 0x55555555
ori $t2, $zero, 0xAAAAAAAA   # Inicializar $t2 en 0xAAAAAAAA

or $t3, $t1, $t2      # $t3 = $t1 OR $t2
and $t4, $t1, $t2     # $t4 = $t1 AND $t2
xor $t5, $t1, $t2     # $t5 = $t1 XOR $t2
 ```

- Cuestion 14 - 15
![imagen](https://user-images.githubusercontent.com/90862738/220244369-99a2fb00-7e7d-4fd6-8b1b-3a4729bbc655.png)



```assembly MIPS
# Reorder bits of $t1 to get 0x0000CAFE in $t2
ori $t1, $zero, 0x0000FACE  # load 0x0000FACE into $t1
andi $t2, $t1, 0x0000CFFF # el resultado ahoro es  0x...CACE
ori $t2, $t2, 0x00000030 #el resultado ahoro es 0x...CAFE
ori $a0, $t2,0
ori $v0, $zero, 34 #print hex
syscall 
ori $v0, $zero, 10 #salir
syscall

```
