# Practica 1

## OBLIGATORIO
- Actividades obligatorias - 3,5,7

## Teoria

- Cuestion 2

>El símbolo # marca el inicio de un comentario. El ensamblador ignorará lo que haya a la
derecha de este símbolo.
La línea .text 0x00400000 dice en que dirección de la memoria comienza el programa.
0x00400000 es la dirección por defecto, si no introducimos nada el ensamblador asume
este valor.
La instrucción addi (suma inmediata) se escribe en lenguaje ensamblador de la forma 

```assembly mips
 addi rt, rs, k
 ```
>donde rt y rs pueden ser cualquier número de registro del 0 al 31 y K cualquier nombre
codificado en complemento a 2 con un tamaño de 16 bits. La instrucción hace rt = rs +
K, es decir, lee un registro fuente (rs), hace la suma del su contenido y la constante K y
escribe el resultado de la suma en el registro destino (rt).
Gráficamente podemos expresarlo como:  

![image](https://user-images.githubusercontent.com/90862738/215717299-19e66f77-f4b7-4668-adc4-b6182a19d1ef.png)


## Ejercicios 

## Cuestiones 
.1
> ¿Cuál es el mayor positivo que puede contener un registro del MIPS? Basta con
que lo digas en hexadecimal. 

Tenemos 32 bits para un INT, un bit es para signo y un bit para 0 en positivos, entonces tenemos 2^31-1 bits para positivos y 2^31 para negativos numeros. 
2^31-1 es 2147483647 , en hexadecimal es 0x7fffffff. Y 2^31 es -2147483648 o 0x80000000 en hexadecimal.

.2
> ¿Cómo se codifica la instrucción addi $10,$8,5? Escribid el código resultante en
hexadecimal

Codigo op(6 bits) Rs(5 bits) Rt(5 bits) K(konsante)  
`(0010 00) (01 000) (0 1001) (0000 0000 0001 0101)`

.4 La ventana text segment 

> Observa la ventana Text Segment. ¿En qué dirección se almacena cada instrucción
del programa? 

En Adress.

> Observa la ventana Registers. ¿Qué vale el PC?

PC vale a  0x00400000 o 4194304.

.5 El cicló de instrucción

Actividad 3
> Dad el siguiente valor inicial a $8 = 0x7FFFFFFF y ejecutad de nuevo el programa
paso a paso fijándoos en la ventana Mars Messages. ¿Qué ha ocurrido? 

```assembly mips
addi $10,$8,5
```

```bash
Error in /home/mt106/Escritorio/practica1.asm line 1: Runtime exception at 0x00400000: arithmetic overflow

Step: execution terminated with errors.
```

Cuestion 3
> ¿Cuál es el valor más grande que podrá contener $8 para que no se aborte el
programa

Un maximo de INT positivo es 2^31-1 y INT negativo es 2^31.


.6 Usos alternativos de addi 

Actividad 4

```assembly mips
addi $8,$0,3
addi $12,$8,0
```

>  ¿Se podría utilizar la instrucción addi para hacer una resta?

```assembly mips
addi $8,$0,3
addi $12,$8,-1
```

Si, puedo.

Cuestion 4

> ¿Cómo se escribe la instrucción que hace $8 = $8-1? 

```assembly mips
addi $8,$0,3
addi $8,$8,-1
```

> ¿Cómo quedaría su codificación en binario?

`(001000)(0100)(01001)(1111 1111 1111 1111)`


.8 Más sobre la suma inmediata.

Actividad 5

Cuestion 6


```
addi $t4, $zero, 5
addi $t2, $zero, 8
addi $t5, $t4, 10
addi $t2, $t2, -4
addi $t6, $t5, -30
addi $t7, $t2, 0
```


## Trabaja en casa

- Actividad 3
> Dad el siguiente valor inicial a $8 = 0x7FFFFFFF y ejecutad de nuevo el programa
paso a paso fijándoos en la ventana Mars Messages. ¿Qué ha ocurrido? 

```assembly mips
addi $10,$8,5
```

```bash
Error in /home/mt106/Escritorio/practica1.asm line 1: Runtime exception at 0x00400000: arithmetic overflow

Step: execution terminated with errors.
```

Cuestion 3
> ¿Cuál es el valor más grande que podrá contener $8 para que no se aborte el
programa

Un maximo de INT positivo es 2^31-1 y INT negativo es 2^31.

- Actividad 4

**Cuestión 5**

> Reescribid el programa anterior utilizando el convenio de registros y vuelve a
ejecutarlo.

```assembly mips
addi $8,$0,3
addi $8,$8,-1
```

Version modificada:

```assembly
addi $t0,$zero,3
addi $t0,$t0,-1
```


- Actividad 5


Cuestion 6

> Escribe el código que haga las siguientes acciones utilizando el convenio de
registros y utilizando la instrucción addi:
```assembly
$12=5
$10= 8
$13=$12 + 10
$10=$10 - 4
$14=$13 – 30
$15=$10
```

> Ensamblad y ejecutad el programa y comprobad que el resultado final es $t7 = $t2
= 4, $t6=-15, $t4=5,$t5=15.

```assembly mips
addi $t4, $zero, 5
addi $t2, $zero, 8
addi $t5, $t4, 10
addi $t2, $t2, -4
addi $t6, $t5, -30
addi $t7, $t2, 0
```
![image](https://user-images.githubusercontent.com/90862738/216791966-dfe6f4cc-508e-4fd4-adb5-8210917beb91.png)

Cuestión 7

> ¿Se podría escribir el mismo código utilizando la instrucción addiu? Haz la
prueba.

Si, puedo sin problema, los resultados son mismos.
```assembly
addiu $t4, $zero, 5
addiu $t2, $zero, 8
addiu $t5, $t4, 10
addiu $t2, $t2, -4
addiu $t6, $t5, -30
addiu $t7, $t2, 0
```
![image](https://user-images.githubusercontent.com/90862738/216791980-3ad80088-ffc6-4d5d-84c8-1f9674a5ba35.png)

> ¿Cuál es el código de operación de la instrucción addiu?

```opcode
001001
```

> Codifica en binario la instrucción addiu $v0, $zero, 1.

```opcode
(001001)(00000)(00010)(0000000000000001)
```


