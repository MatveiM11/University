
"ori" igual al "li"

