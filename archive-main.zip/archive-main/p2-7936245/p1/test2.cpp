#include <cctype>  // Para isalpha(), isdigit(), etc.
#include <cstdlib> // Para rand(), srand() y atoi()
#include <iostream>
using namespace std;

int main()
{
    bool correct_distribution = false;
  char distribution[6];
  char attack; char defense;
  while (correct_distribution != true) {

    cout << endl << "Enter attack/defense:";
  
    cin.getline(distribution, 6);
    
    switch(distribution){
        case distribution[0]- '0' >=1;
        cout << distribution[0] << attack:
        cout << distribution[0] << attack;
        break;
    }
    
     
    
    
   /* int itemp_attack = 0;
    int itemp_def = 0;
    
    if((temp_attack1 - '0') <= 9 and temp_attack2 == '/'){
        temp_def2 = temp_def1;
        temp_def1 = separator;
        
        separator = '/';
        
        itemp_attack = temp_attack1 - '0';
        itemp_def = (temp_def1 - '0') * 10 + (temp_def2 - '0');
        
    }
    else{
     itemp_attack = (temp_attack1 - '0') * 10 + (temp_attack2 - '0');
     itemp_def = (temp_def1 - '0') * 10 + (temp_def2 - '0');
    }*/
     
    /* Inputing an int to a string causing an error that keeps cin storing
       the incorrect numbers, so besides of using char from the beginning we
       can clear cin after an error.
       if (cin.fail())
       {
       cin.clear();
       cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
       cout << "Not a number";
       }
     */

    /*if (separator == '/' and itemp_attack + itemp_def == 100) {
      h1.features.attack = KPOINTS / 100 * itemp_attack;
      h1.features.defense = KPOINTS / 100 * itemp_def;
      correct_distribution = true;
      
      cout << endl << "Attack points: " << h1.features.attack << endl;
      cout << endl << "Defense points: " << h1.features.defense << endl;
    } else {
      cout << endl << "ERROR: wrong distribution" << endl;
    }*/

    return 0;
}
}
