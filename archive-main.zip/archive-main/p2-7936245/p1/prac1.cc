// DNI: 7936245
// Nombre: Marat Tskonyan

#include <cctype>  // Para isalpha(), isdigit(), etc.
#include <cstdlib> // Para rand(), srand() y atoi()
#include <iostream>

using namespace std;

const int KNAME = 32;
const int KENEMIES = 5;
const int KPOINTS = 200;
const int KDICE = 20; // Numero de caras del dado

struct Core {
  int attack;
  int defense;
  int hp;
};

enum Breed { AXOLOTL, TROLL, ORC, HELLHOUND, DRAGON };

struct Enemy {
  Breed name;
  Core features;
};

struct Hero {
  char name[KNAME];
  Core features;
  bool special;
  int runaways;
  int exp;
  int kills[KENEMIES];
};

int rollDice() { return rand() % KDICE + 1; }

Hero createHero() {
  Hero hero1; // Hero variable
  hero1.features.hp = 300;
  hero1.exp = 0;
  hero1.runaways = 3;
  hero1.special = true;
  hero1.kills[0] = 0; // Axolotls    | intitializing all kills as zero
  hero1.kills[1] = 0; // Troll
  hero1.kills[2] = 0; //  Orc
  hero1.kills[3] = 0; // Hellhound
  hero1.kills[4] = 0; // Dragon
  bool correct_name = false;
  while (correct_name != true) {
    cout << endl << "Enter hero name: ";
    cin.getline(hero1.name, KNAME - 1);

    int alpha = 0, digit = 0, space = 0, name_error = 0, name_i;
    for (name_i = 0; hero1.name[name_i] != '\0'; name_i++) {

      // searching for letters
      if (isalpha(hero1.name[name_i]) != 0) {
        alpha++;
      }
      // searching for digits
      else if (isdigit(hero1.name[name_i]) != 0) {
        digit++;
      }
      // searching for spaces
      else if (isspace(hero1.name[name_i]) != 0) {
        space++;
      }
      // all special numbers just going to else
      else {
        name_error++;
      }
    }

    if (isalpha(hero1.name[0]) and name_error == 0) {
      correct_name = true;
      //cout << endl << hero1.name << " has came to this world!" << endl;
    } else {
      cout << endl << "ERROR: wrong name" << endl;
    }
  }

  bool correct_distribution = false;
  char temp_attack1;
  char temp_attack2;
  char temp_def1;
  char temp_def2;
  char separator = '3';

  while (correct_name == true and correct_distribution != true) {

    cout << endl << "Enter attack/defense:";
    cin >> temp_attack1 >> temp_attack2 >> separator >> temp_def1 >> temp_def2;

    int itemp_attack =
        (temp_attack1 - '0') * 10 +
        (temp_attack2 - '0'); // turning chars to int for each digit
    int itemp_def = (temp_def1 - '0') * 10 + (temp_def2 - '0');

    /* Inputing an int to a string causing an error that keeps cin storing
the incorrect numbers, so besides of using char from the beginning we
can clear cin after an error.
if (cin.fail())
{
     cin.clear();
     cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
     cout << "Not a number";
}
*/

    if (separator == '/' and itemp_attack + itemp_def == 100) {
      hero1.features.attack = KPOINTS / 100 * itemp_attack;
      hero1.features.defense = KPOINTS / 100 * itemp_def;
      correct_distribution = true;
    } else {
      cout << endl << "ERROR: wrong distribution" << endl;
    }
  }
  return hero1;
}

Enemy createEnemy() {
  Enemy enemy1;

  int edice = rollDice();

  cout << endl << "[Enemy]" << endl;

  switch (edice) {
  case 1 ... 6:
    enemy1.name = AXOLOTL;
    enemy1.features.attack = 40;
    enemy1.features.defense = 40;
    enemy1.features.hp = 40;
    cout << "Breed: Axolotl" << endl;
    cout << "Attack: " << enemy1.features.attack << endl;
    cout << "Defense: " << enemy1.features.defense << endl;
    cout << "Health points: " << enemy1.features.hp << endl;
    break;

  case 7 ... 11:
    enemy1.name = TROLL;
    enemy1.features.attack = 60;
    enemy1.features.defense = 80;
    enemy1.features.hp = 160;
    cout << "Breed: Troll" << endl;
    cout << "Attack: " << enemy1.features.attack << endl;
    cout << "Defense: " << enemy1.features.defense << endl;
    cout << "Health points: " << enemy1.features.hp << endl;
    break;

  case 12 ... 15:
    enemy1.name = ORC;
    enemy1.features.attack = 80;
    enemy1.features.defense = 120;
    enemy1.features.hp = 240;
    cout << "Breed: Orc" << endl;
    cout << "Attack: " << enemy1.features.attack << endl;
    cout << "Defense: " << enemy1.features.defense << endl;
    cout << "Health points: " << enemy1.features.hp << endl;
    break;

  case 16 ... 18:
    enemy1.name = HELLHOUND;
    enemy1.features.attack = 120;
    enemy1.features.defense = 100;
    enemy1.features.hp = 200;
    cout << "Breed: Hellhound" << endl;
    cout << "Attack: " << enemy1.features.attack << endl;
    cout << "Defense: " << enemy1.features.defense << endl;
    cout << "Health points: " << enemy1.features.hp << endl;
    break;

  case 19 ... 20:
    enemy1.name = DRAGON;
    enemy1.features.attack = 160;
    enemy1.features.defense = 140;
    enemy1.features.hp = 300;
    cout << "Breed: Dragon" << endl;
    cout << "Attack: " << enemy1.features.attack << endl;
    cout << "Defense: " << enemy1.features.defense << endl;
    cout << "Health points: " << enemy1.features.hp << endl;
    break;
  }
  return enemy1;
}
bool isspecial = false;
int runaways_row =
    0; // runaway counter for check that ther's no 2 escapes in a row
void fight(Hero &hero1, Enemy &enemy1) {

  int tohit = rollDice();
  int towound = rollDice();
  int hattack = tohit * 5 + hero1.features.attack;
  int edefense = towound * 5 + enemy1.features.defense;
  if (hattack - edefense >= 1) {
    if (isspecial == true) { // cheking is special used
      enemy1.features.hp =
          (enemy1.features.hp - (hattack - edefense)) * 3; // damage multiplied

    } else {
      enemy1.features.hp =
          enemy1.features.hp - (hattack - edefense); // normal damage
    }

  } else {
    enemy1.features.hp = enemy1.features.hp;
  }
  int hitp = hattack - edefense;
  if (hitp >= 0) {
    hitp = hitp;
  } else {
    hitp = 0;
  }

  cout << endl << "[Hero -> Enemy]" << endl; // hero attack turn
  cout << "Attack: " << hero1.features.attack << " + " << tohit * 5 << endl;
  cout << "Defense: " << enemy1.features.defense << " + " << towound * 5
       << endl;
  cout << "Hit points: " << hitp << endl;
  if (enemy1.features.hp < 0) {
    enemy1.features.hp = 0;
  }
  cout << "Enemy health points: " << enemy1.features.hp << endl;

  if (enemy1.features.hp <= 0) {
    enemy1.features.hp = 0;
    cout << endl << "Enemy killed" << endl;
    switch (enemy1.name) {
    case AXOLOTL:
      hero1.exp += 100;
      hero1.kills[0] += 1;
      break;
    case TROLL:
      hero1.exp += 150;
      hero1.kills[1] += 1;
      break;
    case ORC:
      hero1.exp += 200;
      hero1.kills[2] += 1;
      break;
    case HELLHOUND:
      hero1.exp += 300;
      hero1.kills[3] += 1;
      break;
    case DRAGON:
      hero1.exp += 400;
      hero1.kills[4] += 1;
      break;
    }
    cout << "Exp: " << hero1.exp << endl;
    enemy1 = {};
    enemy1 = createEnemy();
  } else {

    tohit = rollDice();
    towound = rollDice();
    hattack = tohit * 5 + enemy1.features.attack;
    edefense = towound * 5 + hero1.features.defense;
    if (hattack - edefense >= 1) {
      hero1.features.hp = hero1.features.hp - (hattack - edefense);
    } else {
      hero1.features.hp = hero1.features.hp;
    }
    hitp = hattack - edefense;
    if (hitp >= 0) {
      hitp = hitp;
    } else {
      hitp = 0;
    }

    if (hero1.features.hp != 0 and hero1.features.hp > 0) { // enemy attack turn
      cout << endl << "[Enemy -> Hero]" << endl;
      cout << "Attack: " << enemy1.features.attack << " + " << tohit * 5
           << endl;
      cout << "Defense: " << hero1.features.defense << " + " << towound * 5
           << endl;
      cout << "Hit points: " << hitp << endl;
      cout << "Hero's health points: " << hero1.features.hp << endl;
    } else {
      cout << endl << "You are dead" << endl;
      runaways_row = 0;
      isspecial = false;
      cin.ignore(1000, '\n');
    }
  }
}

void report(const Hero &hero1) { // hero statistics report
  cout << "[Report]" << endl;
  cout << endl << "Name: " << hero1.name << endl;
  cout << "Attack: " << hero1.features.attack << endl;
  cout << "Defense: " << hero1.features.defense << endl;
  cout << "Healt points: " << hero1.features.hp << endl;
  string check_special;
  if(hero1.special == 1){
    check_special = "yes";
  }
  else{
    check_special = "no";
  }
  cout << "Special: " << check_special << endl;
  cout << "Runaways: " << hero1.runaways << endl;
  cout << "Exp: " << hero1.exp << endl;
  cout << "Enemies killed: " << endl;
  cout << "- Axolotl:" << hero1.kills[0] << endl;
  cout << "- Troll:" << hero1.kills[1] << endl;
  cout << "- Orc:" << hero1.kills[2] << endl;
  cout << "- Hellhound:" << hero1.kills[3] << endl;
  cout << "- Dragon:" << hero1.kills[4] << endl;
  int total = hero1.kills[0]+hero1.kills[1]+hero1.kills[2]+hero1.kills[3]+hero1.kills[4];
  cout << "- Total: " << total << endl;
}
bool quit = false;
void showMenu(Hero &hero1, Enemy &enemy1) {
  char option = '5';

  while (quit != true and hero1.features.hp > 0) {
    cout << endl;
    cout << "[Options]" << endl
         << "1- Fight" << endl
         << "2- Run away" << endl
         << "3- Special" << endl
         << "4- Report" << endl
         << "q- Quit" << endl
         << "Option: ";
    cin >> option;

    switch (option) {
    case '1': // figh option

      fight(hero1, enemy1);
      runaways_row = 0; // reset of the runaway row checking counter

      break;
    case '2': // runaway option

      // cout << endl << "Runaway row: " << runaways_row << endl; - for
      // debugging
      runaways_row++;
      if (hero1.runaways > 0 and runaways_row < 2) {
        hero1.runaways--;
        enemy1 = createEnemy();
      } else {
        cout << endl << "ERROR: cannot run away" << endl;
      }
      // cout << endl << "Runaway row: " << runaways_row << endl; - for
      // debugging

      break;

    case '3': // special
      if (hero1.special == true) {
        isspecial = true;
        hero1.special = false;
      } else {
        cout << endl << "ERROR: special not available" << endl;
      }
      runaways_row = 0;

      break;

    case '4': // report
      report(hero1);

      runaways_row = 0;

      break;

    case 'q': // quit
      quit = true;
      hero1.features.hp = 0;
      cin.ignore(1000, '\n');
      runaways_row = 0;
      break;
    default: // Error
      cout << endl << "ERROR: wrong option" << endl;
      break;
    }
  }
}

int main(int argc, char *argv[]) {
  if (argc != 2) { // Si los parametros no son correctos, el programa termina
                   // inmediatamente
    cout << "Usage: " << argv[0] << " <seed>" << endl;
  } /*  */
  else {
    srand(atoi(
        argv[1])); // Introducimos la semilla para generar nC:meros aleatorios

    // Aqui- vendra todo tu codigo del "main"...

    Hero hero1;
    Enemy enemy1;
    while (true and quit != true) {
      hero1 = createHero();

      while (hero1.features.hp > 0) {
        enemy1 = createEnemy();
        showMenu(hero1, enemy1);
      }
    }
  }
}
