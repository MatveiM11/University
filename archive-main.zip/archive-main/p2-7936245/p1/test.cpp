#include <iostream>


using namespace std;

struct Core
{
  int attack;
  int defense;
  int hp;
};

enum Breed
{
  AXOLOTL,
  TROLL,
  ORC,
  HELLHOUND,
  DRAGON
};

struct Enemy
{
  Breed name;
  Core features;
};






Enemy createEnemy()
{
  Enemy e1;


  cout << endl
       << "[Enemy]" << endl;

  e1.name = AXOLOTL;
    e1.features.attack = 40;
    e1.features.defense = 40;
    e1.features.hp = 50;
    cout << "Breed: Axolotl" << endl;
    cout << "Attack: " << e1.features.attack << endl;
    cout << "Defense: " << e1.features.defense << endl;
    cout << "Health points: " << e1.features.hp << endl;
}

void fight(Enemy &e1){



cout << "[Hero -> Enemy]" << endl;

cout << "Enemy health points: " << &e1.features.hp << endl;

}


int main(Enemy e1){

    createEnemy();
    fight(e1);
}
