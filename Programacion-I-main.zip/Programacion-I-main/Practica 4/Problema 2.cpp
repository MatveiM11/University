
#include <iostream>


using namespace std;

int main() {          
int dulce=0;
int num;
int regala=0;
int rent=0;

while ( num !=0){    
    cout << "Escribe cunatos envoltorios de Dulcemelos tienes. Escribe 0 para finalizar" << endl;
    cin >> num;
    dulce+=num;
    regala+=num/5;
     if(dulce%5>=1&&dulce!=0){
         rent=+dulce;
     }
    
}

  if(rent%5>=1){
        
        cout << dulce<<" " <<regala <<" RENTABLE";
    }
    else{
        
        cout << dulce<<" " <<regala <<" NO RENTABLE";
    }
    
    return 0;
}
