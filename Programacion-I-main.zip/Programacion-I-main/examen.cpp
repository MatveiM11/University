#include <iostream>
using namespace std;

void start(int inp, char &srt); //declaring function


int main(){
 
int inp = 0; //Deposite and start input
char srt;

while(1){ //main loop
    cout << "Deposite moneda (5-10-20-50) o pida articulo (tecla 0)";
    cin >> inp;
    start(inp, srt);
    while(srt == 's'){
        cout << "started succesefully" << endl;
        break;
    }
}

}




//function
void start(int inp, char &srt){
     switch(inp){
        case 0: srt= 's';
        break;
     }

    


}
