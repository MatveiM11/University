#include <iostream>
#include <cmath>
using namespace std;

int main(){
 
int input, resto;
int suma = 0;

//cin >> input;

cin >> input;

for(int i = 2; i <= 8; i++){
    resto = pow(10, i);
    
    if(i%2 == 0){
    suma += (input%resto)/(resto/10)*3;
    }
    else if(i%2 != 0){
    suma += (input%resto)/(resto/10)*1;
    }
    
}

    if(((suma + input%10)%10) == 0){
        
         cout << "SI" << endl;
    }
    else{cout << "NO" << endl;}




return 0;
}
