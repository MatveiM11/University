#include <iostream>
#include "gfx.h" // librería con las funciones gráficas
using namespace std;

int main() {
 char c;
 int X1, Y1, X2, Y2;
 X1 = 100;
 Y1 = 100;
 X2 = 300;
 Y2 = 100;
 // instrucciones para preguntar al usuario
 // instrucción para abrir una ventana para dibujar
 gfx_open(500, 500, "figura");
 // instrucción para indicar el color del dibujo
 gfx_color(0,200,100);
 // instrucciones para dibujar líneas (mirar Apéndice)

 /* sand clocks
 while(X1 != 300 and Y1 != 300 and X2 != 100 and Y2 != 300){
 X1++;
 Y1++;
 X2--;
 Y2++;
 gfx_line(X1,Y1,X2,Y2);

  // c = gfx_wait(); // step by step
 }*/

 /* //square
 while(Y1 != 300 and Y2 != 300){
 Y1++;
 Y2++;
 gfx_line(X1,Y1,X2,Y2);
 // c = gfx_wait(); // step by step
 }
*/

  while(Y1 != 200 and Y2 != 200){
 Y1++;
 Y2++;
 gfx_line(X1,Y1,X2,Y2);
 // c = gfx_wait(); // step by step
 }

// bottom
gfx_line(100,100,300,100);


//pixel
// gfx_line(250,250,250,250);

 // esperar hasta que se presione una tecla o botón
 c = gfx_wait();
}
