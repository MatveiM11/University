Referencias - 

1. https://www3.nd.edu/~dthain/courses/cse30341/spring2020/project3/gfx/


Compilacion - 

```bash
g++ -o ej1 ej1.cpp gfx.c -lX11 -lm
```

