#include <iostream>

using namespace std;

int main(){
    
int entr;

cin >> entr;


if(entr/1000 >= 1 and ((entr/1000)%2 == 0) and (((entr%100)/10))%2 == 0){
    if((entr/1000 == entr%10) and (((entr/100)%10) == ((entr%100)/10))){
    cout << "VAMPIRO" << endl;
    }
}
else{
    cout << "NO VAMPIRO" << endl;
    
}
    
    
return 0;    
}
