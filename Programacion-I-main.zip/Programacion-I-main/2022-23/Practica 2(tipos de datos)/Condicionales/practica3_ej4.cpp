#include <iostream>

using namespace std;

int main(){
    
int entr1, entr2, temp;

temp = -1;

cin >> entr1 >> entr2;

if(entr1 > entr2){
    temp = entr1;
    entr1 = entr2;
    entr2 = temp;
}

if(entr1 + entr2 <= 60 and temp == -1){
  cout << entr2 - entr1 << " creciente";
}
else if((entr1 + entr2) - 60 >= 0){
    cout << (entr1 + entr2) - 60 << " decreciente" << endl;
    
}
else if((entr1 + entr2) - 60 < 0){
    cout << ((entr1 + entr2) - 60) * -1 << " decreciente" << endl;
    
}
    
return 0;    
}
