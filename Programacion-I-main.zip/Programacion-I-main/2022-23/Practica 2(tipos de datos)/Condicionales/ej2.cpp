#include <iostream>

using namespace std;

int main()
{
    char type;
    int type_i = 0;
    int euros;
    float centimos;
    
    cout<<"RECARGOS A APLICAR \nOcio   50 centimos \nBascio 80 centimos \nExtra  60 centimos";
    cout <<"Tipo de material (o/t): ";
    cin >> type;
    
    if(type == 'o' or type == 't' or type == ' '){
    }
    else{
    cout << "No existe ese tipo de material" << endl << type_i;
    return 0;
    }
    
    type_i += type;
    
    cout <<"Basico o extra (b/e): ";
    cin  >> type;
    if(type == 'e' or type == 'b')
    
    
    switch(type_i){
    
    case 62: cout << 50;
    break;
    
    default: cout << "No existe ese tipo de material" << endl << type_i;
    break;
        
    }

    return 0;
}
