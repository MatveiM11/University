#include <iostream>
#include "gfx.h" // librería con las funciones gráficas
using namespace std;

int main() {
 char c;
 // instrucciones para preguntar al usuario
 // instrucción para abrir una ventana para dibujar
 gfx_open(500, 500, "figura");
 // instrucción para indicar el color del dibujo
 gfx_color(0,200,100);
 // instrucciones para dibujar líneas (mirar Apéndice)
 gfx_line(100,100,300,100);
 gfx_line(300,100,300,300);
 gfx_line(300,300,100,300);
 gfx_line(100,300,100,100);

//pixel
 gfx_line(250,250,250,250);

 // esperar hasta que se presione una tecla o botón
 c = gfx_wait();
} 
