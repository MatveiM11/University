#include <iostream>
#include "gfx.h" // librería con las funciones gráficas
using namespace std;

int main() {
 char c;
 // instrucciones para preguntar al usuario
 // instrucción para abrir una ventana para dibujar
 gfx_open(1000, 1000, "figura");
 // instrucción para indicar el color del dibujo
 gfx_color(0,200,100);
 // instrucciones para dibujar líneas (mirar Apéndice)

 //rectangulo
 gfx_line(100,100,300,100);
 gfx_line(300,100,300,200);
 gfx_line(300,200,100,200);
 gfx_line(100,200,100,100);

 // cuadrado
 gfx_line(500,500,628,500);
 gfx_line(500,500,500,628);
 gfx_line(500,628,628,628);
 gfx_line(628,628,628,500);


//pixel
 //gfx_line(250,250,250,250);

 // esperar hasta que se presione una tecla o botón
 c = gfx_wait();
} 
