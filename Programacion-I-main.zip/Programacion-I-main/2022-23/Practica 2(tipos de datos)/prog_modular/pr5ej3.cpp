#include <iostream>
#include <stdlib.h> 
#include <time.h>

using namespace std;

 void nueva_carta(){
     
      srand(time(NULL));
     
     int temp_carta;
     
     do{
        
         temp_carta = rand()%100;
         
         
     }while(temp_carta == 0 or temp_carta > 21);
     
     cout << "Te ha salido un " << temp_carta;
    }


int main(){
    
   

int n1;
    
   nueva_carta();

return 0;

}
