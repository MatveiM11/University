#include <iostream>

using namespace std;

void tri_izquierda(int filas, char simbolo, char simbolo_2){

    for(int i = 0; i <= filas; i++){
        cout << endl;
        for(int j = 0; j < filas- i; j++){
            
            if( i == 0){
                cout << simbolo;
            }
            else if( (i > 0 and j == 0) or (i > 0 and j == filas-i-1)){
                cout << simbolo;
            }
            else if( i > 0 and j != 0 and j < filas-i-1){
                cout << simbolo_2;
            }
            
        }
    }
}

void tri_derecha(int filas, char simbolo, char simbolo_2){
    
    for(int i = 0; i <= filas; i++){
        cout << endl;
        for(int j = 0; j <= filas-1; j++){
            
            
            if ( (i == 0 and j == 0) or (i == 0 and j == filas-1) or (i == filas-1 and j == filas-1)){
                cout << simbolo_2;
            }
            else if(j <= i){
                cout << " ";
            }
            else{
                cout << simbolo;
            }
            
        }
    }
    
}

void tri_equilatero(int filas, char simbolo, char simbolo_2){
    
    for(int i = 0; i < filas; i++){
        cout << endl;
        for(int j = 0; j < filas*2; j++){
            
            if(j < filas-i or j > filas+i){
                cout << " ";
            }
            else{
                if((i == 0) or (i%2 != 0 and j%2 != 0) or (i%2 == 0 and j%2 == 0)){
                   cout << simbolo; 
                }
                
                else if((i != 0) or (i%2 != 0 and j%2 == 0) or (i%2 == 0 and j%2 != 0)){
                    cout << simbolo_2;
                }
            }
            
        }
    }
    
}

void menu_tri(){

int filas, opcion;
char simbolo, simbolo_2;

cout << "Numero de filas: ";
cin >> filas;

cout << "Caracteres para pintar: ";
cin >> simbolo >> simbolo_2;

cout << endl << "1. Triangulo invertido izquierda"
     << endl << "2. Triandulo invertido derecha"
     << endl << "3. Triangulo equilaterio"
     << endl << "Opcion: ";
cin >> opcion;
     
     switch(opcion){
         case 1: tri_izquierda(filas, simbolo, simbolo_2);
         break;
         
         case 2: tri_derecha(filas, simbolo, simbolo_2);
         break;
         
         case 3: tri_equilatero(filas, simbolo, simbolo_2);
         break;
         
         default:
             cout << endl << "Error! - Opcion Incorrecta!" << endl;
         
     }
    
    
}

int main(){



menu_tri();

return 0;

}
