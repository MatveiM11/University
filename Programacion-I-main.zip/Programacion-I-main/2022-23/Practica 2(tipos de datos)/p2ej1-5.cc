#include <iostream>
#include <cmath>

using namespace std;

float triangulo(float base, float altura); // *Declaration - Problema 2 - Area de un Triangulo
float ipoteca(float euros, float anos, float interes); // *Declaration - Problema 3
 float tres_var(float a, float b, float c); // *Declaration - Problema 4
int main()
{
    // Problema 1
    cout << "Problema 1" << endl;
    
    cout << "1) 8 / 16 * 7 = " << 8.0/16*7 << std::endl;
    cout << "2) 8.0 / 16 * 7 = " << 8.0/16*7 << endl;
    cout << "3) 5 resto 3 + 5 / 2 = " << 5%3+5/2 << endl;
    cout << "4) potencia (3, valor absoluto(-8))/(9.9-5*1.5) = " << pow(3,abs(-8))/(9.9-5*1.5) << std::endl;
    cout << "5) raiz(28) * 5 = " << std::sqrt(28)*5 << endl;


    // Problema 2 - Area de un Triangulp
    cout << "Problema 2 - Area de un Triangulo" << endl;
  
    float base, altura;
    cout << triangulo(base, altura) << endl;

    // Problema 3: Adquiriendo una vivienda
    cout << "Problema 3: Adquiriendo una vivienda" << endl;

    float euros, anos, interes;
    cout << ipoteca(euros, anos, interes) << endl;

    // Problema 4: Intercambiando valores de variables
    cout << "Problema 4: Intercambiando valores de variables" << endl;

    float a, b, c;
    cout << tres_var(a,b,c) << endl;

    return 0;
}


  // *Function - Problema 2 - Area de un Triangulo
  float triangulo(float base, float altura){
        cin >> base >> altura;
        return 0.5*base*altura;
    }

  // *Function - Problema 3: Adquiriendo una vivienda
  float ipoteca(float euros, float anos, float interes){
    float r, mensual;

    cin >> euros >> anos >> interes;
    r = interes/(100 * 12);
    mensual = (euros * r)/(1 - pow((1 + r), -12*anos));
    
    return mensual; 
  }

 // *Function - Problema 4: Intercambiando valores de variables

 float tres_var(float a, float b, float c) {
 
 cout << "Valor de a: ";
 cin >> a;

 cout << "Valor de b: ";
 cin >> b;

 cout << "Valor de c: ";
 cin >> c;



 return cout << endl << "Valores antes del intercambio: a=" << a << " b=" << b << " c=" << c;;

 }
