#include <iostream>
#include <cmath>
using namespace std;

void numSum(int); //declaring function


int main(){


int num;


cin >> num;

numSum(num);

    
}


//function
void numSum(int num, int powr){

    
int rest;
int sum = 0;
int counter1 = 0;
int counter2 = 0;
float = root;

while (rest != 0){

    rest =+ num%10;
    
    if(rest != 0){
        num =+ num/10;
        sum += rest;
        counter1++;
    
}
    
     if(powr < 0 and powr >= counter1){
         cout << "La posicion no es valida"
     } 


while (rest != 0 and powr >= 0 and powr <= counter1){

    rest =+ num%10;
    
    if(rest != 0){
        num =+ num/10;
        sum += rest;
        counter2++;
        if(counter2 == powr){
           sum =+ pow(sum, 1/root)
        }
        
        
}
    
}    
    cout << sum;

}
