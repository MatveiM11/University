#include <iostream>
#include <cmath>
using namespace std;

int main(){
int num;
float root;
int fin;


cin >> num >> root;

fin = pow(num, 1/root);

cout << fin;

    
}





