#include <iostream>
using namespace std;

void numSum(int); //declaring function


int main(){


int num;


cin >> num;

numSum(num);

    
}


//function
void numSum(int num){

    
int rest;
int sum = 0;



while (rest != 0){

    rest =+ num%10;
    
    if(rest != 0){
        num =+ num/10;
        sum += rest;
}
    
}    
    cout << sum;

}
