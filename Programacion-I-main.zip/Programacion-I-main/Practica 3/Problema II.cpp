#include <iostream>


using namespace std;

int main() {
int dist, max_veloc, tiempo = 0;
int veloc = dist/tiempo;
string = 
    cout << "Escribe un velocidad maximo)" << endl;
    cin >> veloc;
    cout << "Escribe una distancia entre de los camaras" << endl;
    cin >> dist;
    cout << "Escribe un tiempo de coche" << endl;
    cin >> dist;
    
    switch(veloc){
        case 'p': precio=1.75;
                break;
        case 'g': precio=2.20;
    }
    switch(toping){
        case 'f': precio+=0.5;
                break;
        case 'd': precio+=0.35;
                break;
        case 's': precio+=0.30;
    }
    cout << precio;
    
    return 0;
}
