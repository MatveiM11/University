#include <iostream>


using namespace std;

int main() {          
char color;
int blanco=0;
int negro=0;
while ( color !='.'){    
    cout << "Escribe un color de calcetin i si quires terminar escribe punto '.' " << endl;
    cin >> color;
    if (color == 'W') {
        blanco++;
    }
    else if(color =='B'){
        negro++;
    }
        
}
    
       if (blanco==negro && blanco>=2 && negro>=2){
        cout << "EMPAREJADOS";         
    }
    else if (blanco==negro && blanco==1 && negro==1){
        cout << "PAREJA MIXTA";         
    }
    else if (blanco%2==1 && negro>1){
        cout << "BLANCO SOLITARIO";         
    }
    else if (negro%2==1 && blanco>1){
        cout << "NEGRO SOLITARIO";         
    }
  
    
    return 0;
}
