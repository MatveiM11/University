#include <iostream>

#define precio_grande 2.20
#define precio_pequeno 1.75
#define precio_fruta 0.5
#define precio_dulce 0.35
#define precio_sirope 0.3
using namespace std;

int main() {
float precio = 0;           
char tamano;
char toping;
    cout << "Escribe un tamano de helado: Pequeno(p) o Grande(g)" << endl;
    cin >> tamano;
    cout << "Escribe un toping de helado: Fruta(f), Dulce(d) o Sirope(s)" << endl;
    cin >> toping;
    
    switch(tamano){
        case 'p': precio=precio_pequeno;
                break;
        case 'g': precio=precio_grande;
    }
    switch(toping){
        case 'f': precio+=precio_fruta;
                break;
        case 'd': precio+=precio_dulce;
                break;
        case 's': precio+=precio_sirope;
    }
    cout << precio;
    
    return 0;
}
