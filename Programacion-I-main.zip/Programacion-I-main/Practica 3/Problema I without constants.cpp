#include <iostream>


using namespace std;

int main() {
float precio = 0;           
char tamano;
char toping;
    cout << "Escribe un tamano de helado: Pequeno(p) o Grande(g)" << endl;
    cin >> tamano;
    cout << "Escribe un toping de helado: Fruta(f), Dulce(d) o Sirope(s)" << endl;
    cin >> toping;
    
    switch(tamano){
        case 'p': precio=1.75;
                break;
        case 'g': precio=2.20;
    }
    switch(toping){
        case 'f': precio+=0.5;
                break;
        case 'd': precio+=0.35;
                break;
        case 's': precio+=0.30;
    }
    cout << precio;
    
    return 0;
}
