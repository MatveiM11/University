
https://www.boolean-algebra.com/
