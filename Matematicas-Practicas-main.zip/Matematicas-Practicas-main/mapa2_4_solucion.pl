:- use_module('pl-man-game/main').


do(drop(right)):- see(normal, right,'U'), havingObject.
do(get(up)):- see(normal, up,'w').
do(get(left)):- see(normal, left,'l'),not(havingObject).
do(get(left)):- see(normal, left,'o'),not(havingObject).
do(get(left)):- see(normal, left,'r'),not(havingObject).
do(get(left)):- see(normal, left,'s'),not(havingObject).

do(drop(down)):-havingObject(appearance('l')).

do(drop(down)):-havingObject(appearance('r')).

do(move(right)):- see(normal, right,' '), havingObject(appearance('o')).
do(move(down)):- see(normal, down,' '), havingObject(appearance('o')).

do(move(up)):- see(normal, right,'#'),see(normal, left,'E'),not(see(normal, down, '.')),not(see(normal, up, '#')).

do(move(none)):- see(normal, left-down,'E').
do(move(none)):- see(normal, left-up,'E').
do(move(none)):- see(normal, left,'E'), not(see(normal, right, 'U')).
do(move(none)):- see(normal, right-up,'E').
do(move(none)):- see(normal, right,'E').

do(move(up)):- see(normal, right, 'U'), see(normal, left, 'E').
do(move(up)):- see(normal, right, 'U'), see(normal, left, '#'),not(see(normal, down, '.')).

do(move(left)):- see(normal, left,'.').
do(move(right)):- see(normal, right,'.').
do(move(down)):- see(normal, down,'.').
do(move(up)):- see(normal, up,'.').

do(move(right)):- see(normal, down,'#'), not(see(normal, right, 'U')).


do(move(left)):- see(normal, left,' ').
do(move(right)):- see(normal, right,' ').
