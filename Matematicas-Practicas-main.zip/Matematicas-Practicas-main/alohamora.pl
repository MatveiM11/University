:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.


do(get(down)):- see(normal,down,'!').
do(use(aLoHoM0ra,right)):- see(normal, right,'|').


do(move(none)):- see(normal, D,'E'),(D=up-right).
do(move(none)):- see(normal, D,'E'),all(D).



do(move(D)):- see(normal, D,'.'),all(D).


do(move(up)):- see(normal, right,'#'), havingObject.

do(move(right)):- see(normal, right,' '), havingObject.

do(move(down)):- see(normal, down,' ').
