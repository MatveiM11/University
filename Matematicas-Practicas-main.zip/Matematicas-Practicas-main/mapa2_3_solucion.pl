:-use_module('pl-man-game/main').


do(get(left)):-see(normal,left,'+').

do(drop(down)):-see(normal,left,'#'), see(normal,up,'.'),see(normal,right,' '),see(normal,down,' ').

do(move(left)):-see(normal,down,'#'), see(normal,up,'.'),see(normal,right,' ').
do(move(down)):-see(normal,left,'#'), see(normal,up,'.'),see(normal,right,' '),not(see(normal,down,'+')).

do(move(up)):-see(normal,right,'E'),not(see(normal,left,'.')).
do(move(up)):-see(normal,up,'.'),not(see(normal,left,'.')),not(see(normal,right,'#')).
do(get(right)):-see(normal,right,'+').

do(drop(up)):-see(normal,down,'E'),not(see(normal,up,'#')).
do(move(right)):-see(normal,down,'E').

do(move(right)):-see(normal,right,'.').


do(move(down)):-see(normal,down,'.').
do(move(down)):-see(normal,left,'#'),not(see(normal,down,'#')).

do(move(left)):-see(normal,left,'.').

do(move(left)):-see(normal,up,'E').

do(move(up)):-see(normal,right,'#').

do(move(down)):-see(normal,down,' '), see(normal,down,' ').

do(move(right)):-see(normal,right,' ').
