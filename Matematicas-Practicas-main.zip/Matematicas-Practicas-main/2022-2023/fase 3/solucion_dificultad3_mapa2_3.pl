:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.


:-dynamic status/1.

status(go_left).

%%% status: go left

st_do(go_left, move(none)):-see(normal, left, '.'), see(normal, left-up, '#'), see(normal, down, '#'), see(normal, down-right, '#'), retract(status(go_left)), assertz(status(go_left3)), writeln(3).


st_do(go_left, get(left)):- see(normal, left, 'v').
st_do(go_left, move(left)):- not(see(normal,left, '#')).

st_do(go_left, move(right)):-see(normal, left, '#'), retract(status(go_left)), assertz(status(go_right)).




%%%%%% status: go right

st_do(go_right, move(up)):-see(normal, right-up, '#'), see(normal, left-up, '#'), see(normal, up, ' '),  retract(status(go_right)), assertz(status(go_up)).

st_do(go_right, get(up)):- see(normal, up, 'v').
st_do(go_right, get(right)):- see(normal, right, 'v').
st_do(go_right, move(right)):- not(see(normal,right, '#')).


st_do(go_right, move(up)):-see(normal, right, '#'), see(normal, right-up, '.'), retract(status(go_right)), assertz(status(go_left)).

st_do(go_right, move(up)):-see(normal, right, '#'), retract(status(go_right)), assertz(status(go_left2)).


%%% status: go left
st_do(go_left2, get(left)):- see(normal, left, 'v').
st_do(go_left2, move(left)):- not(see(normal,left, '#')).


st_do(go_left2, move(up)):-see(normal, left, '#'), not(see(normal, up, '#')), retract(status(go_left2)), assertz(status(go_right)).
st_do(go_left2, move(right)):-see(normal, left, '#'), see(normal, up, '#'), retract(status(go_left2)), assertz(status(go_right)).


%%% go up 
st_do(go_up, use(up)):- see(normal, up, '*'), havingObject.
st_do(go_up, move(up)):- see(normal, up, ' ').

st_do(go_up, move(up)):- see(normal, up, '.'), retract(status(go_up)), assertz(status(go_left)).


%%%% go left3

st_do(go_left3, move(none)):- not(see(normal, left-down, 'E')).


st_do(go_left3, move(left)):-see(normal, left-down, 'E'), retract(status(go_left3)), assertz(status(go_down)), writeln('left'), writeln('E left-down').


%%% go down
st_do(go_down, move(none)):- see(normal, left-up, 'E').
st_do(go_down, move(none)):- see(normal, left, 'E').

st_do(go_down, move(right)):- see(normal, right, '.'), see(normal, left, '.').
st_do(go_down, move(left)):- see(normal, left, '.').
st_do(go_down, move(right)):- see(normal, right, '.').

st_do(go_down, move(down)):- see(normal, down, '.').
st_do(go_down, move(left)):- see(normal, left, ' ').
st_do(go_down, move(up)):- see(normal, up, '.').

st_do(go_down, move(up)):- see(normal, up, ' ').

st_do(go_down, move(right)):- see(normal, up, '#'), retract(status(go_down)), assertz(status(go_right2)).

%%% go go_right2
st_do(go_right2, move(left)):- see(normal, left, '.'), see(normal, right, '.').

st_do(go_right2, move(right)):- see(normal, right, '.').
st_do(go_right2, move(left)):- see(normal, left, '.').
st_do(go_right2, move(down)):- see(normal, down, '.').

st_do(go_right2, move(up)):- see(normal, up, '.').

st_do(go_right2, move(right)):- not(see(normal,right, '#')), see(normal, up, '#').

st_do(go_right2, move(right)):- see(normal, right-up, '.').

%%% Main rule
do(A) :- status(S), st_do(S, A).
