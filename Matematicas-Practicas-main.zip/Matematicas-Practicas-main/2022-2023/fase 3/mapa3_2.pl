%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% DIF:	2
%%% PT:	__:__	[STS: __:__]
%%%
%%% INDETERMINISMOS DE ESTE MAPA
%%%------------------------------------------------------------
%%% En este mapa los únicos objetos que varían su posición son
%%% las llaves semánticas de la sala inferior del mapa. Aparecen
%%% 4 llaves, de las cuales 1 es correcta y 3 incorrectas. Las
%%% 4 llaves pueden aparecer en cualquier posición de la sala
%%% inferior, pero nunca aparecerán 2 en el mismo sitio.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

map_format_version(1.0).
load_behaviour(entitySequentialMovement).
load_behaviour(basicDoorKey).
map([['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'],
['#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#'],
['#', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '.', '.', '#', '#', '.', '.', '.', '#'],
['#', '.', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '#', '#', '.', '.', '.', '.', '#'],
['#', '.', '.', '.', '.', '.', '#', '#', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '#'],
['#', '.', '.', '.', '.', '.', '.', '#', '#', ' ', '#', '#', '.', '.', '.', '.', '.', '.', '#'],
['#', '#', '#', '#', '¬', 'p', 'v', '¬', 'q', ' ', '(', 'q', '^', 'r', ')', '#', '#', '#', '#'],
['#', '#', '#', '#', '#', '#', '#', '#', '#', ' ', '#', '#', '#', '#', '#', '#', '#', '#', '#'],
['#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#'],
['#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#'],
['#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#'],
['#', '.', '.', '.', '.', '.', '.', '.', '.', ' ', '.', '.', '.', '.', '.', '.', '.', '.', '#'],
['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#']]).
map_size(19, 13).
num_dots(135).
pacman_start(9, 11).
initMap:- 
	user:writeln('PISTA: En la fbf falta algo para formar una FN Disyuntiva. Encuéntralo y abrirás la puerta FND'),
	addSolidObject('#'),
	addSolidObject('¬'),
	addSolidObject('p'), 
	addSolidObject('v'), 
	addSolidObject('q'), 
	addSolidObject('('), 
	addSolidObject('^'), 
	addSolidObject('r'), 
	addSolidObject(')'),
	% Llaves y puerta (llaves indeterministas)
	% Las llaves son ^,v,¬,+. Cada una de ellas puede aparecer en una de las filas 7,8,9 ó 10
	% Dentro de cada fila pueden aparecer en una columna del rango 1-17.
	randomPermutation([8,9,10,11], [Y1,Y2,Y3,Y4]),
	createGameEntity(OID_0, '^', object, rnd(1,17), Y1, inactive, norule, 
			[name('conjuntor'), solid(false), static(false), use_rule(basicDoorKey),
			description('Conjuntor'), appearance(attribs(bold, cyan, default))]),
	(entityLocation(OID_0,9,11,'^')->changeEntityLocation(OID_0,8,11,9,11);true), 
	createGameEntity(OID_1, 'v', object, rnd(1,17), Y2, inactive, norule, 
			[name('disyuntor'), solid(false), static(false), use_rule(basicDoorKey),
			description('Disyuntor'), appearance(attribs(bold, cyan, default))]), 	
	(entityLocation(OID_1,9,11,'v')->changeEntityLocation(OID_1,8,11,9,11);true),
	createGameEntity(OID_2, '¬', object, rnd(1,17), Y3, inactive, norule, 
			[name('negador'), solid(false), static(false), use_rule(basicDoorKey),
			description('Negador'), appearance(attribs(bold, cyan, default))]), 
	(entityLocation(OID_2,9,11,'¬')->changeEntityLocation(OID_2,8,11,9,11);true),
	createGameEntity(OID_3, '+', object, rnd(1,17), Y4, inactive, norule, 
			[name('sumador'), solid(false), static(false), use_rule(basicDoorKey),
			description('Sumador'), appearance(attribs(bold, cyan, default))]), 
	(entityLocation(OID_3,9,11,'+')->changeEntityLocation(OID_3,8,11,9,11);true),
	createGameEntity(OID_4, '*', object, 9, 6, inactive, norule, 
			[name('puerta_FND'), solid(true), static(true), use_rule(norule),
			description('Puerta FND'), appearance(attribs(normal, black, green))]), 
	basicDoorKey(init, OID_4, ['pl-man':destroyGameEntity(OID_4), 'pl-man':msgWindowWriteln('Correcto, es un disyuntor. Puedes pasar')],  [OID_1]),
	% Enemigos (deterministas)
	createGameEntity(EID_0, 'E', mortal, 1, 1, active, entitySequentialMovement, [appearance(attribs(bold, red, default))]), 
	createGameEntity(EID_1, 'E', mortal, 17, 5, active, entitySequentialMovement, [appearance(attribs(bold, red, default))]),
	entitySequentialMovement(init, EID_0, [ r,r,d,d,d,d,l,l,u,u,u,u ], []),
	entitySequentialMovement(init, EID_1, [ u,u,u,u,l,l,d,d,d,d,r,r ], []).

norule(_).
norule(_,_,_,_,_).
