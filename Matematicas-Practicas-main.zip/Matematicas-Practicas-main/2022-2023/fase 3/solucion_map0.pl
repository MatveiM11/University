:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.

do(use(right)):- havingObject(appearance('r')), see(normal,right, '|').

do(get(D)):-see(normal,D, 'r'), all(D).

do(move(D)):-see(normal,D, '.'), all(D).

do(move(down)):-see(normal, down , ' '), havingObject(appearance('r')).
do(move(right)):-see(normal, down , '#'), havingObject(appearance('r')).
