:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.


:-dynamic status/1.

status(go_left).

%%% status: go left

st_do(go_left, use(up)):-see(normal, up, '-'), havingObject, 
retract(status(go_left)), assertz(status(go_up)).

st_do(go_left, move(left)):-see(normal, left, ' ').
st_do(go_left, get(down)):-see(normal, down, 'n'), retract(status(go_left)), assertz(status(go_right)).
st_do(go_left, move(none)):-see(normal, down, ' '), retract(status(go_left)), assertz(status(go_right)).


%% status: go right

st_do(go_right, use(up)):-see(normal, up, '-'), havingObject, retract(status(go_right)), assertz(status(go_up)).

st_do(go_right, move(right)):-see(normal, right, ' ').
st_do(go_right, get(down)):-see(normal, down, 'n'), retract(status(go_right)), assertz(status(go_left)).
st_do(go_right, move(none)):-see(normal, down, ' '), retract(status(go_right)), assertz(status(go_left)).

%%%% status: go up

st_do(go_up, move(up)):- not(see(normal, up, '#')).



%%% Main rule
do(A) :- status(S), st_do(S, A).
