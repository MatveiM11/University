%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% DIF:	5
%%% PT:	__:__	[STS: __:__]
%%%
%%% INDETERMINISMOS DE ESTE MAPA
%%%------------------------------------------------------------
%%% En este mapa hay varios objetos indeterministas que se
%%% detallan a continuación:
%%% 1) Puertas:
%%%    Aparecen 4 puertas, una en cada una de las paredes que
%%%    da acceso a las 4 salas exteriores del mapa. Siempre hay
%%%    una puerta para cada zona, y siempre están en orden
%%%    y posiciones aleatorias.
%%% 2) Llaves:
%%%    En cualquier parte de la zona central aparece siempre la
%%%    llave naranja. Con esa llave se tendrá acceso a una de las
%%%    4 zonas exteriores. En esa zona habrá otra llave que dará
%%%    acceso, a su vez, a otra de las 4 zonas exteriores. 
%%%    En cada nueva zona que se abra siempre habrá una llave
%%%    para acceder a la zona siguiente. Las llaves aparecen 
%%%    aleatoriamente en cualquier posición de la zona donde
%%%    estén, siempre que en esa posición haya un coco.
%%%
%%% El resto de objetos en este mapa son deterministas
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

map_format_version(1.0).
load_behaviour(basicDoorKey).
load_behaviour(automaticArcher).
map([['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'],
['#', '#', ' ', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', ' ', '#', '#'],
['#', ' ', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', ' ', '#'],
['#', '.', '.', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '.', '.', '#'],
['#', '.', '.', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '.', '.', '#'],
['#', '.', '.', '#', '.', '.', '.', '.', '.', '.', ' ', '.', '.', '.', '.', '.', '.', '.', '#', '.', '.', '#'],
['#', '.', '.', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '.', '.', '#'],
['#', '.', '.', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '.', '.', '#'],
['#', ' ', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', ' ', '#'],
['#', '#', ' ', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', ' ', '#', '#'],
['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#']]).
map_size(22, 11).
num_dots(125).
pacman_start(10, 5).
initMap:- 
	addSolidObject('#'), 

	% Automatic Archers
	createGameEntity(OID_AR1, ')', object, 2, 1, active, automaticArcher, 
			[name(arquero1), solid(false), static(true), use_rule(norule),
			description('Arquero automatico del rey'), appearance(attribs(bold, yellow, default))]), 
	createGameEntity(OID_AR2, '^', object, 1, 8, active, automaticArcher, 
			[name(arquero2), solid(false), static(true), use_rule(norule),
			description('Arquero automatico del rey'), appearance(attribs(bold, yellow, default))]), 
	createGameEntity(OID_AR3, '^', object, 20, 8, active, automaticArcher, 
			[name(arquero3), solid(false), static(true), use_rule(norule),
			description('Arquero automatico del rey'), appearance(attribs(bold, yellow, default))]), 
	createGameEntity(OID_AR4, '(', object, 19, 9, active, automaticArcher, 
			[name(arquero4), solid(false), static(true), use_rule(norule),
			description('Arquero automatico del rey'), appearance(attribs(bold, yellow, default))]),
	automaticArcher(init, OID_AR1, ['@'], right, 6, [ continuous, bullet_appearance('>', bold, red, default) ]),
	automaticArcher(init, OID_AR2, ['@'],    up, 5, [ continuous, bullet_appearance('!', bold, red, default) ]),
	automaticArcher(init, OID_AR3, ['@'],    up, 7, [ continuous, bullet_appearance('!', bold, red, default) ]),
	automaticArcher(init, OID_AR4, ['@'],  left, 5, [ continuous, bullet_appearance('<', bold, red, default) ]),

	% Doors
	randomBetween(4,17,X1), randomBetween(4,17,X2), 
	randomBetween(4, 6,Y3), randomBetween(4, 6,Y4),
	setDCellContent( 3, Y3, ' '), setDCellContent(18, Y4, ' '), 
	setDCellContent(X1,  3, ' '), setDCellContent(X2,  7, ' '), 
	randomPermutation(
			[d(OID_BD, cyan, puerta_azul), d(OID_RD, red, puerta_roja), 
			 d(OID_OD, yellow, puerta_naranja), d(OID_MD, magenta, puerta_magenta)], 
			[d(OID1, C1, N1), d(OID2, C2, N2), d(OID3, C3, N3), d(OID4, C4, N4)]),
	createGameEntity(OID1, '|', object,  3, Y3, inactive, norule, 
			[name(N1), solid(true), static(true), use_rule(norule),
			description('Puerta'), appearance(attribs(normal, black, C1))]),
	createGameEntity(OID2, '|', object, 18, Y4, inactive, norule, 
			[name(N2), solid(true), static(true), use_rule(norule),
			description('Puerta'), appearance(attribs(normal, black, C2))]),
	createGameEntity(OID3, '-', object, X1,  3, inactive, norule, 
			[name(N3), solid(true), static(true), use_rule(norule),
			description('Puerta'), appearance(attribs(normal, black, C3))]),
	createGameEntity(OID4, '-', object, X2,  7, inactive, norule, 
			[name(N4), solid(true), static(true), use_rule(norule),
			description('Puerta'), appearance(attribs(normal, black, C4))]),

	% KEYS
	CL = [C1, C2, C3, C4],
	createGameEntity(OID_OK, 'n', object,  rnd(4,17), rnd(4,6), inactive, norule, 
			[name(llave_naranja), solid(false), static(false), use_rule(basicDoorKey),
			description('Llave que abre la puerta naranja. Se volatiliza al usarla.'), appearance(attribs(normal, yellow, default))]),
	nth1(Z1, CL, yellow), randZone(Z1, KX1, KY1),
	createGameEntity(OID_BK, 'a', object,  KX1, KY1, inactive, norule, 
			[name(llave_azul), solid(false), static(false), use_rule(basicDoorKey),
			description('Llave que abre la puerta azul. Se volatiliza al usarla.'), appearance(attribs(normal, cyan, default))]),
	nth1(Z2, CL, cyan), randZone(Z2, KX2, KY2),
	createGameEntity(OID_MK, 'm', object,  KX2, KY2, inactive, norule, 
			[name(llave_magenta), solid(false), static(false), use_rule(basicDoorKey),
			description('Llave que abre la puerta magenta. Se volatiliza al usarla.'), appearance(attribs(normal, magenta, default))]),
	nth1(Z3, CL, magenta), randZone(Z3, KX3, KY3),
	createGameEntity(OID_RK, 'r', object,  KX3, KY3, inactive, norule, 
			[name(llave_roja), solid(false), static(false), use_rule(basicDoorKey),
			description('Llave que abre la puerta roja. Se volatiliza al usarla.'), appearance(attribs(normal, red, default))]),
	basicDoorKey(init, OID_BD, [ 'pl-man':destroyGameEntity(OID_BD), 'pl-man':destroyGameEntity(OID_BK) ], [ OID_BK ]),
	basicDoorKey(init, OID_OD, [ 'pl-man':destroyGameEntity(OID_OD), 'pl-man':destroyGameEntity(OID_OK) ], [ OID_OK ]),
	basicDoorKey(init, OID_MD, [ 'pl-man':destroyGameEntity(OID_MD), 'pl-man':destroyGameEntity(OID_MK) ], [ OID_MK ]),
	basicDoorKey(init, OID_RD, [ 'pl-man':destroyGameEntity(OID_RD), 'pl-man':destroyGameEntity(OID_RK) ], [ OID_RK ]).
	
randZone(1, X, Y):- randomBetween( 1, 2,X), randomBetween(3,7,Y).
randZone(2, X, Y):- randomBetween(19,20,X), randomBetween(3,7,Y).
randZone(3, X, Y):- randomBetween( 3,18,X), randomBetween(1,2,Y).
randZone(4, X, Y):- randomBetween( 3,18,X), randomBetween(8,9,Y).

norule(_).
norule(_,_,_,_,_).
