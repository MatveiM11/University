:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.
puertas(P):- P='-'; P='|'.
llaves(L):- L ='a'; L='m';L='r'.

:-dynamic ope/1.
ope(0).

:-dynamic status/1.

:-dynamic cont/1.

cont(0).

status(go_up).

/* ejemplo
st_do(go_right, get(right)):- see(normal,right, N), number(N), ope(Z), N = Z.
*/


%%% status go up


st_do(go_up, get(D)):- see(normal,D, 'n'), all(D).

st_do(go_up, move(up)):- see(normal,up, '.').
st_do(go_up, move(down)):- see(normal,down, '.').
st_do(go_up, move(left)):- see(normal,left, '.').



st_do(go_up, move(right)):-not(see(normal, up, '.')),see(normal, right, ' '), see(normal, down, ' '), retract(status(go_up)), assertz(status(go_right)).

%%%%%% status: go right

st_do(go_right, get(D)):- see(normal,D, 'n'), all(D).

st_do(go_right, move(left)):-not(see(normal, up, '.')), not(see(normal, right, ' ')), not(see(normal, right, '.')),see(normal, left, ' '), see(normal, down, ' '), retract(status(go_right)), assertz(status(go_search)), writeln('right to search').

st_do(go_right, move(up)):- see(normal,up, '.').
st_do(go_right, move(down)):- see(normal,down, '.').
st_do(go_right, move(right)):- see(normal,right, '.').

st_do(go_right, move(down)):- see(normal,down, ' ').
st_do(go_right, move(right)):- see(normal,right, ' ').



%%%% status - go search

st_do(go_search, use(up)):- puertas(P), see(normal,up, P), havingObject, cont(N), N = 0, retract(cont(0)), assertz(cont(1)), writeln(1).
st_do(go_search, use(left)):- puertas(P), see(normal,left, P), havingObject, cont(N), N = 1, retract(cont(1)), assertz(cont(2)), writeln(2).
st_do(go_search, use(down)):- puertas(P), see(normal,down, P), havingObject, cont(N), N = 2, retract(cont(2)), assertz(cont(3)), writeln(3).
st_do(go_search, use(right)):- puertas(P), see(normal,right, P), havingObject, cont(N), N = 3, retract(cont(3)), assertz(cont(4)), writeln(4).

st_do(go_search, move(left)):- see(normal,left, ' '), not(see(normal,up, ' ')), havingObject.

st_do(go_search, move(down)):- see(normal,down, ' '), see(normal,right, ' '), not(see(normal, down-right, '#')), havingObject.


st_do(go_search, move(right)):- see(normal,right, ' '), not(see(normal,down, ' ')), havingObject.


st_do(go_search, move(up)):- see(normal,up, ' '), see(normal,left, ' '), havingObject.

%%% not havingObject

st_do(go_search, move(left)):- see(normal,left, ' '), see(normal,left-up, '#'), see(normal,left-down, '#'), not(havingObject).
st_do(go_search, move(right)):- see(normal,right, ' '), see(normal,right-up, '#'), see(normal,right-down, '#'), not(havingObject).
st_do(go_search, move(down)):- see(normal,down, ' '), see(normal,left-down, '#'), see(normal,right-down, '#'), not(havingObject).
st_do(go_search, move(up)):- see(normal,up, ' '), see(normal,left-up, '#'), see(normal,right-up, '#'), not(havingObject).

st_do(go_search, move(D)):-see(normal, D, '.'),all(D), retract(status(go_search)), assertz(status(go_outside)), writeln('from search to outside').

%%% status - go outside

%st_do(go_outside, move(D)):-see(normal, D, '.'),all(D).
st_do(go_outside, move(left)):-see(normal, down, '.'), retract(status(go_outside)), assertz(status(go_outside1)), writeln('from outside to outside1').
st_do(go_outside, move(left)):-see(normal, down, '<'), retract(status(go_outside)), assertz(status(go_outside1)), writeln('from outside to outside1').

% status - go outside1

st_do(go_outside1, move(right)):-see(normal, left-down, '#'), see(normal, down-right, '#'),not(see(normal, left, '.')), not(see(normal, down, '#')), retract(status(go_outside1)), assertz(status(go_search)), writeln('from outside1 to search').

st_do(go_outside1, get(D)):- see(normal,D, L), all(D), llaves(L).

st_do(go_outside1, move(up)):-see(normal, up, ' '),not(see(normal, left, '.')), not(see(normal, right, '.')), not(see(normal, down, '.')), havingObject.

st_do(go_outside1, move(left)):-see(normal, left, '.').
st_do(go_outside1, move(right)):-not(see(normal, right, '#')).

st_do(go_outside1, move(none)):-not(see(normal, left-down, '<')).

st_do(go_outside1, move(down)):-see(normal, left-down, '<').


%%% Main rule
do(A) :- status(S), st_do(S, A).
