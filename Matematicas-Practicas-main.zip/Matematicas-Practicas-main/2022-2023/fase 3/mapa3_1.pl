%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% DIF:	1
%%% PT:	00:30	[STS: 02:00]
%%%
%%% INDETERMINISMOS DE ESTE MAPA
%%%------------------------------------------------------------
%%% En este mapa sólo hay 1 ente indeterminista: Pl-Man. Pl-Man
%%% aparece siempre en la última fila del mapa (fila 6), pero
%%% en una columna aleatoria (columnas 1-13).
%%%
%%% El resto de objetos en este mapa son deterministas
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

map_format_version(1.0).
load_behaviour(basicDoorKey).
load_behaviour(automaticArcher).
load_behaviour(entitySequentialMovement).
map([['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'],
['#', ' ', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#'],
['#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', ' ', '#'],
['#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#'],
['#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#'],
['#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#'],
['#', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '#'],
['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#']]).
map_size(15, 8).
num_dots(50).
pacman_start(X, 6) :- randomBetween(1,13,X).

initMap:- 
	addSolidObject('#'), 
	
	% Automatic Archers
	createGameEntity(OID_AR1, ')', object, 1, 1, active, automaticArcher,
			[name(arquero1), solid(false), static(true), use_rule(norule),
			description('Arquero automatico del rey'), appearance(attribs(bold, yellow, default))]),
	createGameEntity(OID_AR2, '(', object, 13, 2, active, automaticArcher, 
			[name(arquero2), solid(false), static(true), use_rule(norule),
			description('Arquero automatico del rey'), appearance(attribs(bold, yellow, default))]), 
	automaticArcher(init, OID_AR1, ['@'], right, 5, [ continuous, bullet_appearance('>', bold, red, default) ]),
	automaticArcher(init, OID_AR2, ['@'],  left, 7, [ continuous, bullet_appearance('<', bold, red, default) ]),
 
	% ENEMIES
	ML0 = [ d,r,r,r,r,r,r,r,r,r,r,r,r,u,l,l,l,l,l,l,l,l,l,l,l,l ],
	shiftListLeft(ML0, 1, ML1), shiftListLeft(ML1, 6, ML2),
	shiftListLeft(ML2, 6, ML3), shiftListLeft(ML3, 1, ML4),
	shiftListLeft(ML4, 6, ML5), 
	createGameEntity(EID_0, 'E', mortal,  1, 4, active, entitySequentialMovement, [appearance(attribs(normal, red, default))]), 
	createGameEntity(EID_1, 'E', mortal,  1, 5, active, entitySequentialMovement, [appearance(attribs(normal, red, default))]), 
	createGameEntity(EID_2, 'E', mortal,  7, 5, active, entitySequentialMovement, [appearance(attribs(normal, red, default))]), 
	createGameEntity(EID_3, 'E', mortal, 13, 5, active, entitySequentialMovement, [appearance(attribs(normal, red, default))]),
	createGameEntity(EID_4, 'E', mortal, 13, 4, active, entitySequentialMovement, [appearance(attribs(normal, red, default))]), 
	createGameEntity(EID_5, 'E', mortal,  7, 4, active, entitySequentialMovement, [appearance(attribs(normal, red, default))]), 
	entitySequentialMovement(init, EID_0, ML0, [no_repeat_moves]),
	entitySequentialMovement(init, EID_1, ML1, [no_repeat_moves]),
	entitySequentialMovement(init, EID_2, ML2, [no_repeat_moves]),
	entitySequentialMovement(init, EID_3, ML3, [no_repeat_moves]),
	entitySequentialMovement(init, EID_4, ML4, [no_repeat_moves]),
	entitySequentialMovement(init, EID_5, ML5, [no_repeat_moves]).
	
norule(_).
norule(_,_,_,_,_).
