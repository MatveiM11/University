:-use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.


do(get(right)):- see(normal, right,'+').
do(get(down)):- see(normal, down,'+').
do(drop(up)):- see(normal, up-left,'#'), see(normal, left,' '), see(normal, down,'#'), see(normal, up,' '), not(see(normal, left,'+')), not(see(normal, right,'.')), havingObject.

do(get(left)):- see(normal, left-down,'.'), see(normal, left,'+').

do(drop(left)):- see(normal, up-left,'#'), see(normal, left,' '), see(normal, down,'E'), see(normal, down-left,'>'), not(see(normal, left,'+')), havingObject.

do(drop(up)):- see(normal, up-left,'#'), see(normal, left,'#'), see(normal, down,')'), see(normal, down-right,'>'), not(see(normal, up,'+')), havingObject.


do(move(none)):- see(normal, right-down,'E'), not(see(normal, left,'#')), not(see(normal, left,'+')).
do(move(none)):- see(normal, down,'E').
do(move(none)):- see(normal, down-left,'E').

do(move(down)):- see(normal, right,'E').


do(move(none)):- see(normal, right,'.'), see(normal, down,'>'), not(see(normal, left,'.')), not(havingObject).


do(move(right)):- see(normal, right,'.'), see(normal, left-down,'>'), see(normal, right-down,'#'), see(normal, right-up,'#').


do(move(right)):- see(normal, right,'.'), see(normal, right-down,'('), not(see(normal, down,'.')).
do(move(right)):- see(normal, right,'.'), see(normal, down,'('), see(normal, right-up,'#'), not(see(normal, down,'.')).


do(move(down)):- see(normal, down,'.').
do(move(up)):- not(see(normal, down,'.')), see(normal, up,' '), see(normal, right,'.').
do(move(up)):- not(see(normal, down,'.')), see(normal, up,'.'); see(normal, up-right,'.'), not(see(normal, up,'E')).
do(move(right)):- see(normal, right,'.').



do(move(right)):- see(normal, right-down,'.'), see(normal, up,'#'), not(see(normal, right,'#')).
do(move(left)):- see(normal, up,'#'), see(normal, left,' '), havingObject.


do(move(right)):- see(normal, up-left,'#'), see(normal, up,'+'), see(normal, down,'#'), not(havingObject).
do(move(right)):- see(normal, up-left,'+'), see(normal, up,' '), see(normal, down,'#'), not(havingObject).

/* left-gate*/
do(move(left)):- see(normal, left,'.'), see(normal, left-up,'#'), see(normal, left-down,'#').

do(move(down)):- see(normal, down,'.').
do(move(up)):- not(see(normal, down,'.')), see(normal, up,' '), see(normal, left,'.').
do(move(up)):- not(see(normal, down,'.')), see(normal, up,'.'); see(normal, up-left,'.').
do(move(left)):- see(normal, left,'.').
do(move(left)):- see(normal, left,'*').

do(move(left)):- see(normal, left-down,')'), see(normal, down,'>').

do(move(up)):- see(normal, left,'>').


do(move(up)):- see(normal, up,' '), see(normal, left,'#'), not(havingObject).
/*left*/

do(move(down)):- see(normal, down,' ').
do(move(left)):- see(normal, down,'#'), not(see(normal, left,'#')), havingObject.

do(move(left)):- see(normal, down,'#'), see(normal, left,' '), not(havingObject).
do(move(up)):- see(normal, down,'#'), see(normal, up-left,'.'), not(havingObject).


do(move(right)):- see(normal, left-down,'>'), see(normal, right-down,'E').


do(move(right)):- see(normal, down,')'), see(normal, up,'+').


do(move(up)):- see(normal, up,'*').


do(move(none)).


