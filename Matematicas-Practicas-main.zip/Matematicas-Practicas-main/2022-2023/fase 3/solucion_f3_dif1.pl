:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.


:-dynamic status/1.

status(go_left).

%%% status: go left

st_do(go_left, move(none)):-see(normal, up, 'E'), see(normal, left, '#').

st_do(go_left, move(left)):-see(normal, left, ' ').
st_do(go_left, move(up)):-see(normal, up, '.'), see(normal, up-right, 'E'), retract(status(go_left)), assertz(status(go_right)).
st_do(go_left, move(none)).


%% status: go right -> go left '.'

st_do(go_right, move(left)):-see(normal, left, '.').

st_do(go_right, move(right)):-see(normal, right, '.').
st_do(go_right, move(up)):-see(normal, up, '.').
st_do(go_right, move(left)):-see(normal, left, '.').

st_do(go_right, move(up)):-see(normal, left, '#'), see(normal, up, ' '), retract(status(go_right)), assertz(status(go_up)).



%%%% status: go up

st_do(go_up, move(right)):- see(normal, right-up, '.'), see(normal, up, ')'), retract(status(go_up)), assertz(status(fin_up)).


st_do(go_up, move(none)):- see(normal, up-right, '('), see(normal, up, '<').
st_do(go_up, move(left)):- see(normal, up, '('), see(normal, up-left, '.').
st_do(go_up, move(left)):- see(normal, up, '('), see(normal, up-left, '<').
st_do(go_up, move(up)):- see(normal, up-right, '('), see(normal, up-left, '<').

st_do(go_up, move(left)):-see(normal, left, '.').

st_do(go_up, move(up)):- see(normal, up, ' ').
st_do(go_up, move(right)):- see(normal, right, ' ').


%%%%%%%% status: fin up
st_do(fin_up, move(none)):- see(normal, left-up, ')'), see(normal, right, ' '), see(normal, up, '>').
st_do(fin_up, move(up)):- see(normal, left-up, ')'), see(normal, right, ' '), see(normal, up, '.').
st_do(fin_up, move(right)):- see(normal, right, '.').



%%% Main rule
do(A) :- status(S), st_do(S, A).
