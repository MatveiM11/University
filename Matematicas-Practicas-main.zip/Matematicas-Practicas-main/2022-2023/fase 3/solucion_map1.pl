:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.


:-dynamic status/1.

status(go_up).

%%% status: go up
st_do(go_up, move(up)):-see(normal, up, ' ').
st_do(go_up, move(left)):-see(normal, left, ' ').

st_do(go_up, move(none)):- retract(status(go_up)), assertz(status(go_right)).

%%% status: go right
st_do(go_right, get(right)):-see(normal, right, 'a').
st_do(go_right, move(right)):-see(normal, right, ' ').
st_do(go_right, move(none)):- retract(status(go_right)), assertz(status(go_down)).

%%%% status: go down and left
st_do(go_down, use(up)):-see(normal, up, '-'), retract(status(go_down)), assertz(status(go_up_2)).
st_do(go_down, move(down)):-see(normal, down, ' ').
st_do(go_down, move(left)):-see(normal, left, ' ').

%%%% status: go up
st_do(go_up_2, move(right)):-see(normal, right, '.').
st_do(go_up_2, move(D)):-see(normal, D, '.'), all(D).


%%% Main rule
do(A) :- status(S), st_do(S, A).
