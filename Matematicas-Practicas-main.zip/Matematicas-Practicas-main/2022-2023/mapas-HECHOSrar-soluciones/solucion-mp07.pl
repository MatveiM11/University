:-use_module('pl-man-game/main').

do(get(right)):-see(normal,right,'L').

