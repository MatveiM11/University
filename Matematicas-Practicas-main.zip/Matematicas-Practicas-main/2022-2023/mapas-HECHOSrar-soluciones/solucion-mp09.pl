:-use_module('pl-man-game/main').

do(get(left)):-see(normal,left,'h').

