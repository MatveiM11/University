:-use_module('pl-man-game/main').

do(use(up)):-see(normal,up,'E').
do(move(up)).
