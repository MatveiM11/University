:-use_module('pl-man-game/main').

do(drop(up)):-see(normal,down,'#').
do(move(down)).
