:-use_module('pl-man-game/main').

do(get(down)):-see(normal,down,'h').

