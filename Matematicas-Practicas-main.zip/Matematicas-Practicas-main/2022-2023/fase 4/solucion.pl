:- use_module('pl-man-game/main').
sl(DIR,LIST):- see(list,DIR,LIST).
all(D) :- D=down; D=right;D=left;D=up.


:-dynamic status/1.

status(go_down).





%%% go_down

st_do(go_down, move(up)):- see(normal, left, '>').
st_do(go_down, move(none)):- see(normal, right-down, '<'); see(normal, left-down, '>');
see(normal, down, '<'); see(normal, down, '>').

st_do(go_down, move(up)):- sl(left,L),nth0(POS,L,'>'),POS=1.

st_do(go_down, move(down)):- not(see(normal, down, '#')),  not(see(normal, down, '<')),  not(see(normal, down, '>')), not(see(normal, down-left, '#')), not(see(normal, down-right, '#')).

st_do(go_down, move(none)):- see(normal, down, '#'), retract(status(go_down)), assertz(status(go_left)), writeln('down to left').

st_do(go_down, move(none)):- see(normal, down, ' '), retract(status(go_down)), assertz(status(go_left)), writeln('down to left').

%%% status: go_left

/*case end left*/

st_do(go_left, move(none)):- not(see(normal, down, '.')),sl(left,R),nth0(2,R,'#'),
retract(status(go_left)), assertz(status(go_right)), writeln('left to right').



st_do(go_left, move(none)):- sl(left,R),nth0(1,R,'#'),
retract(status(go_left)), assertz(status(go_right)), writeln('left to right').



/*case left(>), up(<), right-up( )*/

st_do(go_left, move(right)):- see(normal, left, '>'), see(normal, up, '<'), see(normal, up-right, ' ').

/*case left(>), up( ), right-up(<)*/

st_do(go_left, move(right)):- see(normal, left, '>'), see(normal, up, ' '), see(normal, up-right, '<').

/*case up(.), down(.), right(<)*/

st_do(go_left, move(down)):- see(normal, right, '<'), see(normal, up, '.'), see(normal, down, '.').

/*case up(.), down(.), left(>)*/

st_do(go_left, move(down)):- see(normal, left, '>'), see(normal, up, '.'), see(normal, down, '.').

/*case )..@< */

st_do(go_left, move(down)):- sl(left,L), nth0(POS,L,')'), POS=2, see(normal, right, '<'), not( see(normal, down, '#')).

/*case >.@< */

st_do(go_left, move(up)):- sl(left,L), nth0(POS,L,'>'), POS=1, see(normal, right, '<').

/*case up(>), right(<)*/

st_do(go_left, move(left)):- see(normal, right, '<'), see(normal, up, '>').

/*end left*/

st_do(go_left, move(up)):- see(normal, right, '<'), see(normal, left, ' ');
see(normal, right, '<'), see(normal, left, ')').
st_do(go_left, move(right)):- see(normal, down, '<'), see(normal, left, ' ');
see(normal, down, '<'), see(normal, left, ')').

/*case >@<*/

st_do(go_left, move(up)):- see(normal, left, '>'), see(normal, right, '<').

/**/
st_do(go_left, move(left)):- see(normal, right, '<').

st_do(go_left, move(up)):- see(normal, left, '>').
st_do(go_left, move(left)):- see(normal, down, '>'), not(see(normal, down-left, ' ')).

st_do(go_left, move(down)):- not(see(normal, down, '#')), not(see(normal, down, '<')),
not(see(normal, down, '>')), not(see(normal, down-right, '<')), sl(down,L), nth0(POS,L,'#'), POS<3.


/*case no arrows at first stage*/

st_do(go_left, move(left)):- see(normal, up, '<'), see(normal, left, '.'),
not(sl(left,L)), nth0(POS,L,'<'), POS>0.


/**/

st_do(go_left, move(none)).

%%% status: go_right

/*start right*/

st_do(go_right, move(right)):- not(see(normal, right, '<')), sl(left,L), nth0(POS,L,'#'), POS=1.

/*case - up-right(>) */

st_do(go_right, move(right)):- see(normal, up-right, '>').

/*case - @< */

st_do(go_right, move(up)):- see(normal, right, '<').
st_do(go_right, move(down)):- not(see(normal, down, '#')), not(see(normal, down, '<')),
not(see(normal, down, '>')), not(see(normal, down-right, '<')), sl(down,L), nth0(POS,L,'#'), POS<3.

/*case - >@ */

st_do(go_right, move(right)):- see(normal, left, '>').

/**/
st_do(go_right, move(none)).


%%% Main rule
do(A) :- status(S), st_do(S, A).
