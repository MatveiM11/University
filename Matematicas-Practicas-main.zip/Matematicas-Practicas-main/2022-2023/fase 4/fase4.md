```bash
./launch 25   mapa4_2.pl solucion.pl   # tests
./plman   -r logs/log_ejecucion_13     # replay logs
```
