/* HABITANTES EN LAS PROVINCIAS */

prov_cv(alicante).
prov_cv(castellon).
prov_cv(valencia).

prov_cv(granada).
prov_cv(servilla).

prov_cv(murcia).

/* hab(provincia, numh_hab). */
hab(alicante,1934).
hab(castellon,604).
hab(valencia,2578).
hab(murcia,2010).
hab(granada,3100).
hab(servilla,4100).


/* cd Documentos
   swipl -f ejer1.pl
   prov_cv(P)
   hab(alicante,H).
   prov_cv(alicante),hab(alicante,H).
   prov_cv(P),hab(P,H).
*/

/* Superficie de las provincias*/

sup(alicante, 5815).
sup(castellon, 6632).
sup(valencia, 10763).
sup(murcia, 15800).
sup(granada, 20500).

/*

consult('ejer1.pl').
sup(alicante, S), S>7000.

*/

/*Superficie mas de 700 km2*/

sup_7m(P,S):-sup(P,S),S>7000.
