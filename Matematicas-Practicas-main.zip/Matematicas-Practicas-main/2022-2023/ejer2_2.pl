/*Personas*/

pers(carlos).
pers(ana).
pers(luis).
pers(eve).

/*Salario*/

sal(carlos, 2000).
sal(ana, 1000).
sal(luis, 1500).
sal(eve, 2500).

/*Gastos*/

gast(carlos, 1500).
gast(ana, 1000).
gast(luis, 2000).
gast(eve, 500).

/*Resultado neto salario-gasots*/

neto(P,N):-sal(P,S),gast(P,G), N is S-G.

/*

    neto(luis,D), write('La suma Neto'), write(D).

*/

class(P,C):-sal(P,S),gast(P,G), N is S-G, N == sal -> writeln('mismo').
