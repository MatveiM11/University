:-use_module('pl-man-game/main').

do(drop(right)):- see(normal, left,'#').

