:-use_module('pl-man-game/main').

do(use(down)):- see(normal, down,'E').
do(move(down)).

