%prueba5
map_format_version(1.1).
load_behaviour(cauldron).
load_behaviour(basicTeletransport).
load_behaviour(enemyBasicMovement).
load_behaviour(gunBasic).



map([
 '########################################################'
,'# ........... # .......................................#'
,'# .....#......###. .###. .###. .###. .###. .###. .#### #'
,'# .....#......#..###...###...###...###...###...###.....#'
,'# .....#......#........................................#'
,'########################################################'
,'################################-1. ??w ################'
,'################################ 2. ?   EN 1 ###########'
,'########################################################'
]).

map_size(56, 9).
num_dots(157).
pacman_start(1, 4).

initMap:- 
  maplist(write,  ['You are at the bottom of the Pharaoh Llorens Pyramid. '
                  ,'The sarcophagus chamber is locked. Brew up the ancient '
                  ,'vanishing potion with the ingredients that complete the '
                  ,'logic hieroglyphic carved in the stonewall. Drop items '
                  ,'into the cauldron in the logic order.']),
  createGameEntity(EID_P1, '?', object, 36, 6, inactive, norule, 
               [name(?), solid(true), static(false), appearance(attribs(normal, black, yellow)),
                description('part 1')]),    
  createGameEntity(EID_P2, '?', object, 37, 6, inactive, norule, 
               [name(?), solid(true), static(false), appearance(attribs(normal, black, yellow)),
                description('part 2')]),    
  createGameEntity(EID_P3, '?', object, 36, 7, inactive, norule, 
               [name(?), solid(true), static(false), appearance(attribs(normal, black, yellow)),
                description('part 3')]),    


	addSolidObject('#'),
 
	createGameEntity(_, '¬', object, 48, 2, inactive, norule, 
                [name(negator), solid(true), static(false), appearance(attribs(normal, green, default)),
                description('Nether Negator One')]),
	createGameEntity(_, 'w', object, 18, 2, inactive, norule, 
                [name(melon), solid(true), static(false), appearance(attribs(normal, yellow, default)),
                description('Shimmering watermelon')]),
  createGameEntity(_, 'r', object, 30, 2, inactive, norule, 
               [name(redstone), solid(true), static(false), appearance(attribs(normal, red, default)),
                description('redstone')]),
  createGameEntity(_, 'c', object, 24, 2, inactive, norule, 
               [name(carrot), solid(true), static(false), appearance(attribs(normal, cyan, default)),
                description('golden carrot ')]),
  createGameEntity(_, '¬', object, 42, 2, inactive, norule, 
                [name(negator), solid(true), static(false), appearance(attribs(normal, magenta, default)),
                description('Nether Negator Two')]),
  createGameEntity(_, 'l', object, 36, 2, inactive, norule, 
                [name(powder), solid(true), static(false), appearance(attribs(normal, yellow, default)),
                description('Luminous stone powder')]),

  createGameEntity(OID_TT, '?', object, 13, 1, active, basicTeletransport, 	
  [name(teletransporte), solid(false), static(true), use_rule(norule),
  description('Teletransporte'), appearance(attribs(normal,black,green))]),
  basicTeletransport(init, OID_TT, from(13,1), to(15,1), ['@'], []),
 

  cauldron(create(OID_C, 54, 2, [])),
  cauldron(newRecipe(OID_C,  434165666  ,  1, [ 'pl-man':cauldronFinish(OID_C, EID_P1, EID_P2, EID_P3, 1) ])),
  hieroglyphic(create(OID_C, [EID_P1, EID_P2, EID_P3])).
      

cauldronFinish(OID_C, EID_P1, EID_P2, EID_P3, 1) :-
    maplist(write, ['POP! A gun has appeared at the entry to the chamber\n']),

    cauldron(destroy(OID_C)), 
    destroyGameEntity(OID_C),
    createGameEntity(OID_G1, '¬', object, 15, 1, inactive,norule ,
		[name(gun), solid(false), static(false), use_rule(gunBasic),
		description('Gun with 7 bullets that dissapear'), appearance(attribs(bold, yellow, default))]),
	  gunBasic(init, OID_G1, 7, ['E'], destroy),

    changeEntityAppearance(EID_P1, '¬', bold, white, cyan),
    changeEntityAppearance(EID_P2, '¬', bold, white, cyan),
    changeEntityAppearance(EID_P3, 'w', bold, white, cyan),

    createGameEntity(EID, 'E', mortal, 20, 4, active, enemyBasicMovement,[appearance(attribs(normal,red,default))]), 
    enemyBasicMovement(init, EID, right-left, ['#']),
    createGameEntity(EID2, 'E', mortal, 24, 4, active, enemyBasicMovement,[appearance(attribs(normal,red,default))]), 
    enemyBasicMovement(init, EID2, left-right, ['#']),
    createGameEntity(EID3, 'E', mortal, 28, 4, active, enemyBasicMovement,[appearance(attribs(normal,red,default))]), 
    enemyBasicMovement(init, EID3, right-left, ['#']),
    createGameEntity(EID4, 'E', mortal, 32, 4, active, enemyBasicMovement,[appearance(attribs(normal,red,default))]), 
    enemyBasicMovement(init, EID4, left-right, ['#']),
    createGameEntity(EID5, 'E', mortal, 36, 4, active, enemyBasicMovement,[appearance(attribs(normal,red,default))]), 
    enemyBasicMovement(init, EID5, right-left, ['#']),
    createGameEntity(EID6, 'E', mortal, 40, 4, active, enemyBasicMovement,[appearance(attribs(normal,red,default))]), 
    enemyBasicMovement(init, EID6, left-right, ['#']),
    createGameEntity(EID7, 'E', mortal, 44, 4 , active, enemyBasicMovement,[appearance(attribs(normal,red,default))]), 
    enemyBasicMovement(init, EID7, right-left, ['#']).
    
:- dynamic d_hieroglyphic/5.
hieroglyphic(init, EID_S, EID_C, L_PARTS) :-
    retractall(d_hieroglyphic(_,_,_,_,_))
  , assert(d_hieroglyphic(EID_S, EID_C, L_PARTS, _, _)).

hieroglyphic(init, EID_S, EID_C, L_PARTS, OID_ING, AP_ING) :-
    retractall(d_hieroglyphic(_,_,_,_,_))
  , assert(d_hieroglyphic(EID_S, EID_C, L_PARTS, OID_ING, AP_ING)).

hieroglyphic(ingredient_dropped, _, _, _, _, []) :- !.
hieroglyphic(ingredient_dropped, _, EID_C, OID_ING, _, _) :-
    not(aliveEntity(OID_ING))
  , entityLocation(EID_C, XC, YC, _)
  , entityType(EID_PLMAN, pacman)
  , entityLocation(EID_PLMAN, XP, YP, _)
  , DX is abs(XP - XC)
  , DX > 1
  , DY is abs(YP - YC)
  , DY > 1
  , !.
hieroglyphic(ingredient_dropped, EID_S, EID_C, _, AP_ING, [EID_P1 | L_PARTS]) :-
    hieroglyphic(init, EID_S, EID_C, L_PARTS)
  , aliveEntity(EID_C)
  , changeEntityAppearance(EID_P1, AP_ING, bold, white, black).

hieroglyphic(update, _, _, [], _, _) :- !.
hieroglyphic(update, EID_S, EID_C, L_PARTS, OID_ING, AP_ING) :- 
    number(OID_ING)
  , !
  , not(isObjectGot(OID_ING))
  , hieroglyphic(init, EID_S, EID_C, L_PARTS)
  , hieroglyphic(ingredient_dropped, EID_S, EID_C, OID_ING, AP_ING, L_PARTS).
hieroglyphic(update, EID_S, EID_C, L_PARTS, OID_ING, _) :- 
    var(OID_ING)
  , isObjectGot(OID_ING)
  , entityLocation(OID_ING, _, _, Ap)
  , hieroglyphic(init, EID_S, EID_C, L_PARTS, OID_ING, Ap).

hieroglyphic(create(EID_C, L_PARTS)) :-
    createGameEntity(EID_S, '', object, 0, 0, active, hieroglyphic, 
        [name(hieroglyphic), solid(true), static(true), appearance(attribs(normal, black, yellow)),
         description('Hieroglyphic supervisor')])
  , hieroglyphic(init, EID_S, EID_C, L_PARTS).

hieroglyphic(EID) :-
    d_hieroglyphic(EID, EID_C, L_PARTS, OID_ING, AP_ING)
  , hieroglyphic(update, EID, EID_C, L_PARTS, OID_ING, AP_ING).

