:-use_module('pl-man-game/main').

do(get(right)):- see(normal, right, 'a').
do(use(left)):- see(normal, left, '|'), havingObject(appearance('a')).


do(move(left)):- havingObject(appearance('a')).

do(move(right)):- see(normal, right, ' ').
