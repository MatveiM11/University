:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.

do(move(none)):-see(normal, here, '?').

do(get(down)):-see(normal, down, 'w'),not(see(normal, down-right, '¬')), not(see(normal, right, '#')), not(havingObject).
do(get(down)):-see(normal, down, '¬'), not(see(normal, right, '#')), not(havingObject).
do(get(left)):-see(normal, left, '¬'), not(havingObject).



do(use(down)):-see(normal, down, 'E').
do(use(left)):-see(normal, down, '#'), see(normal, right, ' '), see(normal, up, '#'), see(normal, left, '.'), havingObject(appearance('¬')).

do(move(down)):-see(normal, down-left, '.'), see(normal, left, '#'), see(normal, down , ' ').




do(move(down)):-see(normal, down, ' '), see(normal, right, '#'), havingObject(appearance('¬')).


do(drop(down)):-see(normal, down-right, '¬'), havingObject(appearance('w')).
do(drop(down)):-see(normal, down, 'U'), havingObject.

do(move(up)):-see(normal, up, '?'), not(see(normal, up, '#')).

do(move(up)):-see(normal, up, '.').
do(move(down)):-see(normal, down, '.').
do(move(right)):-see(normal, right, '.').

do(move(up)):-see(normal, up-right, '.').


do(move(D)):-see(normal,D, '.'), all(D).

do(move(left)):-see(normal, left, ' '), not(havingObject), not(see(normal, left, '#')).
do(move(right)):-see(normal, right, ' '), havingObject.



do(move(up)):-see(normal, up, ' '), havingObject(appearance('w')).
