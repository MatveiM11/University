:-use_module('pl-man-game/main').

do(get(right)):- see(normal, right, 'a'), not(havingObject(appearance('r'))).
do(use(right)):- see(normal, right, '|'), havingObject(appearance('a')).


do(drop(left)):- see(normal, up, 'r'), havingObject(appearance('a')).
do(get(up)):- see(normal, up, 'r').
do(use(right)):- see(normal, right, '|'), havingObject(appearance('r')).


do(move(right)):- see(normal, right, '.'), havingObject(appearance('r')).
do(move(left)):- see(normal, left, ' '), havingObject(appearance('r')); see(normal, left, 'a'), havingObject(appearance('r')).
do(move(up)):- see(normal, up, ' '), havingObject(appearance('r')), not(see(normal, up, '#')).



do(move(left)):- see(normal, left, ' '), havingObject(appearance('a')), not(see(normal, down, '#')).
do(move(down)):- see(normal, left, '#'), havingObject(appearance('a')), not(see(normal, down, '#')).


do(move(right)):- see(normal, right, ' '),  see(normal, down, '#').
do(move(up)):- see(normal, up, ' ').
