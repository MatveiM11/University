:-use_module('pl-man-game/main').

do(get(left)):- see(normal, left, 'U').

do(get(left)):- see(normal, left, 'V'), see(normal, right, 'U').
do(drop(right)):- see(normal, left, 'V').

do(move(left)).





