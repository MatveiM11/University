 :-use_module('pl-man-game/main').

do(move(down)):- see(normal, down, '.').

do(move(left)):- see(normal, left, ' '), see(normal, up, ' '), see(normal, down, '#'), see(normal, right, ' '), not(see(normal, right-up, '.')).
do(move(left)):- see(normal, left, ' '), see(normal, up, ' '), see(normal, down, '#'), see(normal, right, '#'), not(see(normal, right-up, '.')).

do(move(left)):- see(normal, left, '.'), see(normal, up, ' '), see(normal, down, '#'), see(normal, right, ' '), not(see(normal, right-up, '.')).
do(move(left)):- see(normal, left, ' '), see(normal, up, '#'), see(normal, down, '#'), see(normal, right, ' '), not(see(normal, right-up, '.')).

do(move(down)):- see(normal, down-left, '.'), see(normal, right-down, ' '), not(see(normal, up, '.')),  writeln('12').
do(move(down)):- see(normal, down-left, '#'), see(normal, right, ' '), not(see(normal, down, '#')), not(see(normal, up, '.')),  writeln('13').

do(move(left)):- see(normal, up-left, '#'), see(normal, up-right, '#'), see(normal, left, '.'), see(normal, left-down, '.'), see(normal, up, '#'), writeln('17').
do(move(up)):- see(normal, up, ' '),  writeln('16').
do(move(right)):- see(normal, right, '.').


do(move(up)):- see(normal, up, '.').
do(move(down)):- see(normal, down, ' ').
do(move(left)):- see(normal, left, '.').
