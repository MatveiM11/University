:-use_module('pl-man-game/main').

do(get(down)):- see(normal, down, 'w').
do(drop(down)):- see(normal, down, 'U').

do(move(up)):- see(normal, left, 'E').
do(move(down)):- see(normal, right, 'E'),not(see(normal, down, '#')).
do(move(right)):- see(normal, right-down, 'E').
do(move(down)):- see(normal, left-up, 'E'), see(normal, left-down, 'E').


do(move(left)):- see(normal, left-down, '.'),see(normal, down, 'E').

do(move(left)):- see(normal, left, '.').
do(move(right)):- see(normal, right-down, '.').
do(move(down)):- see(normal, down, '.'),not(see(normal, right, '.')),not(see(normal, right-down, 'E')).

do(move(up)):- see(normal, up, '.'),not(see(normal, left-up, 'E')).

do(move(left)):- see(normal, left-up, '#'),see(normal, left-down, '#'),not(see(normal, right, '.')),not(see(normal, left, '#')).

do(move(right)):- see(normal, right, '.').


do(move(right)):- see(normal, right-up, 'E'), see(normal, down, '#'),not(see(normal, right, 'E')).

do(move(right)):- see(normal, left-up, 'E'), see(normal, down, '#'),not(see(normal, right, 'E')).


do(move(left)):- see(normal, right, 'E').

do(move(right)):- see(normal, right, ' '), see(normal, up, ' '), see(normal, left, ' '), see(normal, down, '#').
do(move(down)):- see(normal, right, ' '), see(normal, up, ' '), see(normal, left, ' '), see(normal, down, ' ').

do(move(up)):- see(normal, right, '#'), see(normal, up, ' '), see(normal, down, '#').
