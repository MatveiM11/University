
:-use_module('pl-man-game/main').

do(move(left)):- see(normal, right-down, 'E'), see(normal, left, '.').
do(move(left)):- see(normal, down, 'E'), see(normal, left, '.').

do(move(none)):- see(normal, right-down, 'E'), see(normal, left, '#').
do(move(none)):- see(normal, down, 'E'), see(normal, left, '#').

do(move(right)):- see(normal, right, '.').

do(move(right)):- see(normal, right, ' '), see(normal, left, ' '), see(normal, up, '#'), see(normal, down, ' ').

do(move(down)):- see(normal, down, ' '), see(normal, right, '#'), see(normal, left, ' ').
do(move(down)):- see(normal, down, '.'), see(normal, left-down, '#'), see(normal, left, ' '), see(normal, down, '.').

do(move(up)):- see(normal, right, ' '), see(normal, left, ' '), see(normal, up, ' '), not(see(normal, down, '.')).

do(move(left)):- see(normal, left, ' '), not(see(normal, up, '.')).

do(move(down)):- see(normal, down, '.'), not(see(normal, up, '.')).

do(move(up)):- see(normal, up, '.').

do(move(left)):- see(normal, left, '.').

do(move(down)):- see(normal, down, ' ').
