:-use_module('pl-man-game/main').

do(get(up)):- see(normal, up, 'k').



do(move(left)):- see(normal, left, '.'),see(normal, up, ' ').

do(move(up)):- see(normal, up, '.').
do(move(up)):- see(normal, right-up, '.'),not(see(normal, up, '#')).

do(move(right)):- see(normal, right, '.').

do(move(left)):- see(normal, left, '.'), writeln('Moving left').


do(move(down)):- see(normal, down, '.').
do(move(right)):- see(normal, down, '#'), not(see(normal,right,'#')).

do(move(up)):- see(normal, up, ' ').

do(use(up)):- see(normal, up, '-').
