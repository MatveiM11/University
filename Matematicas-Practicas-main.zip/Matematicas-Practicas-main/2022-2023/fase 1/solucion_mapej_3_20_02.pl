:-use_module('pl-man-game/main').

do(get(down)):- see(normal, down, 'a'), not(see(normal, left, '.')).

do(use(up)):- see(normal, up, '-').

do(move(none)):- see(normal, right-down, 'E');see(normal, down, 'E').

do(move(up)):- see(normal, right, 'a').
do(move(right)):- see(normal, right-down, 'a'), not(see(normal, left, '.')).

do(drop(down)):- not(see(normal, right-up, '#')), see(normal, left-up, '#'), see(normal, up, '#'), see(normal, down-right, '.'),see(normal, left, '.'), not(see(normal, down, 'a')).

do(move(right)):- see(normal, right, '.').

do(move(left)):- see(normal, left, '.').

do(move(down)):- see(normal, right, '#'), not(see(normal, up, '.')).

do(move(down)):- see(normal, down, '.'), not(see(normal, right-down, 'E')).

do(drop(left)):- see(normal, up, ' '),not(see(normal, left, 'a')).
do(move(up)):- see(normal, up, ' ').


do(move(up)):- see(normal, up, '.').
