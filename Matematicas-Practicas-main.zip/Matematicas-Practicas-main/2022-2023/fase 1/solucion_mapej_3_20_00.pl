:-use_module('pl-man-game/main').

do(get(up)):- see(normal, up, 'k').

do(move(left)):- see(normal, left, '_').

do(move(up)):- see(normal, right, 'E').
do(move(right)):- see(normal, down, 'E').

do(move(left)):- see(normal, left, '.'),see(normal, up, ' ').

do(move(up)):- see(normal, up, '.').
do(move(up)):- see(normal, right-up, '.'),not(see(normal, up, '#')).

do(move(right)):- see(normal, right, '.').

do(move(left)):- see(normal, left, '.'), writeln('Moving left').


do(move(down)):- see(normal, down, '.').

do(move(left)):- see(normal, up, '#'), see(normal, left, ' ').

do(move(down)):- see(normal, down, ' '), see(normal, right, ' '),see(normal, left, '#').

do(use(left)):- see(normal, left, '|').

do(move(up)):- see(normal, up, ' ').





