:-use_module('pl-man-game/main').

do(move(down)):- see(normal, down, '.'), see(normal, left-down, '#'), see(normal, up, '.'), see(normal, left, ' ').

do(move(up)):- see(normal, up, '.').
do(move(left)):- see(normal, left, '.').

do(move(down)):- see(normal, down, '.').

do(move(right)):- see(normal, right, '.').

do(move(right)):- see(normal, right, ' '), see(normal, left, '#'), see(normal, right-down, '#').
do(move(right)):- see(normal, right, ' '), see(normal, left, ' '), see(normal, right-down, ' '), see(normal, left-down, ' '), see(normal, down, '#').
do(move(right)):- see(normal, right, ' '), see(normal, left, ' '), see(normal, right-down, '.'), see(normal, left-down, '#'), see(normal, down, '#').
do(move(right)):- see(normal, right, ' '), see(normal, left, ' '), see(normal, right-down, ' '), see(normal, left-down, '#'), see(normal, down, '#'),  see(normal, up, '#').

do(move(down)):- see(normal, down, ' '), see(normal, right, '#'), see(normal, left, '#').


do(move(up)):- see(normal, right, '#'), see(normal, down, '#').
do(move(right)):- see(normal, down, '#'), not(see(normal, right-up, '#')).
do(move(right)):- see(normal, down, '#'), see(normal, right-up, '#'), see(normal, left-up, '#'), see(normal, up, ' ').

do(move(right)):- see(normal, right, ' '), see(normal, right-up, '#'), see(normal, right-down, '#'), see(normal, left, '#').

do(move(left)):- see(normal, left, ' '), see(normal, left-up, '#'), not(see(normal, right-down, '#')).

do(move(right)):- see(normal, right, ' '), see(normal, up, '#'), see(normal, right-down, '#').
