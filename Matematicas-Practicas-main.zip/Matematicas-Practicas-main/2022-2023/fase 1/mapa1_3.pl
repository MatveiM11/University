%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% DIF:	3-
%%% PT:	00:03	[STS: 00:09]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load_behaviour(pushBlocks).
map_format_version(1.0).
map([
['#', '#', '#', '#', '#', '#', '#'],
['#', ' ', ' ', ' ', ' ', ' ', '#'],
['#', '#', ' ', '#', ' ', '.', '#'],
['#', '.', '#', '#', ' ', '.', '#'],
['#', '.', '#', ' ', ' ', '.', '#'],
['#', '.', ' ', ' ', ' ', ' ', '#'],
['#', '.', '.', ' ', ' ', ' ', '#'],
['#', '#', '#', '#', '#', '#', '#']]).
map_size(7, 8).
num_dots(8).
pacman_start(1, 1).
initMap:-
  addSolidObject('#'),
  
  createGameEntity(OID_BL0, '%', object, 3, 1, inactive, norule, 
    [name(bloque_movil), solid(true), static(true), use_rule(norule),
      description('Bloque pesado que puede ser movido con una palanca'), appearance(attribs(bold, black, green))]),

  createGameEntity(OID_BL1, '%', object, 3, 5, inactive, norule, 
    [name(bloque_movil), solid(true), static(true), use_rule(norule),
      description('Bloque pesado que puede ser movido con una palanca'), appearance(attribs(bold, black, green))]),

  createGameEntity(OID_BL2, '%', object, 4, 5, inactive, norule, 
    [name(bloque_movil), solid(true), static(true), use_rule(norule),
      description('Bloque pesado que puede ser movido con una palanca'), appearance(attribs(bold, black, green))]),

  createGameEntity(OID_BL3, '%', object, 5, 5, inactive, norule, 
    [name(bloque_movil), solid(true), static(true), use_rule(norule),
      description('Bloque pesado que puede ser movido con una palanca'), appearance(attribs(bold, black, green))]),

  createGameEntity(OID_P, '\\', object, 2, 2, inactive, norule, 
    [name(palanca), solid(false), static(false), use_rule(pushBlocks),
      description('Palanca con la que empujar bloques pesados'), appearance(attribs(bold, cyan, default))]),
  pushBlocks(init, OID_P, [OID_BL0, OID_BL1, OID_BL2, OID_BL3]).
norule(_).
norule(_,_,_,_,_).