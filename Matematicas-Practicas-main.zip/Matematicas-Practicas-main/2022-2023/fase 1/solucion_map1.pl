:-use_module('pl-man-game/main').

do(move(none)):- see(normal, right, 'E').
do(use(left)):- see(normal, left, '|').

do(get(up)):- see(normal, up, 'a').

do(move(down)):- see(normal, down, '.').
do(move(up)):- see(normal, up, '.').
do(move(left)):- see(normal, left, '.').

do(move(down)):- see(normal, left-down, '#'), see(normal, up, '#'), see(normal, right-down, '#'), see(normal, down, ' '), see(normal, up-right, '#'), see(normal, up-left, '#'), see(normal, right, '#').

do(move(right)):- see(normal, right, '.').
do(move(right)):- see(normal, left, ' '), see(normal, up, '#'), see(normal, left-down, '#'), see(normal, right, ' ').

do(move(left)):- see(normal, left, ' '), see(normal, up, '#'), see(normal, left-down, '#').

do(move(down)):- see(normal, down-left, '.').
