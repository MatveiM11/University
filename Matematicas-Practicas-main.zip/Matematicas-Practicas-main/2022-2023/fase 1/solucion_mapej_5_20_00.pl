:-use_module('pl-man-game/main').

do(get(right)):- see(normal, right, '¬').

/*finish*/
do(move(down)):- see(normal, left-down, '<'),see(normal, down, '.').

/*avoid projectile*/
do(move(down)):- see(normal, left, '>').
do(move(left)):- see(normal, up, '>');see(normal, up-right, '>').
do(move(right)):- see(normal, up-right, '<').

do(move(right)):- see(normal, right, '.').

/*avoid enemy*/
do(move(up)):- see(normal, left, 'E'),not(see(normal, up, '#')).
do(move(left)):- see(normal, down, 'E').
/*you can shot on any distancy, direct touch isn't necessary'*/
do(use(right)):- see(normal, right, 'E').
do(use(left)):- see(normal, left, 'E').



/*do none to wait for enemy to be in right position*/
do(move(none)):- see(normal, down, '#'), see(normal, right, ' '),see(normal, up, '.'),see(normal, right-up, ' ').


/*move left after password*/
do(move(left)):- see(normal, left, '.'), see(normal, down, ' ').


/*move up after password solving*/
do(move(up)):- see(normal, up-right, '¬');see(normal, down, ' '), see(normal, up, '.'),not(see(normal, left, '.'));see(normal, up, '.'),see(normal, left, '#').


/*do none to wait for enemy to be in right position*/
do(drop(up)):- see(normal, down, '#'), see(normal, down-right, 'i'),not(see(normal, up, '¬')).


/*move down to password*/
do(move(right)):- see(normal, right, ' '),see(normal, left, '#'),see(normal, up-right, '#').
do(move(down)):- see(normal, left, '#'),see(normal, right, '#'),see(normal, down, ' ').



/*after password solved -> move left*/
do(move(left)):- see(normal, down, 'o'), see(normal, down-left, 'k');see(normal, down, 'k'), see(normal, down-right, 'p');see(normal, down, 'e'), see(normal, down-right, 'l');see(normal, down, 'h'), see(normal, down-right, 'f').


/*password solving*/
do(move(right)):- see(normal, right-down, 'g');see(normal, down, 'g');see(normal, left-down, 'h');see(normal, left-down, 'e').


do(move(left)):- see(normal, left-up, '.').

do(move(right)):- see(normal, left-up, '#'), see(normal, right, ' '),not(see(normal, down, ' ')), not(see(normal, left, '.')).

do(move(left)):- see(normal, up, '#').

do(move(up)):- see(normal, left, ' '), see(normal, right, ' '), see(normal, down, ' '), see(normal, up, ' '),not(see(normal, up, '>')), not(see(normal, up, '<')),not(see(normal, up-left, '>')).


do(move(right)):- see(normal, right, ' '), not(see(normal, left, '.')).
