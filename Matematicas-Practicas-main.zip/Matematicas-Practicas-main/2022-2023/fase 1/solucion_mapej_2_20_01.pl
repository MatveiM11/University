
:-use_module('pl-man-game/main').


do(move(up)):- see(normal, right, '.'), see(normal, right-up, '#'), see(normal, up, '.').

do(move(right)):- see(normal, right, '.').

do(move(up)):- see(normal, up, '.'), see(normal, left, ' '); see(normal, left-up, '0').

do(move(left)):- see(normal, left, ' '), see(normal, left-down, '#'), see(normal, down-right, '#'), see(normal, down, '.').

do(move(down)):- see(normal, down, '.').

do(move(up)):- see(normal, up, '.').


do(move(down)):- see(normal, down, '.').
do(move(left)):- see(normal, left, '.').

do(move(up)):- see(normal, up-left, '.').

do(move(left)):- see(normal, left, ' ').

do(move(down)):- see(normal, down-right, '.').

