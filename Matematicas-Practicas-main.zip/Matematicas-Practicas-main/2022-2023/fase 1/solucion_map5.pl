:-use_module('pl-man-game/main').

do(get(down)):- see(normal, down, 'p').

do(move(left)):- see(normal, up-right, 'E'), see(normal, up, '%').
do(move(none)):- see(normal, right-up, '%'), see(normal, up, 'E').

do(use(up)):- see(normal, up, '%').

do(move(none)):- see(normal, right-down, 'E').

do(move(up)):- see(normal, up, ' '), see(normal, down-left, 'E'), see(normal, up-right, '#'), see(normal, right, ' ').

do(move(none)):- see(normal, down, 'E').
do(move(none)):- see(normal, left-down, 'E'), see(normal, up, '#').

do(move(left)):- see(normal, left, '.'), see(normal, right-up, '#'), see(normal, down-left, '#').

do(move(up)):- see(normal, up, '.').
do(move(right)):- see(normal, right, '.').
do(move(left)):- see(normal, left, '.').
do(move(down)):- see(normal, down, '.').


do(move(up)):- see(normal, down-right, '%'), see(normal, up-right, '#').


do(move(right)):- see(normal, right, ' ').

do(use(down)):- see(normal, down, '%'), see(normal, up, '#').

do(move(up)):- see(normal, up, ' ').

do(move(left)):- see(normal, left, ' '), see(normal, right-up, '#').
