:-use_module('pl-man-game/main').

do(move(left)):- see(normal, up-right, 'E'), see(normal, up, '%').
do(move(none)):- see(normal, right-up, '%'), see(normal, up, 'E').
do(move(none)):- see(normal, right-down, 'E').
do(move(none)):- see(normal, down, 'E').
do(move(none)):- see(normal, left-down, 'E'), see(normal, up, '#').


do(move(left)):- see(normal, left, '.').
do(move(right)):- see(normal, right, '.').
do(move(down)):- see(normal, down, '.').
do(move(up)):- see(normal, up, '.').

do(move(up)):- see(normal, up, ' ').

do(move(right)):- see(normal, right, ' '), see(normal, up, '#'), see(normal, up-right, '.').

do(move(left)):- see(normal, right-up, '.'), see(normal, right, '#'), see(normal, up, 'E').
