
:-use_module('pl-man-game/main').

do(move(right)):- see(normal, up-right, 'E'),not(see(normal, left, '.')).

do(move(none)):- see(normal, up, 'E'), see(normal, right, '.'), see(normal, right-up, '#').

do(move(up)):- see(normal, up-left, 'E'), see(normal, right-up, '#').

do(move(down)):- see(normal, down, '.'), see(normal, left, ' '), see(normal, up, '#'), not(see(normal, right, '.')).

do(move(left)):- see(normal, up, '#'), not(see(normal, right, '.')), not(see(normal, left, '#')),not(see(normal, right, 'E')), not(see(normal, down, 'E')).

do(move(up)):- see(normal, up, '.').



do(move(down)):- see(normal, right, 'E').
do(move(right)):- see(normal, right, '.').

do(move(down)):- see(normal, down, '.'), see(normal, left, '#').
do(move(down)):- see(normal, down, ' '), see(normal, left, '#').

do(move(left)):- see(normal, down, '#'), not(see(normal, up, 'E')),not(see(normal, left, '#')).
do(move(right)):- see(normal, down, '#').

do(move(up)):- see(normal, up-left, ' '), see(normal, right-up, '.'), see(normal, right, '#').

do(move(down)):- see(normal, down, '.'), see(normal, right, '#').

do(move(left)):- see(normal, left, '.').
