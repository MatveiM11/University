/* HABITANTES EN LAS PROVINCIAS */

prov_cv(alicante).
prov_cv(castellon).
prov_cv(valencia).

/* hab(provincia, numh_hab). */
hab(alicante,1934127).
hab(castellon,604344).
hab(valencia,2578719).

/* Superficie de las provincias*/

sup(alicante, 5815).
sup(castellon, 6632).
sup(valencia, 10763).

/*funciona de densidad hab:km2 */
dens(P,D):-hab(P,H),sup(P,S), D is H/S.
