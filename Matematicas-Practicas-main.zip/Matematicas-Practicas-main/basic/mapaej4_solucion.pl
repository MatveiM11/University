:-use_module('pl-man-game/main').


do(move(left)):-see(normal,left,'.').
do(get(left)):-see(normal,left,'U').
do(drop(right)):-see(normal,left,'V'), not(see(normal, right, 'U')).
do(get(left)):-see(normal,left,'V').
