:-use_module('pl-man-game/main').


do(move(down)):-see(normal, down,'.').
do(use(right)):-see(normal, right,'E').
do(move(right)):-see(normal, right,'.').
do(get(down)):-see(normal,down,'l').
do(move(up)):-see(normal,up,' ').
do(move(up)):-see(normal,up,'.').



