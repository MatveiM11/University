1) cd into the directory with plman, then cd plman
2) map and solucion.pl should be in the same folder
3) run game with command - ./plman mapname.pl solucion.pl
4) run game with multiple tests(20 for ex.) - ./launch 20 mapname.pl solucion.pl

IMPORTANT

Orden of the commands is important, more higher written command in the script has higher priority.
