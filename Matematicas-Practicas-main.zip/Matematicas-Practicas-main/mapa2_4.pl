%4
map_format_version(1.1).
load_behaviour(cauldron).
load_behaviour(mineExplosion).
load_behaviour(basicTeletransport).
load_behaviour(enemyBasicMovement).


map([
'#################################',
'#                #    #.........#',
'#................#   #..  ##....#',
'#..#       #.....#  #..    #....#',
'#...#     # #....# ##......#....#',
'#....# # #..#....##........#....#',
'#.... ### ..#....##........####.#',
'#...........#.... #.............#', 
'#################################',
'###### -1. a > w   ##############',
'#####  -2. a     ################',
'####   -3. o        #############',
'#####   4.       MP 1,2 #########',
'######  5. w ^   IC 4,3  ########',
'#################################'
]).

map_size(33, 15).
num_dots(130).
pacman_start(11, 4).

initMap:- 
	addSolidObject('#'),

  maplist(write, 
    [' 1 - Welcome to Ancient Logic Pyramid, created by the Pharaoh Llorens. Walls prevent you entering. ',
     'Use a pyramid-teleport potion to enter. The recipe is form with the solution to the Ancient Logic',
     'natural deduction hieroglyphic shown below.\n']),

	createGameEntity(_, 'w', object, 5, 1, inactive, norule, 
                [name(water), solid(true), static(false), appearance(attribs(normal, green, default)),
                description('water')]),
	createGameEntity(_, 's', object, 2, 1, inactive, norule, 
                [name(watermelon), solid(true), static(false), appearance(attribs(normal, red, default)),
                description('Shimmering watermelon')]),
  createGameEntity(_, 'o', object, 8, 1, inactive, norule, 
                [name(oil), solid(true), static(false), appearance(attribs(normal, yellow, default)),
                description('Luminous stone powder')]),
  createGameEntity(_, 'r', object, 11, 1, inactive, norule, 
               [name(redstone), solid(true), static(false), appearance(attribs(normal, magenta, default)),
                description('redstone')]),
  createGameEntity(_, 'l', object, 14, 1, inactive, norule, 
               [name(powder), solid(true), static(false), appearance(attribs(normal, white, default)),
                description('oil')]),  

  createGameEntity(EID_P1, '?', object, 11, 12, inactive, norule, 
               [name(?), solid(true), static(false), appearance(attribs(normal, black, yellow)),
                description('part 1')]),    
  createGameEntity(EID_P2, '?', object, 15, 13, inactive, norule, 
               [name(?), solid(true), static(false), appearance(attribs(normal, black, yellow)),
                description('part 2')]),    

  createGameEntity(EID2, 'E', mortal, 1, 1, active, enemyBasicMovement,[appearance(attribs(normal,red,default))]), 
  enemyBasicMovement(init, EID2, down-up, ['#']),
  createGameEntity(EID3, 'E', mortal, 15, 1, active, enemyBasicMovement,[appearance(attribs(normal,red,default))]), 
  enemyBasicMovement(init, EID3, down-up, ['#']),


  cauldron(create(OID_C, 17, 7, [])),
  dynamicProperties(set(OID_C, static(false))),
  cauldron(newRecipe(OID_C, 2117664152,  1, [ 'pl-man':cauldronFinish(OID_C, EID_P1, EID_P2, 1) ])),
  hieroglyphic(create(OID_C, [EID_P1, EID_P2])).
      

print(LIST) :-
  maplist(write, LIST).

cauldronFinish(OID_C, EID_P1, EID_P2, 1) :-
  cauldron(destroy(OID_C)),      
  destroyGameEntity(OID_C),

  createGameEntity(EID, 'E', mortal, 24, 3, active, enemyBasicMovement,[appearance(attribs(normal,red,default))]), 
  enemyBasicMovement(init, EID, down-up, ['#']),

  changeEntityAppearance(EID_P1, 'w', bold, white, cyan),
  changeEntityAppearance(EID_P2, 'o', bold, white, cyan),

	createGameEntity(OID_TT, '?', object, 17, 7, active, basicTeletransport, 	
	   [name(teletransporte), solid(false), static(true), use_rule(norule),
	   description('teleport'), appearance(attribs(normal,black,red))]),
	basicTeletransport(init, OID_TT, from(17,7), to(19,7), ['@'], [viceversa]).

:- dynamic d_hieroglyphic/5.
hieroglyphic(init, EID_S, EID_C, L_PARTS) :-
    retractall(d_hieroglyphic(_,_,_,_,_))
  , assert(d_hieroglyphic(EID_S, EID_C, L_PARTS, _, _)).

hieroglyphic(init, EID_S, EID_C, L_PARTS, OID_ING, AP_ING) :-
    retractall(d_hieroglyphic(_,_,_,_,_))
  , assert(d_hieroglyphic(EID_S, EID_C, L_PARTS, OID_ING, AP_ING)).

hieroglyphic(ingredient_dropped, _, _, _, _, []) :- !.
hieroglyphic(ingredient_dropped, _, EID_C, OID_ING, _, _) :-
    not(aliveEntity(OID_ING))
  , entityLocation(EID_C, XC, YC, _)
  , entityType(EID_PLMAN, pacman)
  , entityLocation(EID_PLMAN, XP, YP, _)
  , DX is abs(XP - XC)
  , DX > 1
  , DY is abs(YP - YC)
  , DY > 1
  , !.
hieroglyphic(ingredient_dropped, EID_S, EID_C, _, AP_ING, [EID_P1 | L_PARTS]) :-
    hieroglyphic(init, EID_S, EID_C, L_PARTS)
  , aliveEntity(EID_C)
  , changeEntityAppearance(EID_P1, AP_ING, bold, white, black).

hieroglyphic(update, _, _, [], _, _) :- !.
hieroglyphic(update, EID_S, EID_C, L_PARTS, OID_ING, AP_ING) :- 
    number(OID_ING)
  , !
  , not(isObjectGot(OID_ING))
  , hieroglyphic(init, EID_S, EID_C, L_PARTS)
  , hieroglyphic(ingredient_dropped, EID_S, EID_C, OID_ING, AP_ING, L_PARTS).
hieroglyphic(update, EID_S, EID_C, L_PARTS, OID_ING, _) :- 
    var(OID_ING)
  , isObjectGot(OID_ING)
  , entityLocation(OID_ING, _, _, Ap)
  , hieroglyphic(init, EID_S, EID_C, L_PARTS, OID_ING, Ap).

hieroglyphic(create(EID_C, L_PARTS)) :-
    createGameEntity(EID_S, '', object, 0, 0, active, hieroglyphic, 
        [name(hieroglyphic), solid(true), static(true), appearance(attribs(normal, black, yellow)),
         description('Hieroglyphic supervisor')])
  , hieroglyphic(init, EID_S, EID_C, L_PARTS).

hieroglyphic(EID) :-
    d_hieroglyphic(EID, EID_C, L_PARTS, OID_ING, AP_ING)
  , hieroglyphic(update, EID, EID_C, L_PARTS, OID_ING, AP_ING).
  