:-use_module('pl-man-game/main').

do(move(down)):-see(normal,down,'.').
do(move(up)):-see(normal,up,'.').
do(move(right)):-see(normal,right,'.').
do(move(down)):-not(see(normal,down,'#')).
do(move(right)):-see(normal,down,'#'), not(see(normal,left,'.')).
do(move(left)):-see(normal,left,'.').
