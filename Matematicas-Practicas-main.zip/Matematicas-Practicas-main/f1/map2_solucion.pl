:-use_module('pl-man-game/main').

do(get(up)):-see(normal,up,'a').
do(use(left)):-see(normal,left,'|').

do(move(up)):-see(normal,up,'.').

do(move(left)):-see(normal,left,'.').

do(move(right)):-see(normal,right,'.').

do(move(down)):-see(normal,down,'.').



do(move(left)):-see(normal, up,'#'), not(see(normal, left, '#')).
do(move(up)):-see(normal,right,'#').

do(move(down)):-see(normal,left,'#').
