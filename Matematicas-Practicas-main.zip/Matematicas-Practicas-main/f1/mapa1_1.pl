load_behaviour(basicTeletransport).

map_format_version(1.1).
map([
'###########',
'# ...######',
'#....######',
'##.########',
'## ### ####',
'#....#....#',
'#....#....#',
'###########'
]).
map_size(11, 8).
num_dots(24).
pacman_start(1, 1).
initMap:-
 	addSolidObject('#'),

    createGameEntity(OID_TT1, '?', object, 2, 4, active, basicTeletransport, 
      	[appearance(attribs(bold, red, default))]), 
    basicTeletransport(init, OID_TT1, from(2, 4), to(6, 4), ['@'] ,[ viceversa ]),

    createGameEntity(_, '?', object, 6, 4, active, norule, 
      	[appearance(attribs(bold, red, default))]).

norule(_).