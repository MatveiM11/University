:-use_module('pl-man-game/main').



do(move(right)):-see(normal,right,'.'),see(normal,up,' ').

do(move(down)):-see(normal,right,'E'),see(normal,up,' ').

do(move(down)):-see(normal,right,' '),see(normal,left,' '), see(normal,down,' ').

do(move(up)):-see(normal,up,'.').
do(move(left)):-see(normal,left,'.').
do(move(right)):-see(normal,up,'#'), not(see(normal,right,'E')),not(see(normal,right,'#')).
do(move(right)):-see(normal,right,'.').
do(move(down)):-see(normal,down,'.'), see(normal,right,'#').
do(move(down)):-see(normal,down,'.'),not(see(normal,up,'#')).
do(move(left)):-see(normal,left,' '), not(see(normal,right,'E')).
do(move(down)):-see(normal,right,'#').
