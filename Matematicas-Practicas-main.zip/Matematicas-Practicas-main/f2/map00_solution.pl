:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.


do(drop(left)):- havingObject(appearance('a')), see(normal, up, 'r').

do(get(up)):- see(normal, up, 'a').
do(get(up)):- see(normal, up, 'r').
do(use(right)):- see(normal,right, '|').

do(move(right)):- not(havingObject), see(normal,right, ' ').
do(move(up)):- not(havingObject),see(normal,up, ' ').

do(move(right)):- havingObject(appearance('a')),see(normal,down, '#'), see(normal,up,'#').
do(move(right)):- havingObject(appearance('a')),see(normal,down, '#'), see(normal,left,'#').
do(move(left)):- havingObject(appearance('a')),see(normal,left, ' ').
do(move(down)):- havingObject(appearance('a')),see(normal,down, ' ').


do(move(right)):-see(normal,right, '.').
do(move(left)):- havingObject(appearance('r')),see(normal,down, '#'),not(see(normal,left,'#')).
do(move(up)):- havingObject(appearance('r')),see(normal,up, ' ').

