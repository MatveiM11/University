:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.

do(get(right)):- see(normal, right, 'a').
do(move(right)):- not(havingObject).
do(use(left)):- see(normal,left, '|').
do(move(left)):- havingObject.

