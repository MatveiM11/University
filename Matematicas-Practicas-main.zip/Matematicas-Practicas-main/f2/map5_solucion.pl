
:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.

do(use(left)):- havingObject(appearance('r')).

do(move(none)):-see(normal, left, 'E'), see(normal, up, '#'), see(normal, right, '#').
do(move(none)):-see(normal, left, 'E'), see(normal, up-left, '_'), see(normal, right, ' ').

do(get(left)):-see(normal, left, 'r').

do(move(down)):-see(normal, down, '.').

do(move(right)):-see(normal, right, '.'), see(normal, down, 'r').

do(move(D)):-see(normal,D, '.'), all(D).


do(move(left)):-see(normal, down, ' '), see(normal, right, '#'), see(normal, up-left, '#'), havingObject(appearance('r')).
do(move(left)):-see(normal, down, ' '), see(normal, right, ' '), see(normal, left, ' '), see(normal, up-left, '#'), havingObject(appearance('r')).
do(move(down)):-see(normal, down, ' '),  havingObject(appearance('r')).

do(move(right)):-see(normal, right, ' ').

do(move(down)):-see(normal, down, ' ').

do(move(up)):-see(normal, up-right, '.').

do(move(up)):-see(normal, up-right, '#'), see(normal, up, ' '), see(normal, down, '#').
