:- use_module('pl-man-game/main').
all(D) :- D=down; D=right;D=left;D=up.

do(move(right)):-see(normal, down, '#'), see(normal, left, ' '), see(normal, right, '.'), see(normal, up-right, '.').

do(move(D)):-see(normal,D, '.'), all(D).

do(move(right)):-see(normal, right, ' ').

do(move(down)):-see(normal, down, ' ').
