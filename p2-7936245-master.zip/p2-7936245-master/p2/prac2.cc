// Marat Tskonyan Y7936245

#include <iostream>
#include <vector>
#include <regex>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <algorithm>

using namespace std;

const int KMAXSTRING = 50;
const int KMAXIP = 16;

enum Error
{
  ERR_OPTION,
  ERR_NAME,
  ERR_EMAIL,
  ERR_ID,
  ERR_IP,
  ERR_FILE,
  ERR_ARGS
};

//
struct Subscriber
{
  unsigned int id;
  string name;
  string email;
  string mainIp;
  vector<string> ips;
};

struct BinSubscriber
{
  unsigned int id;
  char name[KMAXSTRING];
  char email[KMAXSTRING];
  char mainIp[KMAXIP];
};

struct Platform
{
  string name;
  vector<Subscriber> subscribers;
  unsigned int nextId;
};

struct BinPlatform
{
  char name[KMAXSTRING];
  unsigned int nextId;
};

// Enums for "Enter:" messages
enum enterMessage
{
  MSG_NAME,
  MSG_EMAIL,
  MSG_ID,
  MSG_IP,
  MSG_FILE,
  MSG_ERASE
};

void error(Error e)
{
  switch (e)
  {
  case ERR_OPTION:
    cout << "ERROR: wrong menu option" << endl;
    break;
  case ERR_NAME:
    cout << "ERROR: wrong name" << endl;
    break;
  case ERR_EMAIL:
    cout << "ERROR: wrong email" << endl;
    break;
  case ERR_ID:
    cout << "ERROR: wrong subscriber id" << endl;
    break;
  case ERR_IP:
    cout << "ERROR: wrong IP" << endl;
    break;
  case ERR_FILE:
    cout << "ERROR: cannot open file" << endl;
    break;
  case ERR_ARGS:
    cout << "ERROR: wrong arguments" << endl;
    break;
  }
}

void enter_message(enterMessage M)
{
  switch (M)
  {
  case MSG_NAME:
    cout << "Enter name: ";
    break;
  case MSG_EMAIL:
    cout << "Enter email: ";
    break;
  case MSG_ID:
    cout << "Enter subscriber id: ";
    break;
  case MSG_IP:
    cout << "Enter IP: ";
    break;
  case MSG_FILE:
    cout << "Enter filename: ";
    break;
  case MSG_ERASE:
    cout << "All data will be erased. Continue? [y/n]: ";
    break;
  }
}

void showSubscribers(const Platform &platform)
{
  for (const Subscriber &subscriber : platform.subscribers)
  {
    cout << subscriber.id << ":" << subscriber.name << ":";
    cout << subscriber.email << ":" << subscriber.mainIp << ":";

    for (const string &ip : subscriber.ips)
    {
      cout << ip;

      if (&ip != &subscriber.ips.back())
      {
        cout << "|";
      }
    }
    cout << endl;
  }
}

// Verification of the name entered by the user
bool validName(const string &name)
{
  // regex pattern looks for:
  // - the length is greater than or equal to 3
  // - ensures the name doesn't contain a colon (:)
  regex namePattern("^[^:]{3,}$");

  // Test the name against the regex pattern
  return regex_match(name, namePattern);
}

// Verification of the email entered by the user
bool EmailCheck(string &email)
{

  // Regular expression pattern to match valid email addresses
  regex emailRegex(R"([a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)*@[a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)+)");
  // Check if the email address matches the regex pattern
  if (!regex_match(email, emailRegex))
  {
    return false;
  }

  return true;
}

// add information about the user's name and email.
void addSubscriber(Platform &platform)
{
  Subscriber newSubscriber;
  string name, email;

  // Prompt user to enter name
  cout << "Enter name: ";
  getline(cin, name);

  // Validate name
  while (name.length() < 3 || name.find(':') != string::npos)
  {
    error(ERR_NAME);
    cout << "Enter name: ";
    getline(cin, name);
  }

  // Prompt user to enter email
  cout << "Enter email: ";
  getline(cin, email);

  // Validate email with regex
  regex emailRegex(R"([a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)*@[a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)+)");
  while (!regex_match(email, emailRegex))
  {
    error(ERR_EMAIL);
    cout << "Enter email: ";
    getline(cin, email);
  }

  // Assign subscriber data
  newSubscriber.id = platform.nextId++;
  newSubscriber.name = name;
  newSubscriber.email = email;

  // Add subscriber to platform
  platform.subscribers.push_back(newSubscriber);
}

bool isValidIp(string &ip)
{
  // Regular expression pattern to match valid IPv4 addresses
  regex ipPattern(R"((\d{1,3}\.){3}\d{1,3})");

  // Check if the IP address matches the regex pattern
  if (regex_match(ip, ipPattern))
  {
    stringstream ss(ip);
    string num;
    while (getline(ss, num, '.'))
    {
      int value = stoi(num);

      // Check for leading zeros
      if ((value == 0 && num.length() > 1) || (value != 0 && num[0] == '0'))
      {
        return false;
      }

      if (value < 0 || value > 255)
      {
        return false;
      }
    }
    return true;
  }

  return false;
}

// Given a Platform struct and a subscriber ID, returns the index of the subscriber in the subscribers vector
// If the subscriber ID is not findSubscribers, returns -1
int identifySubscriberID(const Platform &platform, int id)
{
  for (unsigned int i = 0; i < platform.subscribers.size(); i++)
  {
    if ((int)platform.subscribers[i].id == id)
    {           // if the subscriber ID matches the input ID
      return i; // return the index of the subscriber in the subscribers vector
    }
  }
  return -1; // return -1 if the subscriber ID is not findSubscribers
}

string identifyMainIP(const vector<string> &ips)
{
  if (ips.empty())
  { // If empty, return empty string
    return "";
  }

  // Use a map to store the frequency of each IP address
  map<string, int> ipFrequency;
  for (const string &ip : ips)
  {
    ipFrequency[ip]++;
  }

  // Find the IP address with the highest frequency
  string mainIp = ips[0];             // Initialize to first IP address
  int maxCount = ipFrequency[mainIp]; // Initialize to frequency of first IP address

  // Iterate over map to find IP address with highest frequency
  for (const auto &entry : ipFrequency)
  {
    if (entry.second > maxCount)
    { // If frequency is higher than current max, update mainIp and maxCount
      maxCount = entry.second;
      mainIp = entry.first;
    }
  }

  return mainIp; // Return IP address with highest frequency
}

void addSubscriberIp(Platform &platform)
{
  string id;
  cout << "Enter subscriber id: ";
  getline(cin, id);

  // Check if input ID is valid
  if (!regex_match(id, regex("\\d+")))
  {
    error(ERR_ID);
    return;
  }

  // Find subscriber by ID
  int index = identifySubscriberID(platform, stoi(id));
  if (index == -1)
  {
    error(ERR_ID);
    return;
  }

  string ip;
  do
  {
    cout << "Enter IP: ";
    getline(cin, ip);

    // Check if IP address is valid
    if (!isValidIp(ip))
    {
      error(ERR_IP);
      ip = "";
    }
  } while (ip.empty());

  // Add IP address to subscriber's IP vector
  platform.subscribers[index].ips.push_back(ip);

  // Update subscriber's main IP
  platform.subscribers[index].mainIp = identifyMainIP(platform.subscribers[index].ips);
}

bool findSubscribers(Platform &platform, unsigned int id_delete)
{
  // Find the subscriber with the specified ID using a lambda function
  auto it = find_if(platform.subscribers.begin(), platform.subscribers.end(),
                    [&](const Subscriber &s)
                    { return s.id == id_delete; });

  // If the subscriber is found, delete it and return true
  if (it != platform.subscribers.end())
  {
    platform.subscribers.erase(it);
    return true;
  }

  // If the subscriber is not found, return false
  return false;
}

void deleteSubscriber(Platform &platform)
{
  int inputId;
  cout << "Enter subscriber id: ";
  cin >> inputId;
  // Ignore up to 10000 characters or until a newline character is found in the input buffer
  cin.ignore(10000, '\n');

  int index = -1;
  for (unsigned int i = 0; i < platform.subscribers.size(); i++)
  {
    if ((int)platform.subscribers[i].id == inputId)
    {
      index = i; // store the index of the subscriber with the matching id
      break;
    }
  }

  if (index != -1)
  {                                                                   // if a subscriber was found with the matching id
    platform.subscribers.erase(platform.subscribers.begin() + index); // remove the subscriber from the vector
                                                                      // cout << "Subscriber with id " << inputId << " has been deleted." << endl; // for ease of debug
  }
  else
  {                // if no subscriber was found with the matching id
    error(ERR_ID); // show error message
  }
}

// This function removes leading and trailing whitespace characters from the input string
string trim(const string &str)
{
  // Find the first character that is not a whitespace character
  size_t first = str.find_first_not_of(" \t\n\r");
  if (first == string::npos) // If there are only whitespace characters, return an empty string
  {
    return "";
  }
  // Find the last character that is not a whitespace character
  size_t last = str.find_last_not_of(" \t\n\r");
  // Return the substring between the first and last non-whitespace characters, inclusive
  return str.substr(first, (last - first + 1));
}

// This function splits the input string into tokens using the specified delimiter character
// and stores the tokens in the output vector. Leading and trailing whitespace characters
// are removed from each token using the trim function.
void split(const string &str, char delim, vector<string> &tokens)
{
  // Create a stringstream from the input string
  stringstream ss(str);
  string item;
  // Split the input string at each occurrence of the delimiter character and add the tokens to the output vector
  while (getline(ss, item, delim))
  {
    tokens.push_back(trim(item));
  }
}

// Checks if the file is valid and opens it
bool OpenCSVFile(ifstream &infile, const string &filename)
{
  if (filename.empty())
  {
    error(ERR_FILE);
    return false;
  }

  infile.open(filename);
  if (!infile.is_open())
  {
    error(ERR_FILE);
    return false;
  }

  return true;
}

// Parses each line of the CSV file and adds the subscriber data to the platform
void ParseCSVLine(Platform &platform, const string &line)
{
  stringstream ss(line);
  string name, email, mainIp, ips;

  // Extract subscriber data from line
  getline(ss, name, ':');
  getline(ss, email, ':');
  getline(ss, mainIp, ':');
  getline(ss, ips);

  // Trim whitespace from extracted data
  trim(name);
  trim(email);
  trim(mainIp);
  trim(ips);

  // Check name for validity
  if (!validName(name))
  {
    error(ERR_NAME);
    return;
  }

  // Check email for validity
  if (!EmailCheck(email))
  {
    error(ERR_EMAIL);
    return;
  }

  // Split IP addresses by '|' delimiter and trim whitespace
  vector<string> ipList;
  split(ips, '|', ipList);
  for (auto &ip : ipList)
  {
    trim(ip);
    if (!isValidIp(ip))
    {
      error(ERR_IP);
      return;
    }
  }

  // Create a new subscriber and add them to the platform's subscriber list
  Subscriber subscriber;
  subscriber.id = platform.nextId++;
  subscriber.name = name;
  subscriber.email = email;
  subscriber.mainIp = mainIp;
  subscriber.ips = ipList;
  platform.subscribers.push_back(subscriber);
}

// Reads and processes the CSV file
void csvFile(Platform &platform, const string &filename)
{
  ifstream infile;
  if (!OpenCSVFile(infile, filename))
  {
    return;
  }

  string line;
  while (getline(infile, line))
  {
    if (line.empty())
    {
      continue;
    }

    ParseCSVLine(platform, line);
  }

  infile.close();
}

// This function reads binary data from a file and populates the provided Platform object
void ReadBinaryData(Platform &platform, ifstream &file)
{
  // Read the Platform information from the binary file
  BinPlatform binPlat;
  file.read(reinterpret_cast<char *>(&binPlat), sizeof(BinPlatform));
  // Populate the Platform object with the read data
  platform.name = binPlat.name;
  platform.nextId = binPlat.nextId;

  // Read the Subscriber information from the binary file
  BinSubscriber binSub;
  while (file.read(reinterpret_cast<char *>(&binSub), sizeof(BinSubscriber)))
  {
    Subscriber newSubscriber;
    newSubscriber.id = binSub.id;
    newSubscriber.name = binSub.name;
    newSubscriber.email = binSub.email;
    newSubscriber.mainIp = binSub.mainIp;

    // Check if mainIp is not empty, and add it to the Subscriber's ips vector
    if (binSub.mainIp[0] != '\0')
    {
      newSubscriber.ips.push_back(string(binSub.mainIp));
    }

    // Add the new Subscriber object to the Platform's subscribers vector
    platform.subscribers.push_back(newSubscriber);
  }
}

// This function loads data from a binary file and populates the provided Platform object
void BinBackup(Platform &platform, const string &filename)
{
  if (filename.empty())
  {
    error(ERR_FILE);
    return;
  }

  // Open the binary file
  ifstream file(filename, ios::binary);
  if (!file.is_open())
  {
    error(ERR_FILE);
    return;
  }

  // Clear the Platform's subscribers vector and name
  platform.subscribers.clear();
  platform.name.clear();

  // Read the binary data from the file and populate the Platform object
  ReadBinaryData(platform, file);

  // Close the file
  file.close();
}

void importFromCsv(Platform &platform)
{
  string filename;
  enter_message(MSG_FILE);
  cin.ignore();
  getline(cin, filename);

  csvFile(platform, filename);
}

// Creates a CSV file from a vector of Subscriber objects and a file name
void createCSVFile(const vector<Subscriber> &subscribers, const string &filename)
{
  // Open the output file stream
  ofstream fout(filename);

  // Check if the stream opened correctly
  if (!fout)
  {
    error(ERR_FILE);
    return;
  }

  // Write each Subscriber object's information to the file
  for (const auto &subscriber : subscribers)
  {
    fout << subscriber.name << ":" << subscriber.email << ":" << subscriber.mainIp << ":";

    // If the Subscriber has IP addresses, write them to the file
    if (!subscriber.ips.empty())
    {
      for (const auto &ip : subscriber.ips)
      {
        fout << ip;
        if (&ip != &subscriber.ips.back())
        {
          fout << "|";
        }
      }
    }

    // End the line for the current Subscriber object
    fout << endl;
  }

  // Close the output file stream
  fout.close();
}

// Gets a file name from the user and exports the Platform's subscribers to a CSV file
void exportToCsv(const Platform &platform)
{
  // Get the file name from the user
  string filename;
  enter_message(MSG_FILE);
  cin.ignore();
  getline(cin, filename);

  // Check if the file name is empty
  if (filename.empty())
  {
    error(ERR_FILE);
    return;
  }

  // Create the CSV file with the Platform's subscribers
  createCSVFile(platform.subscribers, filename);
}

bool isValidARGS(Platform &platform, int argc, char *argv[])
{
  // Initialize the filenames
  string CSVfilename, binfilename;

  // Create a regex to match valid option arguments
  regex optionRegex("^-(i|l)$");

  // Iterate over the arguments
  for (int i = 1; i < argc; i++)
  {
    // Get the current argument as a string
    string arg = argv[i];

    // Check if the argument matches the regex
    if (regex_match(arg, optionRegex))
    {
      // Switch on the option character (i or l)
      switch (arg[1])
      {
      // If the option is 'i'
      case 'i':
        // Check if the CSV filename is empty
        if (CSVfilename.empty())
        {
          // Get the next argument as the CSV filename
          i++;
          if (i < argc)
          {
            CSVfilename = argv[i];
          }
          else
          {
            error(ERR_ARGS);
            return false;
          }
        }
        else
        {
          // If the CSV filename is already set, return an error
          error(ERR_ARGS);
          return false;
        }
        break;

      // If the option is 'l'
      case 'l':
        // Check if the binary filename is empty
        if (binfilename.empty())
        {
          // Get the next argument as the binary filename
          i++;
          if (i < argc)
          {
            binfilename = argv[i];
          }
          else
          {
            error(ERR_ARGS);
            return false;
          }
        }
        else
        {
          // If the binary filename is already set, return an error
          error(ERR_ARGS);
          return false;
        }
        break;

      // If the option is neither 'i' nor 'l', return an error
      default:
        error(ERR_ARGS);
        return false;
      }
    }
    else
    {
      // If the argument doesn't match the regex, return an error
      error(ERR_ARGS);
      return false;
    }
  }

  // If a CSV filename is provided, read the CSV file
  if (CSVfilename != string())
  {
    csvFile(platform, CSVfilename);
  }

  // If a binary filename is provided, read the binary file
  if (binfilename != string())
  {
    BinBackup(platform, binfilename);
  }

  // Return success
  return true;
}

void loadData(Platform &platform)
{
  char IsErase;
  string filename;
  enter_message(MSG_ERASE);
  cin >> IsErase;

  if (IsErase == 'y' || IsErase == 'Y')
  {
    enter_message(MSG_FILE);
    cin.ignore();
    getline(cin, filename);

    BinBackup(platform, filename); // load binary data
  }
  else if (IsErase == 'N' || IsErase == 'n')
  {
    return;
  }
  else
  {
    loadData(platform); // recursively call function until valid input is entered
  }
}

void saveData(const Platform &platform)
{
  // Prompt the user for the filename
  string filenames;
  enter_message(MSG_FILE);
  cin.ignore();
  getline(cin, filenames);

  // Check if filename is empty
  if (filenames.empty())
  {
    error(ERR_FILE);
    return;
  }

  // Open the file in binary mode
  ofstream file(filenames, ios::binary);
  if (!file.is_open())
  {
    error(ERR_FILE);
    return;
  }

  // Write the platform data to the binary file
  BinPlatform binPlatform;
  memset(&binPlatform, 0, sizeof(binPlatform)); // Zero-initialize the structure
  strncpy(binPlatform.name, platform.name.c_str(), KMAXSTRING);
  binPlatform.nextId = platform.nextId;
  file.write(reinterpret_cast<char *>(&binPlatform), sizeof(binPlatform));

  // Write the subscribers data to the binary file
  for (const Subscriber &subscriber : platform.subscribers)
  {
    BinSubscriber binSubscriber;
    memset(&binSubscriber, 0, sizeof(binSubscriber)); // Zero-initialize the structure
    binSubscriber.id = subscriber.id;
    strncpy(binSubscriber.name, subscriber.name.c_str(), KMAXSTRING);
    strncpy(binSubscriber.email, subscriber.email.c_str(), KMAXSTRING);
    strncpy(binSubscriber.mainIp, subscriber.mainIp.c_str(), KMAXIP);
    file.write(reinterpret_cast<char *>(&binSubscriber), sizeof(binSubscriber));
  }

  // Close the binary file
  file.close();
}

void ShowImportExportMenu()
{
  cout << "[Import/export options]" << endl
       << "1- Import from CSV" << endl
       << "2- Export to CSV" << endl
       << "3- Load data" << endl
       << "4- Save data" << endl
       << "b- Back to main menu" << endl
       << "Option: ";
}

void importExportMenu(Platform &platform)
{
  char optionIE;

  do
  {
    ShowImportExportMenu();
    cin >> optionIE;

    switch (optionIE)
    {
    case '1':
      importFromCsv(platform);
      break;
    case '2':
      exportToCsv(platform);
      break;
    case '3':
      loadData(platform);
      break;
    case '4':
      saveData(platform);
      break;
    case 'b':
      break;
    default:
      error(ERR_OPTION);
    }
  } while (optionIE != 'b');
}

void showMainMenu()
{
  cout << "[Options]" << endl
       << "1- Show subscribers" << endl
       << "2- Add subscriber" << endl
       << "3- Add subscriber IP" << endl
       << "4- Delete subscriber" << endl
       << "5- Import/export" << endl
       << "q- Quit" << endl
       << "Option: ";
}

int main(int argc, char *argv[])
{
  Platform platform;
  platform.name = "Streamflix";
  platform.nextId = 1;
  char args[10][50];
  memset(args, 0, sizeof(args));

  if (!isValidARGS(platform, argc, argv))
  {
    return 1;
  }

  char option;
  do
  {
    showMainMenu();
    cin >> option;
    cin.get();

    switch (option)
    {
    case '1':
      showSubscribers(platform);
      break;
    case '2':
      addSubscriber(platform);
      break;
    case '3':
      addSubscriberIp(platform);
      break;
    case '4':
      deleteSubscriber(platform);
      break;
    case '5':
      importExportMenu(platform);
      break;
    case 'q':
      break;
    default:
      error(ERR_OPTION);
    }
  } while (option != 'q');

  return 0;
}
