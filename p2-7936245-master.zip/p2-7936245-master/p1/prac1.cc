// NIE Y7936245V TSKONYAN MARAT

#include <iostream>
#include <vector>
#include <string>

using namespace std;

const int KNAME = 40;
const int KMAXOBSTACLES = 20;
const int KMAXLVELS = 10;

enum Error
{
    ERR_OPTION,
    ERR_DIFFICULTY,
    ERR_LEVEL,
    ERR_COORDINATE,
    ERR_OBSTACLES,
    ERR_ID,
    ERR_INSTRUCTION
};

// Registro para las coordenadas
struct Coordinate
{
    int row;
    int column;
};

// Registro para el jugador
struct Player
{
    char name[KNAME];
    int difficulty;
    int score;
    int wins;
    int losses;
};

// Registro para el nivel
struct Level
{
    int id;
    int size;
    int numObstacles;
    Coordinate obstacles[KMAXOBSTACLES];
    Coordinate start;
    Coordinate finish;
};

struct allLevels
{
    int vec_row = 1, vec_col = 1;
    vector<vector<int>> map;
    allLevels() : map(vec_row, vector<int>(vec_col, 0)) {} // vector initalization
};

// Función que muestra los mensajes de error
void error(Error e)
{
    switch (e)
    {
    case ERR_OPTION:
        cout << "ERROR: wrong option" << endl;
        break;
    case ERR_DIFFICULTY:
        cout << "ERROR: wrong difficulty" << endl;
        break;
    case ERR_LEVEL:
        cout << "ERROR: cannot create level" << endl;
        break;
    case ERR_COORDINATE:
        cout << "ERROR: wrong coordinate" << endl;
        break;
    case ERR_OBSTACLES:
        cout << "ERROR: wrong number of obstacles" << endl;
        break;
    case ERR_ID:
        cout << "ERROR: wrong id" << endl;
        break;
    case ERR_INSTRUCTION:
        cout << "ERROR: wrong instruction" << endl;
        break;
    }
}

// Función que muestra el menú de opciones
void showMenu()
{
    cout << "[Options]" << endl
         << "1- Create level" << endl
         << "2- Delete level" << endl
         << "3- Show levels" << endl
         << "4- Play" << endl
         << "5- Report" << endl
         << "q- Quit" << endl
         << "Option: ";
}

void startMenu(Player &jugador)
{
    char playerName[KNAME];
    int Difficulty;
    bool difficultyCorrect = false;

    cout << "Name: ";
    cin.getline(playerName, KNAME);

    do
    {
        cout << "Difficulty: ";
        cin >> Difficulty;

        switch (Difficulty)
        {
        case 1:
            difficultyCorrect = true; // 5x5
            break;
        case 2:
            difficultyCorrect = true; // 7 x 7
            break;
        case 3:
            difficultyCorrect = true; // 10 x 10
            break;

        default:
            cout << "ERROR: wrong difficulty" << endl;
            cin.clear();              // without clearing incorrect input will generate infinite loop
            string ignoreLine;        // read the invalid input into it
            getline(cin, ignoreLine); // read the line till next space
            break;
        }

    } while (difficultyCorrect != true);

    for (int i = 0; i < KNAME; i++)
    {
        jugador.name[i] = playerName[i];
    }

    jugador.difficulty = Difficulty;
}

bool isNumeric(char c)
{
    return c >= '0' && c <= '9';
}

bool hasAdjacentCoordinates(const vector<pair<int, int>> &coords)
{
    // loop through each pair of coordinates in the vector
    for (size_t i = 0; i < coords.size(); i++)
    {
        int x1 = coords[i].first;
        int y1 = coords[i].second;

        // loop through the remaining pairs of coordinates in the vector
        for (size_t j = i + 1; j < coords.size(); j++)
        {
            int x2 = coords[j].first;
            int y2 = coords[j].second;

            // check if the current pair of coordinates is adjacent or the same point
            if (abs(x2 - x1) <= 1 && abs(y2 - y1) <= 1 && (x1 != x2 || y1 != y2))
            {
                // if the pair of coordinates is adjacent or the same point, return true
                return true;
            }
        }
    }
    // if no adjacent or same pairs of coordinates are found, return false
    return false;
}

bool hasRepeatedCoordinates(const vector<pair<int, int>> &coords)
{
    // Iterate over each coordinate in the input vector
    for (size_t i = 0; i < coords.size(); i++)
    {
        // Check each coordinate against all subsequent coordinates in the vector
        for (size_t j = i + 1; j < coords.size(); j++)
        {
            // If two coordinates are equal, return true (there is a repeated coordinate)
            if (coords[i] == coords[j])
            {
                return true;
            }
        }
    }
    return false;
}
// Parse and validate input, and add obstacle coordinates to vector
bool parseAndValidateInput(string input, vector<pair<int, int>> &coordinates, Player jugador, int &numPairs)
{
    size_t pos = 0;
    string token;
    // Find pairs of integers separated by a vertical bar in the input string
    while ((pos = input.find("|")) != string::npos)
    {
        token = input.substr(0, pos);
        input.erase(0, pos + 1);

        // Find the position of the comma separator in each pair of integers
        unsigned int comma_pos = token.find(",");

        // Check for invalid input format or characters
        if (comma_pos == string::npos)
        {
            // cout << "Error: Invalid input format" << endl;
            return false;
        }
        for (size_t i = 0; i < token.length(); i++)
        {
            if (!isNumeric(token[i]) && token[i] != ',')
            {
                // cout << "Error: Invalid character in input" << endl;
                return false;
            }
        }

        // Extract the row and column integer values and add them to the coordinates vector
        int row = stoi(token.substr(0, comma_pos));
        int col = stoi(token.substr(comma_pos + 1));
        coordinates.emplace_back(row, col);
        numPairs++;
    }

    unsigned int comma_pos = input.find(",");
    if (comma_pos == string::npos)
    {
        // cout << "Error: Invalid input format" << endl;
        return false;
    }

    // checks if character is digit or comma
    for (size_t i = 0; i < input.length(); i++)
    {
        if (!isNumeric(input[i]) && input[i] != ',')
        {
            //     cout << "Error: Invalid character in input" << endl;
            return false;
        }
    }

    // Extract the last pair of integers in the input string and add them to the coordinates vector
    int row = stoi(input.substr(0, comma_pos));
    int col = stoi(input.substr(comma_pos + 1));
    int bounds = 0;
    switch (jugador.difficulty)
    {
    case 1:
        bounds = 4;
        break;
    case 2:
        bounds = 6;
        break;
    case 3:
        bounds = 9;
        break;
    }

    // Check if the last pair of integers is within the bounds of the map
    if ((row > bounds) or (col > bounds))
    {
        // cout << "Out of map bounds" << endl;
        return false;
    }

    // Add the last pair of integers as a pair of coordinates to the vector
    coordinates.emplace_back(row, col);
    numPairs++;

    return true;
}

void renderLevel(Coordinate playerXY, allLevels maps[KMAXLVELS], int i, int j, int id)
{
    if (playerXY.row == i && playerXY.column == j)
    {
        cout << "R"; // Player
    }
    else if (maps[id].map[i][j] == 0)
    {
        cout << "O"; // Empty cells
    }
    else
    {
        switch (maps[id].map[i][j])
        {
        case -1:
            cout << "X"; // Obstacles
            break;

        case 70:
            cout << "F"; // Finish
            break;

        default:
            break;
        }
    }
}

void showLevel(Level niveles[KMAXLVELS], allLevels maps[KMAXLVELS], int id, Coordinate playerXY, bool levelTitle)
{
    if (levelTitle == true)
    {
        cout << "Level " << id + 1 << endl;
    }

    for (int i = 0; i < niveles[id].size; i++)
    {
        for (int j = 0; j < niveles[id].size; j++)
        {
            renderLevel(playerXY, maps, i, j, id);
        }
        cout << endl;
    }
}

void showAll(Level niveles[KMAXLVELS], allLevels maps[KMAXLVELS])
{

    Coordinate playerXY;
    int numLevels = 0;
    for (int i = 0; i < KMAXLVELS; i++)
    {
        if (niveles[i].id != -1)
        {
            numLevels++;
        }
    }
    for (int id = 0; id < numLevels; id++)
    {

        playerXY.row = niveles[id].start.column;
        playerXY.column = niveles[id].start.row;
        cout << "Level " << id + 1 << endl;

        for (int i = 0; i < niveles[id].size; i++)
        {
            for (int j = 0; j < niveles[id].size; j++)
            {
                renderLevel(playerXY, maps, i, j, id);
            }
            cout << endl;
        }
    }
}

void errorThrow(bool &errorThrown, Error err)
{
    errorThrown = true;
    error(err);
}

void errorReset(string &input, vector<pair<int, int>> &coordinates, int &numPairs)
{
    input = {};
    coordinates = {};
    numPairs = 0;
}

void levelSize(int id, Level niveles[KMAXLVELS], Player jugador, bool &isMax)
{
    if (id == KMAXLVELS + 1)
    {
        error(ERR_LEVEL);
        isMax = true;
    }
    else
    {

        niveles[id - 1].id = id;

        switch (jugador.difficulty)
        {
        case 1:
            niveles[id - 1].size = 5;

            break;

        case 2:
            niveles[id - 1].size = 7;

            break;

        case 3:
            niveles[id - 1].size = 10;

            break;

        default:
            break;
        }

        niveles[id - 1].start.row = 0;
        niveles[id - 1].start.column = niveles[id - 1].size - 1;

        niveles[id - 1].finish.row = niveles[id - 1].size - 1;
        niveles[id - 1].finish.column = 0;
    }
}

void levelDifficulty(bool &errorThrown, string &input, vector<pair<int, int>> &coordinates, Player jugador, int numPairs)
{
    cout << "Obstacles: ";
    getline(cin, input);
    int maxPairs = 0;

    switch (jugador.difficulty)
    {
    case 1:
        maxPairs = KMAXOBSTACLES / 4;
        break;
    case 2:
        maxPairs = KMAXOBSTACLES / 2;
        break;
    case 3:
        maxPairs = KMAXOBSTACLES;
        break;
    }

    if (!parseAndValidateInput(input, coordinates, jugador, numPairs))
    {
        errorThrow(errorThrown, ERR_COORDINATE);
        errorReset(input, coordinates, numPairs);
    }

    if (numPairs > maxPairs and errorThrown != true)
    {
        errorThrow(errorThrown, ERR_OBSTACLES);
        errorReset(input, coordinates, numPairs);
    }

    if (hasAdjacentCoordinates(coordinates) and errorThrown != true)
    {
        errorThrow(errorThrown, ERR_COORDINATE);
        errorReset(input, coordinates, numPairs);
    }

    if (hasRepeatedCoordinates(coordinates) and errorThrown != true)
    {
        errorThrow(errorThrown, ERR_COORDINATE);
        errorReset(input, coordinates, numPairs);
    }
}

void addObstacles(bool &errorThrown, bool &correctCoordinate, allLevels maps[KMAXLVELS], string &input, vector<pair<int, int>> &coordinates,
                  int &numPairs, Level niveles[KMAXLVELS], int &vecSize, int &id, bool &levelTitle, bool &isMax)
{
    if (errorThrown != true)
    {

        maps[id - 1].map[niveles[id - 1].finish.column][niveles[id - 1].finish.row] = 'F';

        // Insert all pairs into map
        for (auto coord : coordinates)
        {
            maps[id - 1].map[coord.first][coord.second] = -1;
        }
        niveles[id - 1].numObstacles = numPairs;

        if (maps[id - 1].map[niveles[id - 1].start.column][niveles[id - 1].start.row] != 0 or maps[id - 1].map[niveles[id - 1].finish.column][niveles[id - 1].finish.row] != 'F')
        {
            errorThrow(errorThrown, ERR_COORDINATE);
            errorReset(input, coordinates, numPairs);
            maps[id - 1].map.assign(vecSize, vector<int>(vecSize, 0));
        }
    }

    if (errorThrown != true)
    {

        int index = 0;

        // Insert obstacles coordinates into the Level struct array
        for (auto coord : coordinates)
        {
            index++;
            niveles[id - 1].obstacles[index - 1].row = coord.first;
            niveles[id - 1].obstacles[index - 1].column = coord.second;
        }

        Coordinate playerXY;
        playerXY.row = niveles[id - 1].start.column;
        playerXY.column = niveles[id - 1].start.row;
        showLevel(niveles, maps, id - 1, playerXY, levelTitle);

        id++; // increment to next map

        correctCoordinate = true;
    }
}

void createLevel(Level niveles[KMAXLVELS], int &id, Player jugador, allLevels maps[KMAXLVELS])
{

    bool correctCoordinate = false, isMax = false, levelTitle = true;
    int vecSize, numPairs = 0;
    ;
    string input;
    vector<pair<int, int>> coordinates;

    levelSize(id, niveles, jugador, isMax);

    if (isMax != true)
    {
        vecSize = niveles[id - 1].size; // id at star is 1, and after each call of the createLevel(). So because it's -1 and not just 'id'.
        maps[id - 1].map.resize(vecSize);
        for (int i = 0; i < vecSize; ++i) // resizing each row of the vector, iterating line by line
        {
            maps[id - 1].map[i].resize(vecSize);
        }
    }

    if (isMax != true)
    {

        while (correctCoordinate != true)
        {
            bool errorThrown = false;

            levelDifficulty(errorThrown, input, coordinates, jugador, numPairs);

            addObstacles(errorThrown, correctCoordinate, maps, input, coordinates, numPairs, niveles, vecSize, id, levelTitle, isMax);
        }
    }
}

void deleteLevel(Level niveles[KMAXLVELS], allLevels maps[KMAXLVELS])
{
    int id;
    bool trueID = false, youSure = false;

    cout << "Id:";
    cin >> id;
    if (niveles[id - 1].id >= 1 and niveles[id - 1].id <= 10)
    {
        trueID = true;
    }
    else
    {
        cout << "Error: wrong id" << endl;
    }
    if (trueID == true)
    {
        char option;
        cout << "Are you sure? [y/n] ";
        cin >> option;

        switch (option)
        {
   //   case 'y': 
        case 'Y': // in PDF it's small y, but autocorrector wants a capital letter Y
            youSure = true;
            break;
        case 'n':
            youSure = false;
            break;
        default:
            youSure = false;
            break;
        }
        if (youSure == true)
        {
            // Shift levels to the left
            for (int i = id - 1; i < KMAXLVELS - 1; i++)
            {
                niveles[i] = niveles[i + 1];
                maps[i] = maps[i + 1];
            }
            // Update IDs of remaining levels
            for (int i = id - 1; i < KMAXLVELS - 1; i++)
            {
                if (niveles[i].id != -1)
                {
                    niveles[i].id = i + 1;
                }
            }
        }
    }
}

void gameOver(Level niveles[KMAXLVELS], allLevels maps[KMAXLVELS], bool &youLose, Coordinate playerXY, int id)
{
    if (maps[id - 1].map[playerXY.row][playerXY.column] == -1)
    {
        youLose = true;
        cout << "ERROR: wrong instruction" << endl;
    }
    else if (playerXY.row >= niveles[id - 1].size or playerXY.row < 0 or playerXY.column >= niveles[id - 1].size or playerXY.column < 0)
    {
        youLose = true;
        cout << "ERROR: wrong instruction" << endl;
    }
}

void playerMovement(string instructions, Coordinate &playerXY, Level niveles[KMAXLVELS], allLevels maps[KMAXLVELS], bool &youLose, int id, bool levelTitle, int i)
{
    switch (instructions[i])
    {

    case 'U':
        playerXY.row -= 1;
        gameOver(niveles, maps, youLose, playerXY, id);
        if (youLose != true)
        {
            cout << "Instruction U" << endl;
            showLevel(niveles, maps, id - 1, playerXY, levelTitle);
        }
        break;
    case 'D':
        playerXY.row += 1;
        gameOver(niveles, maps, youLose, playerXY, id);
        if (youLose != true)
        {
            cout << "Instruction D" << endl;
            showLevel(niveles, maps, id - 1, playerXY, levelTitle);
        }
        break;
    case 'L':
        playerXY.column -= 1;
        gameOver(niveles, maps, youLose, playerXY, id);
        if (youLose != true)
        {
            cout << "Instruction L" << endl;
            showLevel(niveles, maps, id - 1, playerXY, levelTitle);
        }
        break;
    case 'R':
        playerXY.column += 1;
        gameOver(niveles, maps, youLose, playerXY, id);
        if (youLose != true)
        {
            cout << "Instruction R" << endl;
            showLevel(niveles, maps, id - 1, playerXY, levelTitle);
        }
        break;
    default:
        cout << "ERROR: wrong instruction" << endl;
        youLose = true;
        break;
    }
}

void playLevel(Level niveles[KMAXLVELS], allLevels maps[KMAXLVELS], Player &jugador)
{
    Coordinate playerXY;
    string instructions;
    int sizeIns = 0, points = 0, id;
    bool youLose = false, trueID = false, levelTitle = true;

    cout << "Id: ";
    cin >> id;
    if (niveles[id - 1].id >= 1 and niveles[id - 1].id <= 10)
    {
        trueID = true;
    }
    else
    {
        cout << "Error: wrong id" << endl;
    }
    if (trueID == true)
    {
        playerXY.row = niveles[id - 1].start.column;
        playerXY.column = niveles[id - 1].start.row;

        showLevel(niveles, maps, id - 1, playerXY, levelTitle);
        levelTitle = false;
        cout << "Instructions: ";
        cin >> instructions;

        sizeIns = instructions.size();

        for (int i = 0; i < sizeIns; i++)
        {
            playerMovement(instructions, playerXY, niveles, maps, youLose, id, levelTitle, i);
        }
        if ((playerXY.row != niveles[id - 1].finish.column && playerXY.column != niveles[id - 1].finish.row) || youLose == true)
        {
            jugador.losses += 1;
            cout << "You lose" << endl;
        }
        else
        {
            points = 3 * (niveles[id - 1].size - 1) - sizeIns;
            jugador.score += points;
            jugador.wins += 1;
            cout << "You win " << points << " points" << endl;
        }
    }
}

void playerReport(Player jugador)
{
    string s_difficulty;

    switch (jugador.difficulty)
    {
    case 1:
        s_difficulty = "Easy";
        break;
    case 2:
        s_difficulty = "Medium";
        break;
    case 3:
        s_difficulty = "Hard";
        break;
    default:
        break;
    }

    cout << "[Report]" << endl;
    cout << "Name: " << jugador.name << endl;
    cout << "Difficulty: " << s_difficulty << endl;
    cout << "Score: " << jugador.score << endl;
    cout << "Wins: " << jugador.wins << endl;
    cout << "Losses: " << jugador.losses << endl;
    cout << "Total: " << jugador.losses + jugador.wins << endl;
}

// Función principal (tendrás que añadirle más código tuyo)
int main()
{
    char option;
    Player jugador;
    jugador.wins = 0;
    jugador.losses = 0;
    jugador.score = 0;
    Level niveles[KMAXLVELS];
    int id = 1;
    allLevels maps[KMAXLVELS];

    for (int i = 0; i < KMAXLVELS; i++) // without it code will work, but it's going to create unconditional jumps in showAll function
    {
        niveles[i].id = -1; // So better to preinitialize all IDs as a -1
    }
    startMenu(jugador);

    do
    {
        showMenu();
        cin >> option;
        cin.get(); // Para evitar que el salto de línea se quede en el buffer de teclado y luego pueda dar problemas si usas "getline"

        switch (option)
        {
        case '1': // Llamar a la función para crear un nuevo nivel
            createLevel(niveles, id, jugador, maps);
            break;
        case '2': // Llamar a la función para borrar un nivel existente
            deleteLevel(niveles, maps);
            break;
        case '3': // Llamar a la función para mostrar los niveles creados
            showAll(niveles, maps);
            break;
        case '4': // Llamar a la función para jugar
            playLevel(niveles, maps, jugador);
            break;
        case '5': // Llamar a la función para mostrar información del jugador
            playerReport(jugador);
            break;
        case 'q':
            break;
        default:
            error(ERR_OPTION); // Muestra "ERROR: wrong option"
        }
    } while (option != 'q');

    return 0;
}
