#include "Coordinate.h"
#include "Util.h"

// Constructor por defecto, inicializa las coordenadas y el estado de la celda
Coordinate::Coordinate()
{
    row = -1;
    column = -1;
    state = NONE;
}

// Constructor con coordenadas específicas
Coordinate::Coordinate(int row, int column)
{
    this->row = row;
    this->column = column;
    state = NONE;
}

// Constructor con coordenadas en formato string (e.g. "A1")
Coordinate::Coordinate(std::string coord)
{
    std::string aux;
    row = coord[0] - 'A';
    aux = coord.substr(1);
    column = std::stoi(aux) - 1; // Usa std::stoi en lugar de atoi
    state = NONE;
}

// Devuelve la fila de la coordenada
int Coordinate::getRow() const
{
    return row;
}

// Devuelve la columna de la coordenada
int Coordinate::getColumn() const
{
    return column;
}

// Devuelve el estado de la celda
CellState Coordinate::getState() const
{
    return state;
}

// Devuelve el caracter que representa el estado de la celda
char Coordinate::getStateChar() const
{
    char letter;
    switch (state)
    {
    case NONE:
        letter = 'N';
        break;
    case SHIP:
        letter = 'S';
        break;
    case HIT:
        letter = 'H';
        break;
    case WATER:
        letter = 'W';
        break;
    }
    return letter;
}

// Establece el valor de la fila de la coordenada
void Coordinate::setRow(int row)
{
    this->row = row;
}

// Establece el valor de la columna de la coordenada
void Coordinate::setColumn(int column)
{
    this->column = column;
}

// Establece el estado de la celda
void Coordinate::setState(CellState state)
{
    this->state = state;
}

// Compara dos coordenadas y devuelve true si son iguales, false en caso contrario
bool Coordinate::compare(const Coordinate &coord) const
{
    return row == coord.row && column == coord.column;
}

// Agrega un desplazamiento a la coordenada en la dirección especificada y devuelve la nueva coordenada resultante
Coordinate Coordinate::addOffset(int offset, Orientation orientation) const
{
    Coordinate res;
    res.row = row;
    res.column = column;
    switch (orientation)
    {
    case NORTH:
        res.row -= offset;
        break;
    case SOUTH:
        res.row += offset;
        break;
    case EAST:
        res.column += offset;
        break;
    case WEST:
        res.column -= offset;
        break;
    }
    return res;
}

// Convierte un caracter en la orientación correspondiente
Orientation Coordinate::orientationFromChar(char orientation)
{
    Orientation result;
    switch (orientation)
    {
    case 'N':
        result = NORTH;
        break;
    case 'S':
        result = SOUTH;
        break;
    case 'E':
        result = EAST;
        break;
    case 'W':
        result = WEST;
        break;
    default:
        throw EXCEPTION_WRONG_ORIENTATION;
        break;
    }
    return result;
}

std::ostream &operator<<(std::ostream &output_coord, const Coordinate &c)
{
    // Verifica si la coordenada tiene valores válidos
    if (c.getColumn() != -1 && c.getRow() != -1)
    {
        // Verifica si el estado de la celda no es NONE
        if (c.getStateChar() != 'N')
        {
            output_coord << static_cast<char>(c.row + 'A') << c.column + 1 << c.getStateChar();
        }
        else
        {
            output_coord << static_cast<char>(c.row + 'A') << c.column + 1;
        }
    }
    else
    {
        output_coord << "--";
    }
    return output_coord;
}
