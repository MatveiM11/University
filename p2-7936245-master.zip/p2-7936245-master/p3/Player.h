#ifndef _PLAYER_H_
#define _PLAYER_H_
#include "Coordinate.h"
#include "Ship.h"
#include "Util.h"
#include <vector>
#include <string>
#include <array>

const int BOARDSIZE = 10;

class Player
{
protected:
    std::string name;
    std::array<std::array<Coordinate, BOARDSIZE>, BOARDSIZE> board; // array para tamano fijo
    std::vector<Ship> ships;

public:
    Player(std::string name);
    std::string getName() const;
    void addShip(const Coordinate &pos, ShipType type, Orientation orientation);
    void addShips(std::string ships);
    bool attack(const Coordinate &coord);
    bool attack(std::string coord);

    friend std::ostream &operator<<(std::ostream &os, const Player &player);
};

#endif
