#ifndef SHIP_H_
#define SHIP_H_
#include "Coordinate.h"
#include "Util.h"
#include <vector>

enum ShipType
{
	BATTLESHIP,
	DESTROYER,
	CRUISE,
	SUBMARINE
};

enum ShipState
{
	OK,
	DAMAGED,
	SUNK
};

class Ship
{
protected:
	ShipState state;
	ShipType type;
	std::vector<Coordinate *> positions; // Uso del espacio de nombres std

public:
	Ship(ShipType type, const std::vector<Coordinate *> &positions);
	static unsigned shipSize(ShipType type);
	static ShipType typeFromChar(char type);
	Coordinate *getPosition(unsigned pos) const;
	ShipType getType() const;
	ShipState getState() const;
	bool hit(const Coordinate &coord);

	friend std::ostream &operator<<(std::ostream &os, const Ship &ship); // Uso del espacio de nombres std
};

#endif
