#include <iostream>
#include "Ship.h"

Ship::Ship(ShipType type, const std::vector<Coordinate *> &positions)
{
    // Verificar que el número de posiciones coincida con el tamaño del barco
    if (positions.size() != shipSize(type))
    {
        throw EXCEPTION_WRONG_COORDINATES;
    }

    this->state = OK;
    this->type = type;
    this->positions = positions;
    for (auto &position : positions)
    {
        position->setState(SHIP); // Establecer el estado de las posiciones del barco como "SHIP"
    }
}

unsigned Ship::shipSize(ShipType type)
{
    // Devolver el tamaño del barco según su tipo
    switch (type)
    {
    case BATTLESHIP:
        return 4;
    case DESTROYER:
        return 3;
    case CRUISE:
        return 2;
    case SUBMARINE:
        return 1;
    default:
        return 0; // Caso por defecto en caso de tipo de barco inválido
    }
}

ShipType Ship::typeFromChar(char type)
{
    // Convertir el caracter de tipo de barco en el tipo enumerado correspondiente
    ShipType stype;
    switch (type)
    {
    case 'B':
        stype = BATTLESHIP;
        break;
    case 'C':
        stype = CRUISE;
        break;
    case 'D':
        stype = DESTROYER;
        break;
    case 'S':
        stype = SUBMARINE;
        break;
    default:
        throw EXCEPTION_WRONG_SHIP_TYPE; // Lanzar excepción en caso de tipo de barco inválido
        break;
    }
    return stype;
}

Coordinate *Ship::getPosition(unsigned pos) const
{
    Coordinate *r = NULL;
    if (pos >= 0 && pos < positions.size())
    {
        r = positions[pos];
    }
    return r;
}

ShipType Ship::getType() const
{
    return type;
}

ShipState Ship::getState() const
{
    return state;
}

bool Ship::hit(const Coordinate &coord)
{
    bool result = false;
    unsigned int pos, number_hits;

    // Buscar la posición del barco que coincide con la coordenada
    for (auto i = 0u; i < positions.size() && !result; ++i)
    {
        if (coord.compare(*positions[i]))
        {
            result = true;
            pos = i;
        }
    }

    if (result)
    {
        switch (state)
        {
        case SUNK:
            throw EXCEPTION_ALREADY_SUNK;
            break;
        default:
            if (positions[pos]->getState() == HIT)
            {
                throw EXCEPTION_ALREADY_HIT;
            }
            break;
        }

        positions[pos]->setState(HIT); // Establecer el estado de la posición como "HIT"

        number_hits = 0;
        for (auto i = 0u; i < positions.size(); ++i)
        {
            if (positions[i]->getState() == HIT)
            {
                number_hits++;
            }
        }
        if (number_hits == shipSize(type))
        {
            state = SUNK; // Establecer el estado del barco como "SUNK" si todas las posiciones han sido impactadas
        }
        else
        {
            state = DAMAGED; // Establecer el estado del barco como "DAMAGED" si solo algunas posiciones han sido impactadas
        }
        result = true;
    }
    return result;
}

std::ostream &operator<<(std::ostream &output_ship, const Ship &ship)
{
    static const std::string names[] = {"BATTLESHIP", "DESTROYER", "CRUISE", "SUBMARINE"};
    static const std::string states[] = {"O", "D", "S"};

    output_ship << names[ship.type] << " (" << states[ship.state] << "): ";
    for (const auto &position : ship.positions)
    {
        output_ship << *position << " ";
    }
    return output_ship;
}
