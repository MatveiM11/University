#include <iostream>
#include "Util.h"

// Implementación de la función de error en la clase Util
void Util::error(Error e)
{
  // Un switch es una estructura de control que permite
  // elegir una acción o secuencia de acciones a realizar
  // de entre varias posibles, en función del valor de la variable 'e'.
  switch (e)
  {
  // En caso de que el error sea ERR_SHIPS
  case ERR_SHIPS:
    // Se imprime un mensaje de error
    std::cout << "ERROR: cannot place ships" << ::std::endl;
    break;
  // En caso de que el error sea ERR_GAME_OVER
  case ERR_GAME_OVER:
    // Se imprime un mensaje de fin de juego
    std::cout << "GAME OVER!!" << ::std::endl;
    break;
  }
}

// Implementación de la función de depuración en la clase Util
void Util::debug(Exception e)
{
  // Creación de una matriz constante de cadenas de texto que almacena
  // los tipos de excepciones que pueden ocurrir en el programa
  const std::string EXCEPT_STR[] = {
      "EXCEPTION_WRONG_ORIENTATION",
      "EXCEPTION_WRONG_SHIP_TYPE",
      "EXCEPTION_WRONG_COORDINATES",
      "EXCEPTION_MAX_SHIP_TYPE",
      "EXCEPTION_GAME_STARTED",
      "EXCEPTION_OUTSIDE",
      "EXCEPTION_NONFREE_POSITION",
      "EXCEPTION_ALREADY_SUNK",
      "EXCEPTION_ALREADY_HIT",
      "EXCEPTION_GAME_OVER"};

  // Se imprime un mensaje de depuración con el tipo de excepción
  std::cout << "DEBUG: error produced by exception " << EXCEPT_STR[e] << ::std::endl;
}
