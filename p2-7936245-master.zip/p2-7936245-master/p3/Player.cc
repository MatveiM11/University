// Programacion 2 - Practica 3
// DNI: Y7936245V
// Nombre: Marat Tskonyan

#include "Player.h"
#include <sstream>
#include <algorithm>

Player::Player(std::string name) : name(name) {
    // Inicializar las coordenadas del tablero
    for (auto& row : board) {
        for (auto& coordinate : row) {
            coordinate.setRow(&row - &board[0]);
            coordinate.setColumn(&coordinate - &row[0]);
        }
    }
}

std::string Player::getName() const {
    return name;
}

void Player::addShip(const Coordinate &pos, ShipType type, Orientation orientation)
{
    int size, count;

    count = 0;
    // Contar la cantidad de barcos del mismo tipo existentes
    for (const auto &ship : ships)
    {
        if (type == ship.getType())
        {
            count++;
        }
    }

    // Verificar que no se exceda el límite de barcos del mismo tipo
    if ((type == BATTLESHIP && count == 1) ||
        (type == DESTROYER && count == 2) ||
        (type == CRUISE && count == 3) ||
        (type == SUBMARINE && count == 4))
    {
        throw EXCEPTION_MAX_SHIP_TYPE;
    }

    // Verificar que no se haya iniciado el juego
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (board[i][j].getState() == WATER || board[i][j].getState() == HIT)
            {
                throw EXCEPTION_GAME_STARTED;
            }
        }
    }

    size = Ship::shipSize(type);
    std::vector<Coordinate *> positions;

    for (int i = 1; i <= size; i++)
    {
        Coordinate coordinate = pos.addOffset(i - 1, orientation);

        if (coordinate.getRow() < 0 || coordinate.getRow() > 9 || coordinate.getColumn() < 0 || coordinate.getColumn() > 9)
        {
            throw EXCEPTION_OUTSIDE;
        }

        if (board[coordinate.getRow()][coordinate.getColumn()].getState() == SHIP)
        {
            throw EXCEPTION_NONFREE_POSITION;
        }

        positions.push_back(&board[coordinate.getRow()][coordinate.getColumn()]);
    }

    // Crear un nuevo barco y añadirlo a la lista de barcos del jugador
    Ship newShip(type, positions);
    ships.push_back(newShip);
}



void Player::addShips(std::string ships) {
    Coordinate origin;
    int row, column;
    ShipType type;
    Orientation orientation;
    std::stringstream s_ship;
    std::string chain;

    s_ship << ships;
    // Leer y añadir los barcos hasta que se termine la cadena de entrada
    do {
        s_ship >> chain;
        if (chain != "") {
            type = Ship::typeFromChar(chain[0]);
            row = chain[2] - 'A';
            int i = 3;
            std::string aux = "";
            while (chain[i] != '-') {
                aux += chain[i];
                i++;
            }
            column = std::stoi(aux) - 1;
            i++;
            orientation = Coordinate::orientationFromChar(chain[i]);
            origin = Coordinate(row, column);
            addShip(origin, type, orientation);
        }
    } while (!s_ship.eof());
}

bool Player::attack(const Coordinate &coord) {
    bool isHit = false;

    try {
        // Realizar el ataque en cada barco del oponente
        for (auto &ship : ships) {
            if (ship.hit(coord)) {
                isHit = true;
                // Verificar si el barco ha sido hundido
                if (ship.getState() == SUNK) {
                    // Verificar si todos los barcos del oponente han sido hundidos
                    bool allSunk = std::all_of(ships.begin(), ships.end(),
                        [](Ship& s){ return s.getState() == SUNK; });
                    if (allSunk) {
                        throw EXCEPTION_GAME_OVER;
                    }
                }
                break;
            }
        }
        if (!isHit) {
            board[coord.getRow()][coord.getColumn()].setState(WATER);
        }
    } catch (Exception e) {
        isHit = false;
    }
    return isHit;
}

bool Player::attack(std::string coord) {
    Coordinate coordinate(coord);
    bool attackResult = attack(coordinate);
    return attackResult;
}

std::ostream& operator<<(std::ostream& output_ship, const Player& player) {
    output_ship << player.name << '\n';

    // Imprimir los números de columna
    for (int i = 1; i <= BOARDSIZE; i++) {
        output_ship << " " << i << (i != 10 ? " " : "");
    }
    output_ship << '\n';

    // Imprimir el tablero del jugador
    for (int rowIndex = 0; rowIndex < BOARDSIZE; ++rowIndex) {
        output_ship << static_cast<char>('A' + rowIndex);
        for (int columnIndex = 0; columnIndex < BOARDSIZE; ++columnIndex) {
            // Asegurarse de que ambos resultados posibles de la operación ternaria sean de tipo char
            output_ship << " " << (player.board[rowIndex][columnIndex].getState() != NONE ? player.board[rowIndex][columnIndex].getStateChar() : ' ') << " ";
        }
        output_ship << '\n';
    }

    // Imprimir los barcos del jugador
    for (const auto& ship : player.ships) {
        output_ship << ship << '\n';
    }

    return output_ship;
}
