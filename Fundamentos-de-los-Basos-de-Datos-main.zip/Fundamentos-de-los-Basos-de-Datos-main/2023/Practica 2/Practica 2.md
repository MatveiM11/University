
# P02 - TiendaOnLine: varias tablas
https://drive.google.com/file/d/1x-r0FexXpTkGkYo6AGAkEsSEAVlD5EeB/view?pli=1


