# Summary
T13.001: A view called VusuAli is created to show users from Alicante province (code '03').

T13.002: Users from Alicante province are listed in alphabetical order by their last names and first names using the VusuAli view.

T13.003: Users named Carolina or Iloveny from Alicante province are listed in alphabetical order by their last names and first names using the VusuAli view.

T13.004: An attempt to delete users named Carolina or Iloveny from Alicante province using the VusuAli view fails.

T13.005: An attempt to insert a new user using VusuAli fails.

T13.006: A view called Tpedidos is created to show the total amount to be paid for each order in TIENDAONLINE and its date.

T13.007: The email, name, and last name of users from Alicante are listed, and if they have orders, the total amount paid by the user is also shown.

T13.008: Another view called TApedidos is created to show the total amount to be paid for each order made by users from Alicante and their date (only date).

T13.009: The previous view is used to modify the previous solution and list all email, name, and last name of users, and if they have orders, the total paid by the user.

T13.010: A table called "usuAlm" is created with the same structure as the tiendaonline.usuario table.

T13.011: A new user is inserted using the VusuAlm view successfully.

T13.012: All rows of users are deleted using the VusuAlm view, and two new users are inserted into the USUARIO table.

T13.013: An attempt to insert a user from Alicante (code '03') using VusuAlm fails due to the CHECK OPTION constraint.

T13.014: Users from Almería province are added, and the user has to decide which tables are needed in their database and which ones will be used only as references from TIENDAONLINE.

T13.015: A list of email, last name, first name, and names of the city and province is generated for all users, including Almería users and the rest of the users from TIENDAONLINE.

T13.016: A view called TApedidosAlm is created to show the order number, user, date, and total paid for each order made in the Almería delegation.

T13.017: VusuAlm and TApedidosAlm are used to display all Almería users (email, name, and last name) and, if they have orders, the order number and total paid for each of their orders.

# Soluciones

T13.001- Crea una vista (VusuAli) de la delegación de Alicante que permite ver los usuarios de la provincia de Alicante (de código '03').
```SQL
create or replace view VusuAli as select * from tiendaonline.usuario where provincia='03';
```
Como solo tienes permisos de lectura en TIENDAONLINE solo eso puedes hacer en esta vista, consultar.

T13.002- Con la vista anterior, lista a todos los usuarios de la provincia de Alicante ordenados por apellidos y nombre.
```SQL
select * from VusuAli order by apellidos,nombre;
```

T13.003- Con la vista anterior, lista a todos los usuarios de la provincia de Alicante que se llamen Carolina o Iloveny, ordenados por apellidos y nombre.
```SQL
select * from VusuAli where nombre in ('Carolina','Iloveny') order by apellidos,nombre;
```

T13.004- Usando la vista anterior elimina a los usuarios de la provincia de Alicante que se llamen Carolina o Iloveny.
¿Qué ha pasado? ¿Por qué?
```SQL
delete from VusuAli where nombre in ('Carolina','Iloveny');
```
Esta orden falla.

T13.005- Intenta insertar mediante VusuAli (email,dni,apellidos,nombre,provincia,pueblo)
('yoyo@gmial.es','99888777R','FERNANDEZ FERNANDEZ','ROSA','04','1225')
¿Qué ha pasado? ¿Por qué?
```SQL
insert into VusuAli (email,dni,apellidos,nombre,provincia,pueblo) values 
('yoyo@gmial.es','99888777R','FERNANDEZ FERNANDEZ','ROSA','04','1225'); -- esta orden fallará porque no tenemos permisos de inserción en la base de datos tiendaonline.
```
Esta orden falla.

T13.006- Crea una vista que nos informe del total del importe a pagar por cada pedido en TIENDAONLINE y su fecha. Comprueba que nos da los datos correctos.
```SQL
create or replace view Tpedidos as
select p.numpedido,sum(importe*cantidad) total,date(fecha)
from tiendaonline.pedido p, tiendaonline.linped l where p.numpedido=l.numpedido
group by p.numpedido,fecha;

--comprobamos que la consulta y la vista obtienen el mismo resultado
select p.numpedido,sum(importe*cantidad) total,date(fecha)
from tiendaonline.pedido p, tiendaonline.linped l where p.numpedido=l.numpedido
group by p.numpedido,fecha;
select * from Tpedidos;
```

T13.007- Usando las vistas previas, lista todos los email, nombre y apellidos de usuario de Alicante, y si tienen pedidos también el total pagado por el usuario.
```SQL
select u.email,u.apellidos,u.nombre,pp.pagado
from VusuAli u
left join
(
    select usuario, sum(total) pagado
    from tiendaonline.pedido p -- necesitamos esta tabla porque la vista Tpedidos no incluye la información de usuario
    join Tpedidos t on p.numpedido=t.numpedido
    group by usuario
) pp
on pp.usuario=u.email
```
Si la vista no tiene toda la información necesaria, no hay problema en recurrir a las tablas del esquema de base de datos de trabajo.

T13.008- Crea otra vista que nos informe del total del importe a pagar por cada pedido hecho por usuarios de Alicante y su fecha (solo fecha).
```SQL
create or replace view TApedidos as
select p.numpedido,sum(importe*cantidad) total,date(fecha),usuario  
from tiendaonline.pedido p join tiendaonline.linped l on p.numpedido=l.numpedido 
where usuario in (select email from tiendaonline.usuario where provincia='03')
group by p.numpedido,date(fecha),usuario;
```
En esta vista estamos limitando la información a únicamente pedidos hechos por usuarios de Alicante.

T13.009- Usando la nueva vista previa, modifica tu solución anterior y lista todos los email, nombre y apellidos de usuario, y si tienen pedidos también el total pagado por el usuario.
```SQL
select u.email,u.apellidos,u.nombre,pp.total
from VusuAli u
left join TApedidos pp
on pp.usuario=u.email;
```
El objetivo de estos ejercicios es que te des cuenta de lo que puedes añadir a una vista en función de la consulta que quieras diseñar y los requisitos de seguridad que pudieras querer imponer a los que usen esas vistas.

Fíjate que no hemos necesitado filtrar nada, las vistas ya trabajan únicamente con datos de usuarios de Alicante.

T13.010- Crea en tu base de datos una tabla con la misma estructura que tiendaonline.usuario. Tu tabla se llamará "usuAlm".

```SQL
CREATE TABLE usuAlm LIKE tiendaonline.usuario
```
La orden anterior crea una nueva tabla (usuAlm) con las columnas de tiendaonline.usuario y la clave primaria, pero sin claves ajenas, si las hubiere. Si las necesitas, debes usar ALTER TABLE. La nueva tabla no tiene filas aún.

Cuando tengas la tabla anterior, crea una vista "VusuAlm" que permita gestionar (altas, bajas, modificaciones y consultas) a los usuarios de Almería (código '04') y de ninguna otra.
```SQL
create table usuAlm like tiendaonline.usuario; -- esto crea una tabla idéntica excepto en las claves ajenas que, para añadirlas, habría que usar ALTER TABLE

create view VusuAlm as select * from usuAlm where provincia='04' with check option; -- CHECK OPTION es necesario para evitar que se puedan insertar usuarios de otras provincias
```
Tanto la tabla base como la vista pertenecen a tu base de datos y, por tanto, tienes todos los permisos necesarios para trabajar con ellas.

Podemos pensar que el objetivo es permitir la gestión de nuestra tabla USUARIO mediante la vista, eso nos asegura que solo se podrán manejar datos de usuarios de Almería.

T13.011- Intenta insertar mediante VusuAlm (email,dni,apellidos,nombre,provincia,pueblo)
('rgg2@gmial.es','11222333R','GOMEZ GOMEZ','ROSA','04','1002')
¿Qué ha pasado? ¿Por qué?
```SQL
insert into VusuAlm (email,dni,apellidos,nombre,provincia,pueblo) values 
('rgg2@gmial.es','11222333R','GOMEZ GOMEZ','ROSA','04','1002');
-- hemos podido insertar porque la tabla base (usuAlm) está en nuestra base de datos, y tenemos permiso para ello
```
T13.012- Utilizando VusuAlm elimina todas las posibles filas de usuarios que tengas e inserta en tu tabla USUARIO a estos 2 usuarios (email,dni,apellidos,nombre,provincia,pueblo):

```SQL
('rff20@gmial.es','11222333R','FERNANDEZ FERNANDEZ','ROSA','04','0530')
('jmm119@gmial.es','22333444T','MARTINEZ MARTINEZ','JULIA','04','1002')
delete from VusuAlm;

insert into VusuAlm (email,dni,apellidos,nombre,provincia,pueblo) values 
('rff20@gmial.es','11222333R','FERNANDEZ FERNANDEZ','ROSA','04','0530'),
('jmm119@gmial.es','22333444T','MARTINEZ MARTINEZ','JULIA','04','1002');

```

T13.013- Intenta insertar mediante VusuAlm (email,dni,apellidos,nombre,provincia,pueblo)
('tutu@gmial.es','00999000T','LOPEZ DE LOPEZ','ANA','03','1225')
¿Qué ha pasado? ¿Por qué?
```SQL
insert into VusuAlm (email,dni,apellidos,nombre,provincia,pueblo) values 
('tutu@gmial.es','00999000T','LOPEZ DE LOPEZ','ANA','03','1225');
-- Estamos intentando insertar una usuaria de Alicante ('03'), pero la vista no permite otra provincia que Almeria ('04') por el CHECK OPTION
```

T13.014- Vas a montar la delegación de Almería. En TIENDAONLINE no hay ningún usuario de esa provincia. Ya tienes 2 usuarios (ejercicio 12), inserta algunos pedidos para alguno de ellos.

La tabla usuAlm ya la tienes aunque sin clave ajena a localidad.

```SQL
ALTER TABLE usuAlm ADD FOREIGN KEY (pueblo, provincia) REFERENCES tiendaonline.localidad (codm,provincia);
```
La orden anterior añade dicha clave ajena. Fíjate que hace referencia la tabla LOCALIDAD en TIENDAONLINE. Eso quiere decir que no necesitas esta tabla en tu base de datos, la vas a manejar mediante vistas.

Debes decidir qué otras tablas necesitas en tu base de datos y cuáles solo vas a utilizar como referencia desde TIENDAONLINE —y no necesitas recrearlas—.
```SQL
ALTER TABLE usuAlm ADD FOREIGN KEY (pueblo, provincia) REFERENCES tiendaonline.localidad (codm,provincia);

create table pedidosAlm like tiendaonline.pedido;
alter table pedidosAlm add foreign key (usuario) references usuAlm(email);

create table lineasAlm like tiendaonline.linped;
alter table lineasAlm add foreign key (numpedido) references pedidosAlm(numpedido);
alter table lineasAlm add foreign key (articulo) references tiendaonline.articulo(cod);

insert into pedidosAlm (numpedido, usuario, fecha) values (1,'rff20@gmial.es',now());
insert into lineasAlm (numpedido,linea,articulo,cantidad,importe) values
(1,1,'A0685',10,100),(1,2,'A1234',2,10);

-- comprobamos los datos
select * from usuAlm;
select * from pedidosAlm;
select * from lineasAlm;
select * from cestasAlm;
```

T13.015- Tienes a tus usuarios de Almería, y acceso al resto de usuarios de TIENDAONLINE. De tus usuarios, los de Almería, y de todos los demás, los de tiendaonline, lista el email, apellidos, nombre, y nombres de la localidad y provincia.
```SQL
select email,apellidos,u.nombre,p.nombre,l.pueblo
from tiendaonline.localidad l, tiendaonline.provincia p,
(
  select email,apellidos,nombre,provincia,pueblo from VusuAlm
  UNION
  select email,apellidos,nombre,provincia,pueblo from tiendaonline.usuario
) u
where u.provincia=l.provincia and u.pueblo=l.codm
  and l.provincia=p.codp;
```

T13.016- De tus datos almacenados en tu base de datos, crea una vista TApedidosAlm que muestre número de pedido, usuario, fecha, y total pagado por cada pedido. Serán los pedidos hechos en la delegación de Almería.
```SQL
create or replace view TApedidosAlm as
select p.numpedido,sum(importe*cantidad) total,date(fecha),usuario  
from pedidosAlm p join lineasAlm l on p.numpedido=l.numpedido 
group by p.numpedido,date(fecha),usuario;

-- comprobando
select * from TApedidosAlm;
```
T13.017- Aprovecha VusuAlm y TApedidosAlm para mostrar a todos los usuarios de Almeria (email, nombre, y apellidos) y, si tienen pedidos, también número de pedido y el total pagado por cada uno de sus pedidos.
```SQL
select email, nombre, apellidos, p.numpedido,total
from VusuAlm u 
left join TApedidosAlm p on u.email=p.usuario;
```
