# Practica 1

* Professora - Ana Lavalle Lopez

## Examenes

* SQL-A marzo = 25
* SQL-B mayo = 25
* Final julio

## Resursos - 
https://bbdd.dlsi.ua.es/
https://sites.google.com/view/fbddocs/sesiones

## Base de Datos 
```BD
Usuario MariaDB: mt106
Contraseña: J9M9tAD3
Base de datos: z0_mt106
```
Servidor BD
* MySQL/MariaDB
> bbdd.dlsi.ua.es:3306
* acceso desde fuera de la UA
> https://bbdd.dlsi.ua.es/abrirpuertomysql.php  

- Esquema de Tienda Online(https://sites.google.com/view/fbddocs/materiales/tienda-online-e-r) 

![image](https://user-images.githubusercontent.com/90862738/216020746-db23f707-518d-4bbe-9afb-0ab0f85c8e91.png)

- Esquema relacional de base datos(https://sites.google.com/view/fbddocs/materiales/tienda-online-relacional)

- Base de datos, relación y consultas(https://sites.google.com/view/fbddocs/sql/base-de-datos-relaci%C3%B3n-y-consultas)


## Practicando

1. Test
```SQL
SELECT cod, pvp FROM articulo

WHERE  pvp >= 400 /*comment*/

ORDER BY pvp ASC -- single line comments
```

2. Test

```SQL
SELECT marca, cod, pvp FROM articulo

WHERE  pvp >= 400 AND marca != "Sigma" /*comment*/

ORDER BY marca , pvp ASC -- single line comments
```

3. Test

```SQL
SELECT * from camara -- selects everthing
```

4. Test

```SQL
SELECT cod FROM camara
WHERE sensor = "CCD de 12,10 MP (efectivos:12,10 MP)" or resolucion = "5184 x 3456"
ORDER BY cod
```

## [Ejercicios](https://bbdd.dlsi.ua.es/FBDweb/SQLf/proponerxdif.php?sesion=T02&desde=1&hasta=999)
- T02

* Difficulty 0
> T02.001- Get all the information of users.

```SQL
SELECT * FROM usuario
```

> T02.011- Marcas

```SQL
SELECT * FROM marca
```
* Dificultad 1

> T02.002- Lista los email y nombre y apellidos de los usuarios

```SQL
SELECT email, nombre, apellidos FROM usuario
```

> T02.003- Lista los email y nombre y apellidos de los usuarios ordenados por email

```SQL
SELECT email, nombre, apellidos FROM usuario
ORDER BY email 
```

> T02.005- Lista los email y nombre y apellidos de los usuarios ordenados ascendentemente por apellidos y descendentemente por nombre

```SQL
SELECT email, nombre, apellidos FROM usuario
ORDER BY apellidos ASC, nombre DESC
```

> T02.006- Lista los email y nombre y apellidos de los usuarios en orden descendente de apellidos y nombre

```SQL
SELECT email, nombre, apellidos FROM usuario
ORDER BY apellidos DESC, nombre DESC 
```

> T02.016- Código e importe de los artículos solicitados en el pedido número 1.

```SQL
select articulo,importe
from linped
where numpedido = 1
```

> T02.023- Panel de los televisores de 21 pulgadas o menos de pantalla, eliminando duplicados.

```SQL
SELECT Distinct tv.panel FROM tv -- Distinct removes duplicates
WHERE tv.pantalla <= 21;
```

> T02.024- Código, nombre, marca y pvp de los artículos que tienen ese precio entre 350 y 450.

```SQL
SELECT a.cod, a.nombre, a.marca, a.pvp
FROM articulo a
 WHERE a.pvp BETWEEN 350 AND 450
-- WHERE a.pvp >= 350 AND a.pvp <= 450
```

* Dificultad A

> T02.025- Código, nombre y precio de venta al público de los artículos que no tienen marca.

```SQL
SELECT a.cod, a.nombre, a.pvp
FROM articulo a
WHERE marca is Null
```

> T02.026- Código, nombre y precio de venta al público de los artículos que no tienen precio de venta al público y son de marca Sigma.

```SQL
SELECT a.cod, a.nombre, a.pvp
FROM articulo a
 WHERE a.pvp is NULL AND a.marca = "Sigma"
```

> T02.027- Email, nombre, apellidos y teléfono de los usuarios que se llaman Santiago, Wenceslao o Sergio.

```SQL
SELECT u.email, u.nombre, u.email, u.telefono
FROM usuario u
WHERE u.nombre = "Santiago" OR u.nombre = "Wenceslao" OR u.nombre = "Sergio"
```

> T02.028- Email, nombre, apellidos y teléfono de los usuarios que se llaman Santiago, Wenceslao o Sergio y que sí tienen teléfono.

```SQL
SELECT u.email, u.nombre, u.email, u.telefono
FROM usuario u
WHERE (u.nombre = "Santiago" OR u.nombre = "Wenceslao" OR u.nombre = "Sergio")
AND u.telefono IS NOT NULL;
```

- En clase

* Dificultad 1

> T02B.001- Código, nombre y pvp de los artículos de menos de 100€; la salida ha de ser código, nombre, "tiene el precio de", pvp.

```SQL
SELECT a.cod, a.nombre,'tiene el precio de', a.pvp
FROM articulo a
WHERE a.pvp < 100;
```

* Dificultad A

> T02B.002- DNI,email,nombre y apellidos de los usuarios de la provincia de Asturias (código 33).

```SQL
SELECT u.dni, u.nombre, u.apellidos
FROM usuario u
WHERE u.provincia = 33;
```

> T02B.003- Toda la información (código y nombre) de las provincias de las que se tienen usuarios

```SQL
select pv.* 
from usuario u, provincia pv
where u.provincia=codp;
```

> T02B.004- Toda la información (código y nombre) de las provincias de las que se tienen usuarios, eliminando duplicados y ordenando por nombre

```SQL
SELECT DISTINCT p.*
FROM provincia p, usuario u
WHERE  u.provincia = p.codp
ORDER BY u.nombre 
```

> T02B.005- Email de los usuarios de la provincia de Murcia que no tienen teléfono, acompañado en la salida por un mensaje que diga "No tiene teléfono"

```SQL
SELECT email, 'No tiene telefono'
FROM usuario u, provincia p
WHERE p.codp = u.provincia 
AND p.nombre = "Murcia" 
AND telefono IS NULL
```

> T02B.006- Artículos que no tienen marca

```SQL
SELECT a.*
FROM articulo a
WHERE marca IS NULL
```

> T02B.007- Código y nombre de los articulos con un precio entre 400 y 500 euros.

```SQL
SELECT a.cod, a.nombre
FROM articulo a
WHERE pvp BETWEEN 400 AND 500;
```

> T02B.008- Código y nombre de los articulos con precio 415, 129, 1259 o 3995.

```SQL
SELECT a.cod, a.nombre
FROM articulo a
WHERE pvp = 415 OR pvp = 129 
OR pvp = 1259 OR pvp = 3995;
```

> T02B.009- Código, nombre, marca, pvp e importe de los artículos solicitados en el pedido número 1.

```SQL
SELECT a.cod, a.nombre, a.marca, a.pvp, l.importe
FROM articulo a, linped l
WHERE l.numPedido = 1 AND l.articulo= a.cod
```

> T02B.012- Código, sensor y pantalla de las cámaras, si es que "pantalla" tiene valor, ordenado por código descendentemente;

```SQL
SELECT ca.cod, ca.sensor, ca.pantalla
FROM camara ca
WHERE pantalla IS NOT NULL 
ORDER BY ca.cod DESC;
```

> T02B.020- Código y nombre de las provincias que no son Huelva, Sevilla, Asturias ni Barcelona.

```SQL
SELECT pr.codp, pr.nombre
FROM provincia pr
WHERE pr.nombre != "Huelva" 
AND pr.nombre != "Sevilla"
AND pr.nombre != "Asturias"
AND pr.nombre != "Barcelona"
```

- Dificultad B

> T02B.010- Código, nombre, marca, pvp e importe de los artículos solicitados en el pedido número 1 que sean televisores.

```SQL
SELECT ar.cod,ar.nombre, ar.marca, ar.pvp, li.importe
FROM articulo ar, linped li,tv
WHERE li.numPedido = 1 AND li.articulo = ar.cod
AND ar.cod = tv.cod;
```

> T02B.011- Fecha y usuario del pedido, código, nombre, marca, pvp e importe de los artículos solicitados en el pedido número 1 que sean televisores.


```SQL
SELECT pe.fecha, pe.usuario,
ar.cod,ar.nombre, ar.marca, ar.pvp,
li.importe

FROM articulo ar, linped li,tv, pedido pe
WHERE li.numPedido = 1 AND li.articulo = ar.cod
AND ar.cod = tv.cod
AND li.numPedido = pe.numPedido;
```

* This cause HeidiSQL to freeze and cannot be stopped without restart of it.

```SQL error
SELECT pe.fecha, pe.usuario, ar.cod, ar.nombre,
ar.marca, ar.pvp, li.importe
FROM pedido pe, articulo ar, linped li
WHERE li.numPedido = 1
```

> T02B.014- Nombre de las provincias en las que viven usuarios que hayan realizado algún pedido, eliminando duplicados.

```SQL
SELECT DISTINCT pr.nombre -- , us.email -- para verificar
FROM pedido pe, usuario us, provincia pr
WHERE us.email = pe.usuario AND pr.codp = us.provincia;
```
