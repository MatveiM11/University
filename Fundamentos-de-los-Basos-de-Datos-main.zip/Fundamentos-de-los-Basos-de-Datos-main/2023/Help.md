# Examen 2
Practica 8 - 13

## Base de Datos 
```BD
Usuario MariaDB: mt106
Contraseña: J9M9tAD3
Base de datos: z0_mt106
```
Servidor BD
* MySQL/MariaDB
> bbdd.dlsi.ua.es:3306
* acceso desde fuera de la UA
> https://bbdd.dlsi.ua.es/abrirpuertomysql.php  

- Esquema de Tienda Online(https://sites.google.com/view/fbddocs/materiales/tienda-online-e-r) 

![image](https://user-images.githubusercontent.com/90862738/216020746-db23f707-518d-4bbe-9afb-0ab0f85c8e91.png)

- Esquema relacional de base datos(https://sites.google.com/view/fbddocs/materiales/tienda-online-relacional)

- Base de datos, relación y consultas(https://sites.google.com/view/fbddocs/sql/base-de-datos-relaci%C3%B3n-y-consultas)



https://www.programiz.com/sql/online-compiler/

https://www.w3schools.com/sql/trysql.asp?filename=trysql_select_all

https://www.bing.com/

https://sites.google.com/view/fbddocs/sesiones
