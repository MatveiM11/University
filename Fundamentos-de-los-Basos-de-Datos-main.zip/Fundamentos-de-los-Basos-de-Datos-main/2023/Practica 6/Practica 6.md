# S06 Calculos


# Simulacro

- 1 Codigo, nombre y marca de los articulos que puertenecen a algun pack

```SQL
SELECT  a.cod, a.nombre, a.marca
FROM articulo a, pack p
where a.cod = p.cod
```

- 2 Informacion sobre los usuarios menores de 25 anos

```SQL
SELECT  * 
FROM usuario u
where u.nacido  > '1996-12-31'
```

- 3 Informacion de todos los usuarios de la comunidad valenciana cuyo nombre empiece por 'P' incluendo la direccion de envio en caso de que la tenga

```SQL
SELECT  u.* 
FROM provincia p, usuario u
LEFT JOIN direnvio d  on d.email  = u.email 
WHERE  p.codp = 46 AND u.nombre LIKE 'P%' and d.calle IS NOT NULL;
```

- 4 Obtener la cantidad de provincias distintas de las que tenemos conocimiento de algun usuario

 ```SQL
 SELECT count(DISTINCT u.provincia)
FROM usuario u 
 ```

- 5 a) Crea una table: tbA(a int, b int, c int) CP(a)
b) Crea una tabla: tbB(d int, e int) CP(d), CAj(e)>>tbA, borrados propagar, modificaciones anular
c) Inserta en tbA las filas: (a=4, c=99), (a=2, c=20);
d) Inserta en tbB el contenido de tbA, almacenando en tbB.d los valores de la columna tbA.c, y en tbB.e lo que haya en la columna tbA.a, con una unica instruccion a partir de una consulta sobre tbA.

```SQL
CREATE TABLE tbA (
  a INT,
  b INT,
  c INT,
  PRIMARY KEY (a)
);

CREATE TABLE tbB (
  d INT,
  e INT,
  PRIMARY KEY (d),
  CONSTRAINT CAj FOREIGN KEY (e) REFERENCES tbA(a) ON DELETE CASCADE ON UPDATE SET NULL
);

INSERT INTO tbA (a, c) VALUES (4, 99), (2, 20);

INSERT INTO tbB (d, e)
SELECT c, a FROM tbA;
```
