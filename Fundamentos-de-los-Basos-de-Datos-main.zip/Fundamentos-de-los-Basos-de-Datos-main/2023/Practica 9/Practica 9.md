# Summary

Brands with fewer than 150 articles:
To find brands with less than 150 articles in the ARTICULO table, use SELECT with GROUP BY and HAVING to filter the results based on the article count.

Brands with fewer than 150 articles, excluding NULL brands:
To exclude NULL brands, add a WHERE clause to check that the 'marca' field is not NULL before grouping and filtering.

Users who have placed more than one order:
Join the 'usuario' and 'pedido' tables and use GROUP BY with HAVING to filter users who have more than one order.

Orders with a total value greater than 4000 euros:
Join the 'pedido' and 'linped' tables and calculate the total order value using SUM. Then, use GROUP BY and HAVING to filter orders above 4000 euros.

Orders with more than 10 items:
Join the 'pedido' and 'linped' tables and use GROUP BY with HAVING to filter orders that have a total quantity of items greater than 10.

Orders with more than four distinct items:
Join the 'pedido' and 'linped' tables and use GROUP BY with HAVING to filter orders containing more than four distinct articles.

Provinces with more than 100 towns:
Join the 'provincia' and 'localidad' tables and use GROUP BY with HAVING to filter provinces with more than 100 towns.

Customers who have ordered more than 2 TVs:
Join the 'pedido', 'linped', and 'tv' tables, and use GROUP BY with HAVING to filter customers who have ordered more than 2 TVs.







# Soluciones

T09B.002- ¿Cuáles son las marcas (en la tabla ARTICULO) que tienen menos de 150 artículos?
```SQL
select marca,count(*) from articulo 
group by marca 
having count(*)<150;
```
T09B.003- ¿Cuáles son las marcas (en la tabla ARTICULO) que tienen menos de 150 artículos (eliminar las marcas que sean null)?
```SQL
select marca,count(*) from articulo 
where marca is not null 
group by marca 
having count(*)<150
```
T09B.005- Dni, nombre, apellidos y email de los usuarios que han realizado más de un pedido.
```SQL
select dni,nombre,apellidos,email 
from usuario U, pedido P
where U.email=P.Usuario 
group by dni,nombre,apellidos,email 
having count(*)>1;
```
T09B.006- Pedidos (número de pedido y usuario) de importe mayor a 4000 euros.
```SQL
select p.numpedido,p.usuario  
from pedido p, linped l  
where p.numpedido=l.numpedido 
group by p.numpedido,p.usuario
having sum(cantidad*importe)>4000;
```
Cuando nos piden el importe (total) de un pedido, se entiende que es el precio unitario de cada línea de ese pedido multiplicado por la cantidad pedida de ese artículo.

T09B.007- Pedidos (número de pedido y usuario) con más de 10 artículos, mostrando esta cantidad.
```SQL
select P.numPedido,P.usuario, sum(cantidad) 
from pedido P, linped L  
where P.numPedido=L.numPedido 
group by P.numPedido,P.usuario
having sum(cantidad)>10;
```

T09B.008- Pedidos (número de pedido y usuario) que contengan más de cuatro artículos distintos.
```SQL
select P.numPedido,P.usuario, count(distinct articulo)  
from pedido P, linped L 
where P.numPedido=L.numPedido 
group by P.numPedido,P.usuario
having count(distinct articulo)>4;
```
T09B.009- ¿Hay dos provincias que se llamen igual (con nombre repetido)?
```SQL
select nombre,count(*) from provincia group by nombre having count(*)>1;
```

T09B.010- ¿Hay algún pueblo con nombre repetido?
```SQL
select pueblo,count(*) from localidad group by pueblo having count(*)>1;
```

T09B.011- Obtener el código y nombre de las provincias que tengan más de 100 pueblos.
```SQL
select P.codp,P.nombre,count(*) 
FROM provincia P, localidad L 
WHERE P.codp=L.provincia 
group by P.codp,P.nombre 
having count(*)>100;
```

T09B.013- Clientes que hayan adquirido (pedido) más de 2 tv
```SQL
select p.usuario, sum(cantidad) 
from pedido p, linped l, tv
where p.numpedido=l.numpedido
  and l.articulo=tv.cod
group by p.usuario 
having sum(cantidad)>2;
```
Hay que sumar la columna LINPED.cantidad porque es la que nos dice cuántas unidades de cada artículo se han pedido.

T09B.015- Código y nombre de las provincias que tienen más de 50 usuarios (provincia del usuario, no de la dirección de envío).
```SQL
select p.codp, p.nombre 
from provincia p, usuario u 
where p.codp=u.provincia 
group by p.codp, p.nombre 
having count(email)>50;
```

T09B.018- Número de artículos pedidos por provincia (provincia del usuario no de la dirección de envío). Mostrar el código de la provincia, su nombre y la cantidad de veces que se ha pedido el artículo; si la provincia no tiene asociada esta cantidad, mostrar "0" en esa columna.
```SQL
select pr.codp, pr.nombre, IFNULL(sum(cantidad),0) 
from provincia pr 
  left join usuario u on (pr.codp=u.provincia) 
  left join pedido p on (p.usuario=u.email)
  left join linped l on (p.numpedido=l.numpedido)
group by pr.codp,pr.nombre;
```

T09B.019- Código y nombre de los artículos que han sido solicitados en todos los pedidos del usuario acm@colegas.com.
```SQL
select cod,nombre
from articulo a
where cod in
   (select articulo
    from pedido p,linped l
    where usuario='acm@colegas.com' and p.numpedido=l.numpedido
    group by articulo
    having count(distinct p.numpedido) = 
             (select count(*) from pedido where usuario='acm@colegas.com')
   );
```

Solución alternativa:
```SQL
select cod,nombre
from articulo a 
where not exists
  (select 1
   from pedido p
   where usuario='acm@colegas.com'
     and not exists
       (select 1
        from linped l
        where l.numpedido=p.numpedido
          and l.articulo=a.cod)
  );
```

-- También:

```SQL
select articulo,nombre
from articulo a, pedido p,linped l
where usuario='acm@colegas.com' 
  and p.numpedido=l.numpedido
  and l.articulo=a.cod
group by articulo,nombre
having count(distinct p.numpedido) = 
            (select count(*) from pedido where usuario='acm@colegas.com');
```

T09B.020- ¿Cuáles son las marcas que tienen menos de 150 artículos?

```SQL
select m.marca,count(a.marca) 
from marca m 
LEFT JOIN articulo a on m.marca=a.marca   
group by marca 
having count(a.marca)<150;
```
Se entiende que estamos preguntando por todas las marcas conocidas, las de la tabla MARCA. Una de ellas podría no aparecer en la tabla ARTICULO, por lo que su cuenta de artículos sería 0 y haría cierta la condición.

El problema reside en que, si solo miramos ARTICULO, esa marca no saldrá en el listado; y si hacemos un INNER JOIN tampoco porque esa marca no encontrará artículo con el que concatenarse.

La solución es un LEFT JOIN: muestra todas las marcas y, si tienen artículos, cuéntalos. De esta forma también se muestran las marcas con 0 artículos. Además, evita aquellos artículos "sin marca", de los que desconocemos la marca (marca is null).

No obstante, el estado actual de la base de datos no contiene marcas así, por lo que daría el mismo resultado que

```SQL
select marca,count(*)
from articulo
group by marca
having count(*)<150;
```

Pero es una casualidad, nada garantiza que en otro momento no se añada una nueva marca y que no tenga artículos.
