select a.cod artcod, nombre, pvp, o.*
from articulo a 
left join objetivo o on (a.cod = o.cod);