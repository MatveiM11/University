select i1.dni, ' imparte la misma asignatura que ', i2.dni 

from imparte i1, imparte i2 

where i1.asignatura= i2.asignatura