SELECT count(pvp)   
FROM articulo
WHERE pvp != 0;