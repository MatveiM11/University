SELECT *
from usuario
where email LIKE '%@eps.%'

/* Or like:
where nombre like 'Alicante%';
*/

