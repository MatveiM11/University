SELECT nombre, cod
FROM articulo
WHERE pvp >= 400 AND pvp <= 500
/* Or like:
WHERE pvp >= 400 AND pvp <= 500
*/