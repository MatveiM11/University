SELECT nombre, cod
FROM articulo
WHERE pvp IN (415,129, 1259, 3995)
/* Or like:
WHERE pvp = 415 OR pvp = 129 OR pvp = 1259 OR pvp = 3995
*/

