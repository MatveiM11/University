select cod, nombre, pvp
from articulo
where marca like 'S%'

/* Or like:
where nombre like 'Alicante%';
*/

