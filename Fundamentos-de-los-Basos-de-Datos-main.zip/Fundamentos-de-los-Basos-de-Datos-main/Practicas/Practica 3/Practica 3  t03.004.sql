SELECT nombre, codp
FROM provincia
where nombre like 'Alicante%'
/* Or like:
where nombre like 'Alicante%';
*/

