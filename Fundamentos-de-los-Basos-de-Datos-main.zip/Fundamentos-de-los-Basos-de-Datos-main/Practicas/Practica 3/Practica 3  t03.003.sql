SELECT nombre, codp
FROM provincia
WHERE nombre not IN ('Huelva','Sevilla', 'Asturias', 'Barcelona')
/* Or like:
where nombre like 'Alicante%';
*/

